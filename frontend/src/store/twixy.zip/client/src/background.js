"use strict";

const CLIENT_ID = "x4m8vmy47zv4sx7ls8n4rr9mgcx3vs";

const SCOPES = [ "user:edit:follows", "user:read:email", "user:read:follows", "moderation:read" ];

const TWITCH_API = "https://api.twitch.tv/helix";

const DEV_MODE = !chrome.runtime.getManifest().update_url;

const SERVER_BASE = "https://twixy.cc/api";

const BROWSER_KIND = (() => {
    try {
        if (typeof browser !== "undefined" && typeof browser.runtime?.getBrowserInfo === "function") {
            return "firefox";
        }
    } catch (_) {}
    try {
        const ua = typeof navigator !== "undefined" && navigator.userAgent || "";
        if (/firefox|fxios/i.test(ua)) return "firefox";
    } catch (_) {}
    return "chrome";
})();

function extractMozExtensionUuid() {
    const urls = [];
    try {
        urls.push(chrome.runtime.getURL(""));
    } catch (_) {}
    try {
        urls.push(chrome.runtime.getURL("manifest.json"));
    } catch (_) {}
    try {
        urls.push(chrome.runtime.getURL("background.js"));
    } catch (_) {}
    try {
        if (typeof self !== "undefined" && self.location?.href) urls.push(self.location.href);
    } catch (_) {}
    try {
        const script = typeof self !== "undefined" && self.registration?.active?.scriptURL;
        if (script) urls.push(script);
    } catch (_) {}
    const re = /^moz-extension:\/\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(\/|$)/i;
    for (const raw of urls) {
        const m = re.exec(String(raw || ""));
        if (m) return m[1].toLowerCase();
    }
    return null;
}

function getIdentityRedirectFromApi() {
    let u = chrome.identity.getRedirectURL();
    try {
        if (typeof browser !== "undefined" && browser.identity?.getRedirectURL) {
            const b = browser.identity.getRedirectURL();
            if (b && !/chromiumapp\.org/i.test(b)) u = b;
        }
    } catch (_) {}
    return u;
}

function normalizeTwitchRedirectUri(uri) {
    const s = String(uri || "").trim();
    if (!s) return s;
    if (/^https:\/\/[^/]+\.chromiumapp\.org\/?$/i.test(s) || /^https:\/\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.extensions\.mozilla\.org\/?$/i.test(s)) {
        return s.replace(/\/+$/, "") + "/";
    }
    return s;
}

function getOAuthRedirectUri() {
    const rawApi = getIdentityRedirectFromApi();
    const hasGecko = Boolean(chrome.runtime.getManifest().browser_specific_settings?.gecko);
    const badChromeRedirect = Boolean(rawApi && /chromiumapp\.org/i.test(rawApi));
    if (hasGecko && badChromeRedirect) {
        const uuid = extractMozExtensionUuid();
        if (uuid) {
            return normalizeTwitchRedirectUri(`https://${uuid}.extensions.mozilla.org/`);
        }
    }
    return normalizeTwitchRedirectUri(rawApi);
}

let _twitchToken = null;

const AVATAR_CACHE_TTL_MS = 10 * 60 * 1e3;

const _avatarCache = new Map;

const _avatarPending = new Map;

function normalizeLogin(login) {
    return String(login ?? "").trim().toLowerCase();
}

function getCachedAvatar(login) {
    const key = normalizeLogin(login);
    if (!key) return null;
    const cached = _avatarCache.get(key);
    if (!cached) return null;
    if (Date.now() - cached.ts > AVATAR_CACHE_TTL_MS) {
        _avatarCache.delete(key);
        return null;
    }
    return cached.url || null;
}

function setCachedAvatar(login, url) {
    const key = normalizeLogin(login);
    if (!key || !url) return;
    _avatarCache.set(key, {
        url: url,
        ts: Date.now()
    });
}

async function fetchAvatarUrl(login, twitchToken) {
    const key = normalizeLogin(login);
    if (!key) return null;
    const cached = getCachedAvatar(key);
    if (cached) return cached;
    const headers = {
        "Client-Id": CLIENT_ID
    };
    if (twitchToken) {
        headers.Authorization = `Bearer ${twitchToken}`;
    }
    const res = await fetch(`${TWITCH_API}/users?login=${encodeURIComponent(key)}`, {
        headers: headers
    });
    const data = await res.json();
    const url = data.data?.[0]?.profile_image_url ?? null;
    if (url) {
        setCachedAvatar(key, url);
    }
    return url;
}

chrome.storage.local.get("serverToken", ({serverToken: serverToken}) => {
    if (!serverToken) return;
    try {
        const {exp: exp} = JSON.parse(atob(serverToken.split(".")[1]));
        if (exp && Date.now() >= exp * 1e3) {
            chrome.storage.local.remove("serverToken");
        }
    } catch {
        chrome.storage.local.remove("serverToken");
    }
});

function getTwitchToken() {
    return new Promise(resolve => {
        const redirectUri = getOAuthRedirectUri();
        const authUrl = "https://id.twitch.tv/oauth2/authorize" + "?client_id=" + CLIENT_ID + "&redirect_uri=" + encodeURIComponent(redirectUri) + "&response_type=token" + "&scope=" + encodeURIComponent(SCOPES.join(" "));
        chrome.identity.launchWebAuthFlow({
            url: authUrl,
            interactive: true
        }, redirectUrl => {
            if (chrome.runtime.lastError || !redirectUrl) return resolve(null);
            const hash = redirectUrl.split("#")[1] || "";
            const params = new URLSearchParams(hash);
            resolve(params.get("access_token"));
        });
    });
}

async function fetchTwitchUser(token) {
    const res = await fetch(`${TWITCH_API}/users`, {
        headers: {
            Authorization: `Bearer ${token}`,
            "Client-Id": CLIENT_ID
        }
    });
    const body = await res.json();
    return body.data?.[0] ?? null;
}

async function persistTwitchUser(token, user) {
    if (!token || !user) return null;
    _twitchToken = token;
    await chrome.storage.local.set({
        twitchToken: token,
        twitchUser: {
            id: user.id,
            login: user.login,
            display_name: user.display_name,
            profile_image_url: user.profile_image_url
        }
    });
    if (user.login && user.profile_image_url) {
        setCachedAvatar(user.login, user.profile_image_url);
    }
    return user;
}

async function syncTwitchIdentity(token) {
    if (!token) return null;
    const user = await fetchTwitchUser(token);
    if (!user) return null;
    await persistTwitchUser(token, user);
    const serverToken = await authenticateWithServer(token);
    if (!serverToken) return null;
    return {
        twitchToken: token,
        serverToken: serverToken,
        user: user
    };
}

async function fetchWithTimeout(url, init = {}, timeoutMs = 1e4) {
    let controller = null;
    let timeoutId = null;
    try {
        if (typeof AbortController === "function") {
            controller = new AbortController;
            timeoutId = setTimeout(() => {
                try {
                    controller.abort();
                } catch (_) {}
            }, timeoutMs);
            return await fetch(url, {
                ...init,
                signal: controller.signal
            });
        }
        return await fetch(url, init);
    } finally {
        if (timeoutId != null) clearTimeout(timeoutId);
    }
}

let _lastAuthFetchErrorAt = 0;

let _authInflight = null;

let _authInflightToken = null;

async function authenticateWithServer(twitchToken) {
    if (_authInflightToken === twitchToken && _authInflight) return _authInflight;
    _authInflightToken = twitchToken;
    _authInflight = (async () => {
        const formBody = new URLSearchParams({
            access_token: twitchToken,
            browser: BROWSER_KIND
        }).toString();
        let res;
        try {
            res = await fetchWithTimeout(`${SERVER_BASE}/auth/twitch`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: formBody,
                cache: "no-store",
                mode: "cors",
                credentials: "omit"
            }, 12e3);
        } catch (err) {
            console.warn(`[Twixy BG] /auth/twitch network error:`, err?.message || err);
            _lastAuthFetchErrorAt = Date.now();
            return null;
        }
        if (res.status === 429) {
            console.warn("[Twixy BG] /auth/twitch rate-limited (429)");
            _lastAuthFetchErrorAt = Date.now();
            return null;
        }
        if (res.status >= 500) {
            let body = "";
            try {
                body = await res.text();
            } catch {}
            console.error(`[Twixy BG] /auth/twitch ${res.status} server error:`, body.slice(0, 300));
            _lastAuthFetchErrorAt = Date.now();
            return null;
        }
        let data = null;
        try {
            data = await res.json();
        } catch {
            return null;
        }
        if (data?.success && data.token) {
            await chrome.storage.local.set({
                serverToken: data.token
            });
            _browserPushedFor = null;
            _lastAuthFetchErrorAt = 0;
            return data.token;
        }
        if (data && !data.success) {
            console.warn("[Twixy BG] /auth/twitch returned non-success:", data);
        }
        return null;
    })();
    try {
        return await _authInflight;
    } finally {
        setTimeout(() => {
            if (_authInflightToken === twitchToken) {
                _authInflightToken = null;
                _authInflight = null;
            }
        }, 300);
    }
}

let _refreshPromise = null;

let _lastRefreshFailAt = 0;

async function _doRefresh() {
    if (_lastRefreshFailAt && Date.now() - _lastRefreshFailAt < 8e3) return null;
    const {serverToken: serverToken} = await chrome.storage.local.get("serverToken");
    if (!serverToken) {
        _lastRefreshFailAt = Date.now();
        return null;
    }
    try {
        const res = await fetchWithTimeout(`${SERVER_BASE}/auth/refresh`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${serverToken}`
            }
        }, 1e4);
        if (!res.ok) {
            _lastRefreshFailAt = Date.now();
            return null;
        }
        const data = await res.json();
        if (data.success && data.token) {
            await chrome.storage.local.set({
                serverToken: data.token
            });
            _lastRefreshFailAt = 0;
            pushBrowserKindToServer(data.token).catch(() => {});
            return data.token;
        }
    } catch (err) {
        console.warn("[Twixy BG] refresh error:", err?.message || err);
    }
    _lastRefreshFailAt = Date.now();
    return null;
}

let _browserPushedFor = null;

async function pushBrowserKindToServer(serverToken) {
    if (!serverToken || _browserPushedFor === serverToken) return;
    _browserPushedFor = serverToken;
    try {
        await fetchWithTimeout(`${SERVER_BASE}/users/me/browser`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${serverToken}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                browser: BROWSER_KIND
            })
        }, 8e3);
    } catch {}
}

async function refreshServerToken() {
    if (_refreshPromise) return _refreshPromise;
    _refreshPromise = _doRefresh().finally(() => {
        _refreshPromise = null;
    });
    return _refreshPromise;
}

async function authorizeTwitch({forceInteractive: forceInteractive = false} = {}) {
    if (!forceInteractive && _twitchToken) {
        try {
            const synced = await syncTwitchIdentity(_twitchToken);
            if (synced) return synced;
        } catch (e) {
            console.warn("[Twixy BG] sync from cached twitchToken failed:", e?.message || e);
        }
    }
    if (!forceInteractive) {
        let storedTwitchToken = null;
        try {
            ({twitchToken: storedTwitchToken} = await chrome.storage.local.get("twitchToken"));
        } catch {}
        if (storedTwitchToken) {
            try {
                const synced = await syncTwitchIdentity(storedTwitchToken);
                if (synced) return synced;
            } catch (e) {
                console.warn("[Twixy BG] sync from stored twitchToken failed:", e?.message || e);
            }
        }
    }
    let token = null;
    try {
        token = await getTwitchToken();
    } catch (e) {
        console.warn("[Twixy BG] OAuth flow failed:", e?.message || e);
    }
    if (!token) return null;
    let user = null;
    try {
        user = await fetchTwitchUser(token);
    } catch (e) {
        console.warn("[Twixy BG] fetchTwitchUser failed:", e?.message || e);
    }
    if (!user) return null;
    try {
        await persistTwitchUser(token, user);
    } catch {}
    const serverToken = await authenticateWithServer(token);
    return serverToken ? {
        twitchToken: token,
        serverToken: serverToken,
        user: user
    } : null;
}

const HQ_RULE_ID_LIVE_LEGACY = 101;

const HQ_RULE_ID_VOD = 102;

const HQ_TAB_LIVE_RULE_ID_BASE = 1e5;

const HQ_SCRIPT_ID = "twixy-quality-main";

const HQ_PROXY_BASE = `${SERVER_BASE}/playlist`;

const _hqTabNavTimers = new Map;

function channelLoginFromTwitchUrl(urlStr) {
    try {
        const u = new URL(urlStr);
        if (!/twitch\.tv$/i.test(u.hostname) && !/\.twitch\.tv$/i.test(u.hostname)) return null;
        if (/^clips\.twitch\.tv$/i.test(u.hostname)) return null;
        const parts = u.pathname.replace(/^\//, "").split("/").filter(Boolean);
        if (!parts.length) return null;
        const first = parts[0].toLowerCase();
        if (first === "moderator" && parts[1]) {
            const mod = parts[1].toLowerCase();
            if (/^[a-z0-9_]{3,25}$/.test(mod)) return mod;
            return null;
        }
        const RESERVED = new Set([ "directory", "settings", "popout", "jobs", "messages", "inventory", "store", "turbo", "search", "subscriptions", "collections", "clips", "team", "login", "signup", "drops", "extensions", "oauth2", "create", "videos", "history", "moderator", "console", "authorize", "watchparty", "p", "s", "embed" ]);
        if (!/^[a-z0-9_]{3,25}$/.test(first) || RESERVED.has(first)) return null;
        return first;
    } catch {
        return null;
    }
}

function hqTabLiveRuleId(tabId) {
    return HQ_TAB_LIVE_RULE_ID_BASE + tabId;
}

async function helixChannelIsLive(login) {
    const L = normalizeLogin(login);
    if (!L) return false;
    try {
        const {twitchToken: storedTok} = await chrome.storage.local.get("twitchToken");
        const twitchToken = storedTok || _twitchToken;
        if (twitchToken) {
            const r = await fetch(`${TWITCH_API}/streams?user_login=${encodeURIComponent(L)}`, {
                headers: {
                    Authorization: `Bearer ${twitchToken}`,
                    "Client-Id": CLIENT_ID
                }
            });
            if (!r.ok) return false;
            const data = await r.json().catch(() => null);
            return Array.isArray(data?.data) && data.data.length > 0;
        }
        const r = await fetch(`${SERVER_BASE}/twitch/stream-live?login=${encodeURIComponent(L)}`);
        if (!r.ok) return false;
        const data = await r.json().catch(() => null);
        if (data?.unavailable) return false;
        return Boolean(data?.live);
    } catch {
        return false;
    }
}

async function removeHqLiveRedirectForTab(tabId) {
    const id = hqTabLiveRuleId(tabId);
    try {
        await chrome.declarativeNetRequest.updateSessionRules({
            removeRuleIds: [ id ]
        });
    } catch {}
}

async function removeAllHqTabLiveRedirectRules() {
    try {
        const rules = await chrome.declarativeNetRequest.getSessionRules();
        const remove = rules.filter(r => r.id >= HQ_TAB_LIVE_RULE_ID_BASE && r.id < HQ_TAB_LIVE_RULE_ID_BASE + 2e9).map(r => r.id);
        if (remove.length) {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: remove
            });
        }
    } catch {}
}

async function upsertHqLiveRedirectForTab(tabId) {
    const auth = await getTwitchAuthCookie();
    if (!auth) return false;
    const safeAuth = encodeURIComponent(auth);
    const ruleId = hqTabLiveRuleId(tabId);
    const rule = {
        id: ruleId,
        priority: 1,
        action: {
            type: "redirect",
            redirect: {
                regexSubstitution: `${HQ_PROXY_BASE}?auth=${safeAuth}&channel=\\1&\\2`
            }
        },
        condition: {
            regexFilter: "^https://usher\\.ttvnw\\.net/api(?:/v2)?/channel/hls/([^/?]+)\\.m3u8(?:\\?(.*))?$",
            resourceTypes: [ "xmlhttprequest", "media", "other" ],
            tabIds: [ tabId ]
        }
    };
    try {
        await chrome.declarativeNetRequest.updateSessionRules({
            removeRuleIds: [ ruleId ],
            addRules: [ rule ]
        });
        return true;
    } catch (e) {
        console.warn("[Twixy HQ] tab live session DNR:", e?.message || e);
        return false;
    }
}

async function syncHqLiveRedirectForTwitchTab(tabId, urlStr) {
    const {hqEnabled: hqEnabled} = await chrome.storage.local.get("hqEnabled");
    if (!hqEnabled) {
        await removeHqLiveRedirectForTab(tabId);
        return;
    }
    const login = channelLoginFromTwitchUrl(urlStr || "");
    if (!login) {
        await removeHqLiveRedirectForTab(tabId);
        return;
    }
    const live = await helixChannelIsLive(login);
    if (live) {
        const ok = await upsertHqLiveRedirectForTab(tabId);
        if (!ok) console.warn("[Twixy HQ] session DNR failed", login, "tab", tabId);
    } else {
        await removeHqLiveRedirectForTab(tabId);
    }
}

function scheduleHqLiveRedirectSync(tabId, urlStr) {
    const prev = _hqTabNavTimers.get(tabId);
    if (prev) {
        if (Array.isArray(prev)) prev.forEach(x => clearTimeout(x)); else clearTimeout(prev);
    }
    const run = async () => {
        try {
            const tab = await chrome.tabs.get(tabId);
            await syncHqLiveRedirectForTwitchTab(tabId, tab?.url || urlStr || "");
        } catch {
            await syncHqLiveRedirectForTwitchTab(tabId, urlStr || "");
        }
    };
    void run();
    const t1 = setTimeout(() => void run(), 200);
    const t2 = setTimeout(() => void run(), 900);
    _hqTabNavTimers.set(tabId, [ t1, t2 ]);
}

const HQ_TWITCH_NAV_FILTER = {
    url: [ {
        hostSuffix: "twitch.tv"
    } ]
};

function onTwitchNavigation(details) {
    if (details.frameId !== 0) return;
    scheduleHqLiveRedirectSync(details.tabId, details.url || "");
}

chrome.webNavigation.onCommitted.addListener(onTwitchNavigation, HQ_TWITCH_NAV_FILTER);

chrome.webNavigation.onHistoryStateUpdated.addListener(onTwitchNavigation, HQ_TWITCH_NAV_FILTER);

chrome.webNavigation.onCompleted.addListener(onTwitchNavigation, HQ_TWITCH_NAV_FILTER);

chrome.tabs.onRemoved.addListener(tabId => {
    const t = _hqTabNavTimers.get(tabId);
    if (t) {
        if (Array.isArray(t)) t.forEach(x => clearTimeout(x)); else clearTimeout(t);
    }
    _hqTabNavTimers.delete(tabId);
    void removeHqLiveRedirectForTab(tabId);
});

async function getTwitchAuthCookie() {
    for (const url of [ "https://www.twitch.tv", "https://twitch.tv" ]) {
        try {
            const c = await chrome.cookies.get({
                url: url,
                name: "auth-token"
            });
            if (c?.value) return c.value;
        } catch {}
    }
    return null;
}

async function registerHqMainWorldScript() {
    try {
        await chrome.scripting.unregisterContentScripts({
            ids: [ HQ_SCRIPT_ID ]
        });
    } catch {}
    await chrome.scripting.registerContentScripts([ {
        id: HQ_SCRIPT_ID,
        matches: [ "https://*.twitch.tv/*" ],
        js: [ "modules/quality-inject.js" ],
        runAt: "document_start",
        world: "MAIN"
    } ]);
}

const CHAT_IRC_SCRIPT_ID = "twixy-chat-irc-main";

async function ensureChatIrcHookRegistered() {
    try {
        const existing = await chrome.scripting.getRegisteredContentScripts({
            ids: [ CHAT_IRC_SCRIPT_ID ]
        });
        if (existing && existing.length) return;
    } catch {}
    try {
        await chrome.scripting.registerContentScripts([ {
            id: CHAT_IRC_SCRIPT_ID,
            matches: [ "https://*.twitch.tv/*" ],
            js: [ "modules/chat-irc-hook.js" ],
            runAt: "document_start",
            world: "MAIN",
            persistAcrossSessions: true
        } ]);
    } catch (err) {
        console.warn("[Twixy chat hook] register:", err?.message || err);
    }
}

chrome.runtime.onInstalled.addListener(() => {
    void ensureChatIrcHookRegistered();
});

chrome.runtime.onStartup.addListener(() => {
    void ensureChatIrcHookRegistered();
});

void ensureChatIrcHookRegistered();

async function unregisterHqMainWorldScript() {
    try {
        await chrome.scripting.unregisterContentScripts({
            ids: [ HQ_SCRIPT_ID ]
        });
    } catch {}
}

async function enableHqVodRedirectRule() {
    const auth = await getTwitchAuthCookie();
    if (!auth) {
        console.warn("[Twixy HQ] нет куки auth-token — войдите на twitch.tv в этом браузере");
        return false;
    }
    const safeAuth = encodeURIComponent(auth);
    const vodRule = {
        id: HQ_RULE_ID_VOD,
        priority: 1,
        action: {
            type: "redirect",
            redirect: {
                regexSubstitution: `${HQ_PROXY_BASE}?auth=${safeAuth}&vod_id=\\1&\\2`
            }
        },
        condition: {
            regexFilter: "^https://usher\\.ttvnw\\.net/vod/(?:v2/)?([^/?]+)\\.m3u8(?:\\?(.*))?$",
            resourceTypes: [ "xmlhttprequest", "media", "other" ]
        }
    };
    try {
        const existing = await chrome.declarativeNetRequest.getDynamicRules();
        const removeIds = existing.filter(r => r.id === HQ_RULE_ID_VOD).map(r => r.id);
        const updatePayload = {
            addRules: [ vodRule ]
        };
        if (removeIds.length) updatePayload.removeRuleIds = removeIds;
        await chrome.declarativeNetRequest.updateDynamicRules(updatePayload);
        console.log("[Twixy HQ] DNR VOD rule applied");
        return true;
    } catch (err) {
        console.error("[Twixy HQ] updateDynamicRules (VOD):", err);
        return false;
    }
}

async function disableHQRules() {
    try {
        const rules = await chrome.declarativeNetRequest.getDynamicRules();
        const removeIds = rules.filter(r => r.id === HQ_RULE_ID_LIVE_LEGACY || r.id === HQ_RULE_ID_VOD || r.id >= HQ_TAB_LIVE_RULE_ID_BASE && r.id < HQ_TAB_LIVE_RULE_ID_BASE + 2e9).map(r => r.id);
        if (removeIds.length) {
            await chrome.declarativeNetRequest.updateDynamicRules({
                removeRuleIds: removeIds
            });
        }
    } catch (err) {
        console.error("[Twixy HQ] remove dynamic rules:", err);
    }
    try {
        await removeAllHqTabLiveRedirectRules();
    } catch (err) {
        console.error("[Twixy HQ] remove session rules:", err);
    }
}

async function hqEnableAll() {
    const auth = await getTwitchAuthCookie();
    if (!auth) return {
        success: false,
        error: "no_twitch_session"
    };
    try {
        await registerHqMainWorldScript();
    } catch (err) {
        console.error("[Twixy HQ] registerContentScripts:", err);
        return {
            success: false,
            error: "script_register"
        };
    }
    const ok = await enableHqVodRedirectRule();
    if (!ok) {
        await unregisterHqMainWorldScript();
        return {
            success: false,
            error: "dnr_rules"
        };
    }
    try {
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [ HQ_RULE_ID_LIVE_LEGACY ]
        });
    } catch {}
    await removeAllHqTabLiveRedirectRules();
    try {
        const tabs = await chrome.tabs.query({
            url: [ "*://*.twitch.tv/*" ]
        });
        for (const t of tabs) {
            if (t.id != null && t.url) scheduleHqLiveRedirectSync(t.id, t.url);
        }
    } catch {}
    await chrome.storage.local.set({
        hqEnabled: true
    });
    return {
        success: true
    };
}

async function hqDisableAll() {
    await disableHQRules();
    await unregisterHqMainWorldScript();
    await chrome.storage.local.set({
        hqEnabled: false
    });
}

chrome.cookies.onChanged.addListener(changeInfo => {
    const {cookie: cookie, removed: removed} = changeInfo;
    if (!cookie || cookie.name !== "auth-token") return;
    if (!String(cookie.domain || "").includes("twitch.tv")) return;
    if (removed) return;
    void (async () => {
        try {
            const {hqEnabled: hqEnabled} = await chrome.storage.local.get("hqEnabled");
            if (!hqEnabled) return;
            await enableHqVodRedirectRule();
            try {
                const tabs = await chrome.tabs.query({
                    url: [ "*://*.twitch.tv/*" ]
                });
                for (const t of tabs) {
                    if (t.id != null && t.url) scheduleHqLiveRedirectSync(t.id, t.url);
                }
            } catch {}
        } catch {}
    })();
});

void async function restoreHqState() {
    try {
        const {hqEnabled: hqEnabled} = await chrome.storage.local.get("hqEnabled");
        if (!hqEnabled) return;
        await registerHqMainWorldScript();
        await enableHqVodRedirectRule();
        try {
            await chrome.declarativeNetRequest.updateDynamicRules({
                removeRuleIds: [ HQ_RULE_ID_LIVE_LEGACY ]
            });
        } catch {}
        await removeAllHqTabLiveRedirectRules();
        try {
            const tabs = await chrome.tabs.query({
                url: [ "*://*.twitch.tv/*" ]
            });
            for (const t of tabs) {
                if (t.id != null && t.url) scheduleHqLiveRedirectSync(t.id, t.url);
            }
        } catch {}
    } catch (e) {
        console.warn("[Twixy HQ] restore:", e);
    }
}();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message.action) {
      case "twitch_authorize":
        {
            const forceInteractive = !!message.forceInteractive;
            authorizeTwitch({
                forceInteractive: forceInteractive
            }).then(result => {
                if (result) {
                    console.log("[Twixy BG] Auth success, token starts:", result.serverToken?.slice(0, 20));
                    sendResponse({
                        success: true,
                        serverToken: result.serverToken
                    });
                } else {
                    const networkError = Date.now() - _lastAuthFetchErrorAt < 15e3;
                    if (networkError) {
                        console.warn("[Twixy BG] Auth failed due to /auth/twitch network/429 — keep user state");
                    } else {
                        console.error("[Twixy BG] Auth failed");
                    }
                    sendResponse({
                        success: false,
                        networkError: networkError,
                        error: networkError ? "Network error" : "Auth failed"
                    });
                }
            }).catch(err => {
                console.error("[Twixy BG] authorizeTwitch threw:", err?.message || err);
                sendResponse({
                    success: false,
                    error: err?.message || "Auth failed"
                });
            });
            return true;
        }

      case "get_avatar":
        {
            const login = normalizeLogin(message.login);
            if (!login) {
                sendResponse({
                    url: null
                });
                return false;
            }
            const cachedUrl = getCachedAvatar(login);
            if (cachedUrl) {
                sendResponse({
                    url: cachedUrl
                });
                return false;
            }
            const pending = _avatarPending.get(login);
            if (pending) {
                pending.then(url => sendResponse({
                    url: url ?? null
                })).catch(() => sendResponse({
                    url: null
                }));
                return true;
            }
            const request = new Promise(resolve => {
                chrome.storage.local.get("twitchToken", ({twitchToken: twitchToken}) => {
                    const tokenToUse = twitchToken || _twitchToken;
                    fetchAvatarUrl(login, tokenToUse).then(resolve).catch(() => resolve(null));
                });
            }).finally(() => {
                _avatarPending.delete(login);
            });
            _avatarPending.set(login, request);
            request.then(url => sendResponse({
                url: url ?? null
            })).catch(() => sendResponse({
                url: null
            }));
            return true;
        }

      case "server_request":
        {
            const {method: method, path: reqPath, body: body} = message;
            const PUBLIC_PATHS = [ /^\/changelog($|\?)/ ];
            const isPublic = PUBLIC_PATHS.some(re => re.test(reqPath));
            async function doRequest(token) {
                const headers = {
                    "Content-Type": "application/json"
                };
                if (token) headers.Authorization = `Bearer ${token}`;
                const r = await fetchWithTimeout(`${SERVER_BASE}${reqPath}`, {
                    method: method,
                    headers: headers,
                    body: body ? JSON.stringify(body) : undefined
                }, 12e3);
                console.log(`[Twixy BG] ${method} ${reqPath} →`, r.status);
                return r;
            }
            (async () => {
                try {
                    const {serverToken: serverToken} = await chrome.storage.local.get("serverToken");
                    if (!serverToken && !isPublic) {
                        sendResponse({
                            success: false,
                            unauthorized: true
                        });
                        return;
                    }
                    let r;
                    try {
                        r = await doRequest(serverToken);
                    } catch (netErr) {
                        console.warn(`[Twixy BG] ${method} ${reqPath} network error:`, netErr?.message || netErr);
                        sendResponse({
                            success: false,
                            networkError: true,
                            error: String(netErr?.message || netErr)
                        });
                        return;
                    }
                    if (r.status === 429) {
                        let data = null;
                        try {
                            data = await r.json();
                        } catch {}
                        sendResponse(data ?? {
                            success: false,
                            error: "Too many requests, slow down.",
                            retryAfterMs: 3e4
                        });
                        return;
                    }
                    if (r.status === 401) {
                        console.log("[Twixy BG] 401 — attempting token refresh");
                        const newToken = await refreshServerToken();
                        if (newToken) {
                            try {
                                r = await doRequest(newToken);
                            } catch (netErr) {
                                console.warn(`[Twixy BG] ${method} ${reqPath} retry network error:`, netErr?.message || netErr);
                                sendResponse({
                                    success: false,
                                    networkError: true
                                });
                                return;
                            }
                        } else {
                            sendResponse({
                                success: false,
                                unauthorized: true
                            });
                            return;
                        }
                    }
                    if (r.status === 401) {
                        sendResponse({
                            success: false,
                            unauthorized: true
                        });
                        return;
                    }
                    let data = null;
                    try {
                        data = await r.json();
                    } catch {}
                    console.log("[Twixy BG] response:", data);
                    sendResponse(data ?? {
                        success: r.ok
                    });
                } catch (err) {
                    console.error("[Twixy BG] fetch error:", err);
                    sendResponse({
                        success: false,
                        error: err?.toString?.() || "Internal error"
                    });
                }
            })();
            return true;
        }

      case "twitch_follow":
        {
            authorizeTwitch().then(({twitchToken: twitchToken} = {}) => {
                if (!twitchToken) return sendResponse({
                    success: false,
                    error: "Auth failed"
                });
                fetch(`${TWITCH_API}/users?login=${encodeURIComponent(message.username)}`, {
                    headers: {
                        Authorization: `Bearer ${twitchToken}`,
                        "Client-Id": CLIENT_ID
                    }
                }).then(r => r.json()).then(data => {
                    const user = data.data?.[0];
                    if (user) {
                        if (user.login && user.profile_image_url) {
                            setCachedAvatar(user.login, user.profile_image_url);
                        }
                        sendResponse({
                            success: true,
                            targetUser: user
                        });
                    } else {
                        sendResponse({
                            success: false,
                            error: "User not found"
                        });
                    }
                }).catch(e => sendResponse({
                    success: false,
                    error: e.toString()
                }));
            });
            return true;
        }

      case "twitch_search":
        {
            authorizeTwitch().then(({twitchToken: twitchToken} = {}) => {
                if (!twitchToken) return sendResponse({
                    success: false,
                    error: "Auth failed"
                });
                fetch(`${TWITCH_API}/search/channels?query=${encodeURIComponent(message.query)}`, {
                    headers: {
                        Authorization: `Bearer ${twitchToken}`,
                        "Client-Id": CLIENT_ID
                    }
                }).then(r => r.json()).then(data => {
                    const results = (data.data || []).map(ch => {
                        if (ch.broadcaster_login && ch.thumbnail_url) {
                            setCachedAvatar(ch.broadcaster_login, ch.thumbnail_url);
                        }
                        return {
                            display_name: ch.display_name,
                            broadcaster_login: ch.broadcaster_login,
                            thumbnail_url: ch.thumbnail_url || ""
                        };
                    });
                    sendResponse({
                        success: true,
                        results: results
                    });
                }).catch(e => sendResponse({
                    success: false,
                    error: e.toString()
                }));
            });
            return true;
        }

      case "twitch_followage":
        {
            (async () => {
                try {
                    const viewerId = String(message.viewerId || "").trim();
                    const broadcasterLogin = normalizeLogin(message.broadcasterLogin);
                    if (!viewerId || !broadcasterLogin) {
                        return sendResponse({
                            success: false,
                            error: "invalid_args"
                        });
                    }
                    const {twitchToken: storedTok} = await chrome.storage.local.get("twitchToken");
                    let twitchToken = storedTok || _twitchToken;
                    if (!twitchToken) {
                        const auth = await authorizeTwitch();
                        twitchToken = auth?.twitchToken || null;
                    }
                    if (!twitchToken) {
                        return sendResponse({
                            success: false,
                            error: "no_session"
                        });
                    }
                    const headers = {
                        Authorization: `Bearer ${twitchToken}`,
                        "Client-Id": CLIENT_ID
                    };
                    const userResp = await fetch(`${TWITCH_API}/users?login=${encodeURIComponent(broadcasterLogin)}`, {
                        headers: headers
                    });
                    if (!userResp.ok) {
                        return sendResponse({
                            success: false,
                            error: "broadcaster_lookup_failed"
                        });
                    }
                    const userData = await userResp.json().catch(() => null);
                    const broadcaster = userData?.data?.[0];
                    if (!broadcaster?.id) {
                        return sendResponse({
                            success: false,
                            error: "broadcaster_not_found"
                        });
                    }
                    const url = `${TWITCH_API}/channels/followed?user_id=${encodeURIComponent(viewerId)}&broadcaster_id=${encodeURIComponent(broadcaster.id)}`;
                    const followResp = await fetch(url, {
                        headers: headers
                    });
                    if (followResp.status === 401) {
                        return sendResponse({
                            success: false,
                            error: "unauthorized"
                        });
                    }
                    if (followResp.status === 403) {
                        return sendResponse({
                            success: false,
                            error: "scope_missing"
                        });
                    }
                    if (!followResp.ok) {
                        return sendResponse({
                            success: false,
                            error: `helix_${followResp.status}`
                        });
                    }
                    const followData = await followResp.json().catch(() => null);
                    const row = followData?.data?.[0];
                    if (!row?.followed_at) {
                        return sendResponse({
                            success: false,
                            error: "not_following"
                        });
                    }
                    sendResponse({
                        success: true,
                        followed_at: row.followed_at,
                        broadcaster_id: broadcaster.id,
                        broadcaster_login: broadcaster.login,
                        broadcaster_display_name: broadcaster.display_name
                    });
                } catch (err) {
                    console.error("[Twixy BG] twitch_followage:", err);
                    sendResponse({
                        success: false,
                        error: err?.message || "fetch_error"
                    });
                }
            })();
            return true;
        }

      case "refresh_token":
        {
            refreshServerToken().then(token => {
                sendResponse({
                    success: !!token,
                    token: token ?? null
                });
            }).catch(err => {
                console.error("[Twixy BG] refresh_token failed:", err);
                sendResponse({
                    success: false,
                    error: err?.message || "Refresh failed"
                });
            });
            return true;
        }

      case "get_browser":
        {
            sendResponse({
                browser: BROWSER_KIND
            });
            return false;
        }

      case "hq_enable":
        {
            hqEnableAll().then(sendResponse).catch(err => sendResponse({
                success: false,
                error: err?.message || "hq_enable"
            }));
            return true;
        }

      case "hq_disable":
        {
            hqDisableAll().then(() => sendResponse({
                success: true
            })).catch(err => sendResponse({
                success: false,
                error: err?.message || "hq_disable"
            }));
            return true;
        }

      case "hq_status":
        {
            void (async () => {
                try {
                    const [{hqEnabled: hqEnabled}, dynamicRules, sessionRules] = await Promise.all([ chrome.storage.local.get("hqEnabled"), chrome.declarativeNetRequest.getDynamicRules(), chrome.declarativeNetRequest.getSessionRules() ]);
                    const tabLiveSession = sessionRules.some(r => r.id >= HQ_TAB_LIVE_RULE_ID_BASE && r.id < HQ_TAB_LIVE_RULE_ID_BASE + 2e9);
                    const hasRules = dynamicRules.some(r => r.id === HQ_RULE_ID_VOD || r.id === HQ_RULE_ID_LIVE_LEGACY || r.id >= HQ_TAB_LIVE_RULE_ID_BASE && r.id < HQ_TAB_LIVE_RULE_ID_BASE + 2e9);
                    sendResponse({
                        enabled: Boolean(hqEnabled && (hasRules || tabLiveSession))
                    });
                } catch (err) {
                    sendResponse({
                        enabled: false,
                        error: err?.message
                    });
                }
            })();
            return true;
        }

      default:
        return false;
    }
});