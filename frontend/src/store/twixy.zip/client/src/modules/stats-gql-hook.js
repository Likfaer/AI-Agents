(function() {
    "use strict";
    if (window.__twixyStatsFetchHook) return;
    window.__twixyStatsFetchHook = true;
    var orig = window.fetch.bind(window);
    function gqlUrl(input) {
        if (typeof input === "string") return input;
        if (typeof Request !== "undefined" && input instanceof Request) return input.url || "";
        return String(input || "");
    }
    function postGqlPayload(urlStr, reqBody, res) {
        try {
            if (urlStr.indexOf("gql.twitch.tv") === -1 || !res || !res.clone) return;
            res.clone().json().then(function(json) {
                try {
                    window.postMessage({
                        source: "twixy-stats",
                        type: "gql",
                        url: urlStr,
                        reqBody: reqBody,
                        json: json
                    }, "*");
                } catch (e) {}
            }).catch(function() {});
        } catch (e) {}
    }
    window.fetch = function(input, init) {
        var urlStr = gqlUrl(input);
        if (typeof Request !== "undefined" && input instanceof Request) {
            if (urlStr.indexOf("gql.twitch.tv") !== -1) {
                var method = init && init.method || input.method;
                if (method !== "GET" && method !== "HEAD") {
                    return input.clone().text().then(function(bodyText) {
                        var reqBody = null;
                        try {
                            reqBody = JSON.parse(bodyText);
                        } catch (e) {}
                        return orig(input, init).then(function(res) {
                            postGqlPayload(urlStr, reqBody, res);
                            return res;
                        });
                    }).catch(function() {
                        return orig(input, init);
                    });
                }
            }
            return orig(input, init);
        }
        var reqBody = null;
        if (init && init.body != null) {
            try {
                reqBody = typeof init.body === "string" ? JSON.parse(init.body) : JSON.parse(String(init.body));
            } catch (e) {}
        }
        return orig.apply(null, arguments).then(function(res) {
            postGqlPayload(urlStr, reqBody, res);
            return res;
        });
    };
})();