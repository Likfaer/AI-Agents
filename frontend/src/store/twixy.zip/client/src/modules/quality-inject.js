(function() {
    "use strict";
    if (window.__TWIXY_HQ_INJECTED__) return;
    window.__TWIXY_HQ_INJECTED__ = true;
    const TARGET_PLAYER_TYPE = "site";
    const _realFetch = window.fetch.bind(window);
    function isChannelVisiblyOffline() {
        try {
            if (document.querySelector('[data-a-target="host-channel-content"]')) return false;
            if (document.querySelector('[data-a-target="player-overlay-offline"]')) return true;
            if (document.querySelector('[data-a-target="off-line-banner"]')) return true;
            if (document.querySelector('[data-a-target="channel-header-offline"]')) return true;
        } catch {}
        return false;
    }
    function variablesPatchable(v) {
        if (!v || typeof v !== "object") return false;
        if (v.isVod === true) return false;
        if (v.vodID) return false;
        if (v.isLive === false) return false;
        if (!v.playerType) return false;
        if (v.playerType === TARGET_PLAYER_TYPE) return false;
        return true;
    }
    function shouldPatchToSite(info) {
        if (isChannelVisiblyOffline()) return false;
        return Boolean(info.hasLiveCandidate);
    }
    function analyzePlaybackBody(bodyStr) {
        if (!bodyStr || typeof bodyStr !== "string" || !bodyStr.includes("PlaybackAccessToken")) {
            return null;
        }
        let parsed;
        try {
            parsed = JSON.parse(bodyStr);
        } catch {
            return null;
        }
        const isSingle = !Array.isArray(parsed);
        const items = Array.isArray(parsed) ? parsed : [ parsed ];
        const hasLiveCandidate = items.some(x => variablesPatchable(x?.variables));
        return {
            parsed: parsed,
            items: items,
            isSingle: isSingle,
            hasLiveCandidate: hasLiveCandidate
        };
    }
    function applyPatch(items, isSingle) {
        let changed = false;
        for (const item of items) {
            if (variablesPatchable(item?.variables)) {
                item.variables.playerType = TARGET_PLAYER_TYPE;
                changed = true;
            }
        }
        if (!changed) return null;
        return JSON.stringify(isSingle ? items[0] : items);
    }
    function fetchPatched(input, init, bodyText) {
        const info = analyzePlaybackBody(bodyText);
        if (!info || !info.hasLiveCandidate) {
            return _realFetch(input, init);
        }
        if (!shouldPatchToSite(info)) {
            return _realFetch(input, init);
        }
        const newBody = applyPatch(info.items, info.isSingle);
        if (newBody == null) {
            return _realFetch(input, init);
        }
        if (typeof Request !== "undefined" && input instanceof Request) {
            return _realFetch(new Request(input, {
                body: newBody
            }));
        }
        return _realFetch(input, {
            ...init || {},
            body: newBody
        });
    }
    window.fetch = function(input, init) {
        try {
            if (typeof Request !== "undefined" && input instanceof Request) {
                const urlStr = input.url;
                if (urlStr.includes("gql.twitch.tv")) {
                    const method = init && init.method || input.method;
                    if (method !== "GET" && method !== "HEAD") {
                        return input.clone().text().then(bodyText => fetchPatched(input, init, bodyText)).catch(() => _realFetch(input, init));
                    }
                }
                return _realFetch(input, init);
            }
            const urlStr = typeof input === "string" ? input : String(input);
            if (urlStr.includes("gql.twitch.tv")) {
                const i = init || {};
                if (i.body && typeof i.body === "string") {
                    return fetchPatched(input, i, i.body);
                }
            }
        } catch (_) {}
        return _realFetch(input, init);
    };
})();