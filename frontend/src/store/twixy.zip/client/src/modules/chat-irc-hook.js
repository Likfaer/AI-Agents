(function() {
    "use strict";
    if (window.__twixyChatIrcHook) return;
    window.__twixyChatIrcHook = true;
    var RealWS = window.WebSocket;
    if (typeof RealWS !== "function") return;
    function isTwitchChatUrl(u) {
        try {
            var s = typeof u === "string" ? u : u && u.toString && u.toString() || "";
            return /(^|\.)chat\.twitch\.tv(\/|:|$)/i.test(s) || /irc-ws\.chat\.twitch\.tv/i.test(s);
        } catch (e) {
            return false;
        }
    }
    function parseIrcTags(tagsStr) {
        var map = {};
        if (!tagsStr) return map;
        var parts = tagsStr.split(";");
        for (var i = 0; i < parts.length; i++) {
            var kv = parts[i];
            var eq = kv.indexOf("=");
            if (eq === -1) map[kv] = ""; else map[kv.substring(0, eq)] = kv.substring(eq + 1);
        }
        return map;
    }
    function parsePrivmsg(line) {
        if (!line || line.indexOf(" PRIVMSG #") === -1) return null;
        var i = 0;
        var tags = {};
        if (line.charCodeAt(0) === 64) {
            var sp = line.indexOf(" ");
            if (sp === -1) return null;
            tags = parseIrcTags(line.substring(1, sp));
            i = sp + 1;
        }
        if (line.charCodeAt(i) !== 58) return null;
        var sp2 = line.indexOf(" ", i);
        if (sp2 === -1) return null;
        var prefix = line.substring(i + 1, sp2);
        var bang = prefix.indexOf("!");
        var login = bang === -1 ? prefix : prefix.substring(0, bang);
        i = sp2 + 1;
        if (line.substr(i, 8) !== "PRIVMSG ") return null;
        i += 8;
        if (line.charCodeAt(i) !== 35) return null;
        var sp3 = line.indexOf(" ", i);
        if (sp3 === -1) return null;
        var channel = line.substring(i + 1, sp3);
        var id = tags.id || "";
        if (!id) return null;
        return {
            id: String(id),
            login: String(login || "").toLowerCase(),
            channel: String(channel || "").toLowerCase()
        };
    }
    function handleFrame(data) {
        if (typeof data !== "string") return;
        if (data.indexOf("PRIVMSG") === -1) return;
        var lines = data.split("\r\n");
        for (var i = 0; i < lines.length; i++) {
            var parsed = parsePrivmsg(lines[i]);
            if (!parsed) continue;
            try {
                window.postMessage({
                    source: "twixy-chat-irc",
                    type: "privmsg",
                    id: parsed.id,
                    login: parsed.login,
                    channel: parsed.channel
                }, "*");
            } catch (e) {}
        }
    }
    function attach(ws) {
        try {
            ws.addEventListener("message", function(evt) {
                try {
                    handleFrame(evt && evt.data);
                } catch (e) {}
            });
        } catch (e) {}
    }
    function PatchedWS(url, protocols) {
        var ws = protocols === undefined ? new RealWS(url) : new RealWS(url, protocols);
        if (isTwitchChatUrl(url)) attach(ws);
        return ws;
    }
    PatchedWS.prototype = RealWS.prototype;
    try {
        PatchedWS.CONNECTING = RealWS.CONNECTING;
        PatchedWS.OPEN = RealWS.OPEN;
        PatchedWS.CLOSING = RealWS.CLOSING;
        PatchedWS.CLOSED = RealWS.CLOSED;
    } catch (e) {}
    try {
        window.WebSocket = PatchedWS;
    } catch (e) {}
})();