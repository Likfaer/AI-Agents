"use strict";

window.TWIXY.followage = {
    _button: null,
    _popup: null,
    _observer: null,
    _lastSlug: null,
    _cache: new Map,
    _CACHE_TTL_MS: 6e4,
    _outsideClickBound: false,
    _currentRequestKey: null,
    _url(path) {
        try {
            return chrome.runtime.getURL(path);
        } catch {
            return "";
        }
    },
    _slugFromPath() {
        const p = location.pathname.replace(/^\//, "");
        return window.TWIXY.getStreamerFromPath(p);
    },
    _findHost() {
        const sec = document.getElementById("live-channel-stream-information");
        if (!sec) return null;
        const shareBtn = sec.querySelector('button[data-a-target="share-button"]');
        if (shareBtn) {
            return shareBtn.parentElement;
        }
        return null;
    },
    _createIconButton() {
        const t = window.TWIXY.i18n;
        const btn = document.createElement("button");
        btn.id = "twixy-followage-btn";
        btn.type = "button";
        btn.className = "twixy-followage-btn twixy-has-tip";
        btn.setAttribute("aria-label", t.t("followageButtonLabel"));
        btn.innerHTML = `\n      <span class="twixy-followage-btn-inner">\n        <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">\n          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>\n        </svg>\n      </span>\n      <span class="twixy-tip-popup" role="tooltip">${escapeHTML(t.t("followageTip"))}</span>\n    `;
        btn.addEventListener("click", e => {
            e.preventDefault();
            e.stopPropagation();
            this._togglePopup();
        });
        return btn;
    },
    _inject() {
        if (!window.TWIXY.settings.getBool("twixy_followage_btn_show")) return;
        const host = this._findHost();
        if (!host) return;
        if (document.getElementById("twixy-followage-btn")) return;
        const btn = this._createIconButton();
        host.insertBefore(btn, host.firstChild);
        this._button = btn;
    },
    _remove() {
        document.getElementById("twixy-followage-btn")?.remove();
        this._button = null;
        this._closePopup();
    },
    _togglePopup() {
        if (this._popup) {
            this._closePopup();
            return;
        }
        this._openPopup();
    },
    _closePopup() {
        this._popup?.remove();
        this._popup = null;
        if (this._outsideClickBound) {
            document.removeEventListener("mousedown", this._boundOutsideClick, true);
            document.removeEventListener("keydown", this._boundEscKey, true);
            this._outsideClickBound = false;
        }
    },
    _onOutsideClick(e) {
        if (!this._popup) return;
        if (this._popup.contains(e.target)) return;
        if (this._button && this._button.contains(e.target)) return;
        this._closePopup();
    },
    _onEscKey(e) {
        if (e.key === "Escape") this._closePopup();
    },
    async _openPopup() {
        const btn = this._button;
        if (!btn) return;
        const t = window.TWIXY.i18n;
        const slug = this._slugFromPath();
        const popup = document.createElement("div");
        popup.className = "twixy-followage-popup";
        popup.innerHTML = `\n      <div class="twixy-followage-popup-head">\n        <img src="${this._url("icons/menu_icon.svg")}" alt="" class="twixy-followage-popup-brand">\n        <span class="twixy-followage-popup-title">Twixy</span>\n        <button class="twixy-followage-popup-close" type="button" aria-label="${escapeHTML(t.t("close"))}">&times;</button>\n      </div>\n      <div class="twixy-followage-popup-body">\n        <div class="twixy-followage-popup-spinner"><div></div><div></div><div></div></div>\n      </div>\n    `;
        document.body.appendChild(popup);
        this._popup = popup;
        popup.querySelector(".twixy-followage-popup-close")?.addEventListener("click", () => this._closePopup());
        this._positionPopup();
        if (!this._outsideClickBound) {
            this._boundOutsideClick = e => this._onOutsideClick(e);
            this._boundEscKey = e => this._onEscKey(e);
            document.addEventListener("mousedown", this._boundOutsideClick, true);
            document.addEventListener("keydown", this._boundEscKey, true);
            this._outsideClickBound = true;
        }
        if (!slug) {
            this._renderPopupError(t.t("followageNoChannel"));
            return;
        }
        await this._renderPopupFor(slug);
    },
    _positionPopup() {
        const btn = this._button;
        const popup = this._popup;
        if (!btn || !popup) return;
        const rect = btn.getBoundingClientRect();
        const pw = popup.offsetWidth || 280;
        let left = rect.right - pw;
        if (left < 8) left = 8;
        if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
        const top = rect.bottom + 10;
        popup.style.left = `${Math.round(left)}px`;
        popup.style.top = `${Math.round(top)}px`;
    },
    _renderPopupError(message) {
        if (!this._popup) return;
        const body = this._popup.querySelector(".twixy-followage-popup-body");
        if (!body) return;
        body.innerHTML = `<div class="twixy-followage-popup-empty">${escapeHTML(message)}</div>`;
    },
    async _renderPopupFor(slug) {
        const t = window.TWIXY.i18n;
        const viewer = await this._getMyTwitchId();
        if (!viewer) {
            this._renderPopupError(t.t("followageNeedTwitchLogin"));
            return;
        }
        const cacheKey = `${viewer}:${slug.toLowerCase()}`;
        this._currentRequestKey = cacheKey;
        const cached = this._cache.get(cacheKey);
        if (cached && Date.now() - cached.ts < this._CACHE_TTL_MS) {
            this._renderPopupResult(slug, cached.data);
            return;
        }
        try {
            const resp = await window.TWIXY.bgMessage({
                action: "twitch_followage",
                viewerId: viewer,
                broadcasterLogin: slug
            });
            if (this._currentRequestKey !== cacheKey) return;
            if (!resp?.success) {
                const err = resp?.error || "unknown";
                const map = {
                    not_following: t.t("followageNotFollowing"),
                    broadcaster_not_found: t.t("followageBroadcasterNotFound"),
                    no_session: t.t("followageNeedTwitchLogin"),
                    scope_missing: t.t("followageScopeMissing")
                };
                this._renderPopupError(map[err] || t.t("followageLoadError"));
                return;
            }
            const data = {
                followed_at: resp.followed_at,
                streamer: slug
            };
            this._cache.set(cacheKey, {
                data: data,
                ts: Date.now()
            });
            this._renderPopupResult(slug, data);
        } catch (err) {
            console.warn("[Twixy] followage error:", err);
            this._renderPopupError(t.t("followageLoadError"));
        }
    },
    async _getMyTwitchId() {
        try {
            const store = await window.TWIXY.storageGet([ "twitchUser" ]);
            const id = store?.twitchUser?.id;
            return id ? String(id) : "";
        } catch {
            return "";
        }
    },
    _pad(n) {
        return String(Math.max(0, Math.floor(n))).padStart(2, "0");
    },
    _formatFollowedAt(iso) {
        try {
            const d = new Date(iso);
            if (Number.isNaN(d.getTime())) return "";
            const lang = window.TWIXY.i18n.lang === "ru" ? "ru-RU" : "en-US";
            return d.toLocaleString(lang, {
                year: "numeric",
                month: "long",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            });
        } catch {
            return "";
        }
    },
    _formatDurationParts(fromIso) {
        const t = window.TWIXY.i18n;
        const from = new Date(fromIso);
        if (Number.isNaN(from.getTime())) return null;
        const now = new Date;
        let ms = Math.max(0, now - from);
        const days = Math.floor(ms / 864e5);
        ms -= days * 864e5;
        const hours = Math.floor(ms / 36e5);
        ms -= hours * 36e5;
        const minutes = Math.floor(ms / 6e4);
        let years = 0;
        let remainingDays = days;
        {
            const tmp = new Date(from.getTime());
            while (true) {
                const next = new Date(tmp.getTime());
                next.setFullYear(next.getFullYear() + 1);
                if (next.getTime() > now.getTime()) break;
                years += 1;
                tmp.setFullYear(tmp.getFullYear() + 1);
            }
            remainingDays = Math.floor((now - tmp) / 864e5);
        }
        let months = 0;
        {
            const tmp = new Date(from.getTime());
            tmp.setFullYear(tmp.getFullYear() + years);
            while (true) {
                const next = new Date(tmp.getTime());
                next.setMonth(next.getMonth() + 1);
                if (next.getTime() > now.getTime()) break;
                months += 1;
                tmp.setMonth(tmp.getMonth() + 1);
            }
            remainingDays = Math.floor((now - tmp) / 864e5);
        }
        return {
            years: years,
            months: months,
            days: remainingDays,
            hours: hours,
            minutes: minutes,
            totalDays: days
        };
    },
    _renderDurationLine(parts) {
        const t = window.TWIXY.i18n;
        if (!parts) return "";
        const pieces = [];
        if (parts.years > 0) pieces.push(`${parts.years} ${t.t(parts.years === 1 ? "followageYear" : "followageYears")}`);
        if (parts.months > 0) pieces.push(`${parts.months} ${t.t(parts.months === 1 ? "followageMonth" : "followageMonths")}`);
        if (parts.days > 0 || !parts.years && !parts.months) {
            pieces.push(`${parts.days} ${t.t(parts.days === 1 ? "followageDay" : "followageDays")}`);
        }
        return pieces.join(" · ");
    },
    _renderPopupResult(slug, data) {
        if (!this._popup) return;
        const t = window.TWIXY.i18n;
        const body = this._popup.querySelector(".twixy-followage-popup-body");
        if (!body) return;
        if (!data?.followed_at) {
            body.innerHTML = `<div class="twixy-followage-popup-empty">${escapeHTML(t.t("followageNotFollowing"))}</div>`;
            return;
        }
        const parts = this._formatDurationParts(data.followed_at);
        const durationHuman = this._renderDurationLine(parts);
        const totalDays = parts ? parts.totalDays : 0;
        const sinceStr = this._formatFollowedAt(data.followed_at);
        body.innerHTML = `\n      <div class="twixy-followage-hero">\n        <div class="twixy-followage-hero-ico">\n          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">\n            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>\n          </svg>\n        </div>\n        <div class="twixy-followage-hero-text">\n          <div class="twixy-followage-hero-sub">${escapeHTML(t.t("followageYouFollow"))}</div>\n          <div class="twixy-followage-hero-name">${escapeHTML(slug)}</div>\n        </div>\n      </div>\n      <div class="twixy-followage-duration">${escapeHTML(durationHuman)}</div>\n      <div class="twixy-followage-rows">\n        <div class="twixy-followage-row">\n          <span class="twixy-followage-row-label">${escapeHTML(t.t("followageSince"))}</span>\n          <span class="twixy-followage-row-value">${escapeHTML(sinceStr)}</span>\n        </div>\n        <div class="twixy-followage-row">\n          <span class="twixy-followage-row-label">${escapeHTML(t.t("followageTotalDays"))}</span>\n          <span class="twixy-followage-row-value">${totalDays}</span>\n        </div>\n      </div>\n    `;
        this._positionPopup();
    },
    _onLocationChange() {
        const slug = this._slugFromPath();
        if (slug === this._lastSlug) return;
        this._lastSlug = slug;
        this._closePopup();
        if (!slug) {
            this._remove();
            return;
        }
        this._remove();
        this._ensureInjected();
    },
    _ensureInjected() {
        if (!this._slugFromPath()) return;
        this._inject();
    },
    init() {
        this._lastSlug = this._slugFromPath();
        this._ensureInjected();
        this._observer = new MutationObserver(() => {
            if (!this._slugFromPath()) {
                this._remove();
                return;
            }
            if (!document.getElementById("twixy-followage-btn")) {
                this._ensureInjected();
            }
        });
        this._observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        window.addEventListener("locationchange", () => this._onLocationChange());
        window.addEventListener("resize", () => this._positionPopup());
        window.addEventListener("scroll", () => this._positionPopup(), true);
        window.addEventListener("twixy:langChanged", () => {
            this._remove();
            this._ensureInjected();
        });
        window.addEventListener("twixy:settingChanged", e => {
            if (e?.detail?.key !== "twixy_followage_btn_show") return;
            if (window.TWIXY.settings.getBool("twixy_followage_btn_show")) this._ensureInjected(); else this._remove();
        });
    }
};