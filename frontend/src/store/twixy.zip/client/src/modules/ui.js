"use strict";

window.TWIXY.ui = {
    _avatarCache: {},
    _avatarPromises: {},
    _friendTipPopup(text) {
        return `<span class="twixy-tip-popup" role="tooltip">${escapeHTML(text)}</span>`;
    },
    _url(path) {
        try {
            return chrome.runtime.getURL(path);
        } catch {
            return "";
        }
    },
    _defaultAvatarUrl() {
        return this._url("icons/default_avatar.svg");
    },
    _normalizeLogin(login) {
        return String(login ?? "").trim().toLowerCase();
    },
    _getCachedAvatar(login) {
        const key = this._normalizeLogin(login);
        if (key && this._avatarCache[key]) {
            return this._avatarCache[key];
        }
        return this._defaultAvatarUrl();
    },
    async _getAvatar(login) {
        const key = this._normalizeLogin(login);
        if (!key) return this._defaultAvatarUrl();
        if (this._avatarCache[key]) {
            return this._avatarCache[key];
        }
        if (this._avatarPromises[key]) {
            return this._avatarPromises[key];
        }
        this._avatarPromises[key] = window.TWIXY.bgMessage({
            action: "get_avatar",
            login: key
        }).then(resp => {
            const url = resp?.url || this._defaultAvatarUrl();
            if (resp?.url) {
                this._avatarCache[key] = resp.url;
            }
            delete this._avatarPromises[key];
            return url;
        }).catch(() => {
            delete this._avatarPromises[key];
            return this._defaultAvatarUrl();
        });
        return this._avatarPromises[key];
    },
    _applyAvatar(imgEl, login) {
        if (!imgEl) return;
        const key = this._normalizeLogin(login);
        if (!key) {
            imgEl.src = this._defaultAvatarUrl();
            return;
        }
        imgEl.dataset.avatarLogin = key;
        const cached = this._avatarCache[key];
        if (cached) {
            if (imgEl.src !== cached) {
                imgEl.src = cached;
            }
            return;
        }
        this._getAvatar(key).then(url => {
            if (!imgEl.isConnected) return;
            if ((imgEl.dataset.avatarLogin || "") !== key) return;
            if (url && imgEl.src !== url) {
                imgEl.src = url;
            }
        });
    },
    _isModeratorViewPath() {
        return /^\/moderator\/[a-z0-9_]{3,25}/i.test(location.pathname || "");
    },
    _findModViewChannelLink() {
        return document.querySelector('a[aria-label="Перейти на страницу канала"],' + 'a[aria-label="Go to channel page"],' + 'a[aria-label="Go to channel"]');
    },
    _injectModViewButton() {
        if (!this._isModeratorViewPath()) {
            document.getElementById("twixy-modview-dock-slot")?.remove();
            return;
        }
        if (document.getElementById("twixy-modview-dock-slot")) return;
        if (document.getElementById("twixy-settings-button")) return;
        const channelLink = this._findModViewChannelLink();
        if (!channelLink || !channelLink.isConnected) return;
        const row = channelLink.closest(".cVSGvQ") || channelLink.parentElement;
        if (!row || !row.parentNode) return;
        const wrap = document.createElement("div");
        wrap.id = "twixy-modview-dock-slot";
        wrap.className = row.className;
        Object.assign(wrap.style, {
            display: "flex",
            justifyContent: "center",
            width: "100%"
        });
        const inner = document.createElement("div");
        inner.className = channelLink.parentElement?.className || "";
        const btn = document.createElement("button");
        btn.type = "button";
        btn.id = "twixy-settings-button";
        btn.className = channelLink.className;
        btn.setAttribute("aria-label", window.TWIXY.i18n.t("modViewTwixyMenu"));
        const origFig = channelLink.querySelector("div.ButtonIconFigure-sc-1emm8lf-0");
        const origWrap = channelLink.querySelector("div.ScSvgWrapper-sc-wkgzod-0");
        const fig = document.createElement("div");
        fig.className = origFig?.className || "ButtonIconFigure-sc-1emm8lf-0";
        Object.assign(fig.style, {
            width: "24px",
            height: "24px",
            transform: "scale(1.2)",
            transformOrigin: "center"
        });
        const w = document.createElement("div");
        w.className = origWrap?.className || "ScSvgWrapper-sc-wkgzod-0";
        Object.assign(w.style, {
            width: "24px",
            height: "24px"
        });
        const img = document.createElement("img");
        img.src = this._url("icons/menu_icon.svg");
        img.alt = "Twixy";
        Object.assign(img.style, {
            width: "100%",
            height: "100%",
            objectFit: "contain"
        });
        w.appendChild(img);
        fig.appendChild(w);
        btn.appendChild(fig);
        inner.appendChild(btn);
        wrap.appendChild(inner);
        row.parentNode.insertBefore(wrap, row);
        btn.addEventListener("click", () => {
            btn.classList.remove("twixy-has-notif");
            this._togglePanel();
        });
    },
    _injectButton() {
        if (document.getElementById("twixy-nav-item")) return;
        if (this._isModeratorViewPath()) return;
        const topNav = document.querySelector('nav[aria-label="Top Navigation"]') || document.querySelector('nav[aria-label="Верхняя навигация"]') || document.querySelector(".top-nav__menu");
        if (!topNav) return;
        const notifBtn = Array.from(topNav.querySelectorAll("button[aria-label]")).find(btn => /notification|уведомлен/i.test(btn.getAttribute("aria-label") || ""));
        if (!notifBtn) return;
        const notifNavItem = notifBtn.closest("div.InjectLayout-sc-1i43xsx-0") || notifBtn.parentElement?.parentElement;
        if (!notifNavItem) return;
        const nav = document.createElement("div");
        nav.id = "twixy-nav-item";
        nav.className = notifNavItem.className;
        const btn = document.createElement("button");
        btn.id = "twixy-settings-button";
        btn.className = notifBtn.className;
        btn.setAttribute("aria-label", "Twixy Menu");
        const origFig = notifBtn.querySelector("div.ButtonIconFigure-sc-1emm8lf-0");
        const origWrap = notifBtn.querySelector("div.ScSvgWrapper-sc-wkgzod-0");
        const fig = document.createElement("div");
        fig.className = origFig?.className || "ButtonIconFigure-sc-1emm8lf-0";
        Object.assign(fig.style, {
            width: "24px",
            height: "24px",
            transform: "scale(1.2)",
            transformOrigin: "center"
        });
        const wrap = document.createElement("div");
        wrap.className = origWrap?.className || "ScSvgWrapper-sc-wkgzod-0";
        Object.assign(wrap.style, {
            width: "24px",
            height: "24px"
        });
        const img = document.createElement("img");
        img.src = this._url("icons/menu_icon.svg");
        img.alt = "Twixy";
        Object.assign(img.style, {
            width: "100%",
            height: "100%",
            objectFit: "contain"
        });
        wrap.appendChild(img);
        fig.appendChild(wrap);
        btn.appendChild(fig);
        nav.appendChild(btn);
        const vxlcrContainer = notifNavItem.closest(".VxLcr") || notifNavItem.parentElement?.parentElement;
        if (!vxlcrContainer) {
            notifNavItem.parentNode.insertBefore(nav, notifNavItem);
        } else {
            vxlcrContainer.parentNode.insertBefore(nav, vxlcrContainer);
        }
        btn.addEventListener("click", () => {
            btn.classList.remove("twixy-has-notif");
            this._togglePanel();
        });
    },
    _sidebarObserver: null,
    _addingSidebar: false,
    _initSidebar() {
        this._addOrUpdateSidebar();
        this._sidebarObserver = new MutationObserver(() => {
            const sidebar = document.querySelector("nav#side-nav") || document.querySelector(".side-bar-contents");
            if (sidebar && !document.getElementById("twixy-friends-sidebar") && !this._addingSidebar) {
                this._addingSidebar = true;
                this._addOrUpdateSidebar();
                setTimeout(() => {
                    this._addingSidebar = false;
                }, 300);
            }
        });
        this._sidebarObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    _addOrUpdateSidebar() {
        const sidebar = document.querySelector("nav#side-nav") || document.querySelector(".side-bar-contents");
        if (!sidebar) return;
        let tab = document.getElementById("twixy-friends-sidebar");
        if (tab) {
            this._repositionSidebar();
            this._updateSidebarVisibility();
            this.renderSidebarFriends();
            this._updateYouWatching();
            return;
        }
        const t = window.TWIXY.i18n;
        tab = document.createElement("div");
        tab.id = "twixy-friends-sidebar";
        tab.innerHTML = `\n    <div class="twixy-sidebar-tab">\n      <div class="twixy-sidebar-header">\n        <span class="twixy-sidebar-title">${t.t("friendsTitle")}</span>\n        <span class="twixy-sidebar-profile-btn" id="twixy-sidebar-profile-btn" title="${t.t("profileTitle")}">${window.TWIXY.profile.ICONS.profileBtn}</span>\n        <button class="twixy-sidebar-refresh" title="${t.t("refresh")}">${t.t("refresh")}</button>\n      </div>\n      <div id="twixy-you-watching" class="twixy-you-watching" style="display:none"></div>\n      <div class="twixy-sidebar-friends-list"></div>\n    </div>`;
        sidebar.appendChild(tab);
        tab.querySelector(".twixy-sidebar-refresh").addEventListener("click", async () => {
            const data = await window.TWIXY.api.presence.getAll();
            if (Array.isArray(data)) {
                window.TWIXY.friends.presences = {};
                data.forEach(item => window.TWIXY.friends.updatePresence(item));
            }
            const user = await window.TWIXY.auth.getUser();
            if (user?.login) await window.TWIXY.friends.refresh(user.login);
            this.renderSidebarFriends();
        });
        tab.querySelector("#twixy-sidebar-profile-btn").addEventListener("click", async () => {
            const me = await window.TWIXY.auth.getUser();
            if (me?.login) window.TWIXY.profile.openCard(me.login);
        });
        this._repositionSidebar();
        this._updateSidebarVisibility();
        this.renderSidebarFriends();
        this._updateYouWatching();
    },
    _repositionSidebar() {
        const sidebar = document.querySelector("nav#side-nav") || document.querySelector(".side-bar-contents");
        if (!sidebar) return;
        const tab = document.getElementById("twixy-friends-sidebar");
        if (!tab) return;
        tab.parentNode?.removeChild(tab);
        const pos = window.TWIXY.settings.get("twixy_friends_position") || "top";
        if (pos === "bottom") sidebar.appendChild(tab); else sidebar.insertBefore(tab, sidebar.firstChild);
    },
    _updateSidebarVisibility() {
        const tab = document.getElementById("twixy-friends-sidebar");
        if (tab) tab.style.display = window.TWIXY.settings.getBool("twixy_friends_hidden") ? "none" : "";
    },
    _updateYouWatching() {
        const block = document.getElementById("twixy-you-watching");
        if (!block) return;
        const t = window.TWIXY.i18n;
        const streamer = window.TWIXY.presence._displaySlug;
        if (streamer) {
            block.style.display = "";
            block.innerHTML = `<span class="you-watching-text">${t.t("youWatching")} <a class="streamer-name" href="https://www.twitch.tv/${encodeURIComponent(streamer)}">${escapeHTML(streamer)}</a></span>`;
        } else {
            block.style.display = "none";
            block.innerHTML = "";
        }
    },
    _unwrapSidebarFriendsList(tab) {
        const scroll = tab.querySelector(".twixy-sidebar-friends-scroll");
        if (!scroll) return;
        const list = scroll.querySelector(".twixy-sidebar-friends-list");
        const parent = scroll.parentNode;
        if (list && parent) {
            parent.insertBefore(list, scroll);
            scroll.remove();
        }
    },
    async renderSidebarFriends() {
        const tab = document.getElementById("twixy-friends-sidebar");
        if (!tab) return;
        this._unwrapSidebarFriendsList(tab);
        const container = tab.querySelector(".twixy-sidebar-friends-list");
        if (!container) return;
        const t = window.TWIXY.i18n;
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) {
            delete tab.dataset.sidebarFriendsVisible;
            container.innerHTML = `<p class="twixy-sidebar-msg">${t.t("loginToSeeFriends")}</p>`;
            return;
        }
        const friends = window.TWIXY.friends.getSortedFriends().filter(f => !window.TWIXY.settings.isSidebarHidden(f.login));
        if (friends.length === 0) {
            delete tab.dataset.sidebarFriendsVisible;
            const neverLoaded = !window.TWIXY.friends._lastRefresh;
            container.innerHTML = `<p class="twixy-sidebar-msg">${neverLoaded ? t.t("profileLoading") : t.t("noFriends")}</p>`;
            return;
        }
        const rawInitial = parseInt(window.TWIXY.settings.get("twixy_sidebar_friends_initial"), 10);
        const INITIAL = Number.isFinite(rawInitial) && rawInitial > 0 ? Math.min(rawInitial, 100) : 5;
        const STEP = 5;
        const n = friends.length;
        let visible = parseInt(tab.dataset.sidebarFriendsVisible || "", 10);
        if (Number.isNaN(visible) || visible <= 0) {
            visible = Math.min(INITIAL, n);
        } else {
            visible = Math.min(visible, n);
        }
        tab.dataset.sidebarFriendsVisible = String(visible);
        const toShow = friends.slice(0, visible);
        container.innerHTML = "";
        for (const friend of toShow) {
            const pres = window.TWIXY.friends.presences[friend.login] || {};
            const isFav = window.TWIXY.settings.isFav(friend.login);
            const sidebarName = window.TWIXY.friends.getSidebarName(friend);
            const statusClass = pres.isStreaming ? "status-streaming" : pres.online ? "status-online" : "status-offline";
            const statusText = pres.isStreaming ? t.t("streaming") : pres.online ? t.t("online") : t.t("offline");
            const statusColor = pres.isStreaming ? "purple" : pres.online ? "green" : "grey";
            const viewHtml = pres.currentView ? `<span class="friend-view-text">${t.t("watching")} <a class="streamer-name" href="https://www.twitch.tv/${encodeURIComponent(pres.currentView)}">${escapeHTML(pres.currentView)}</a></span>` : "";
            const card = document.createElement("div");
            card.className = `sidebar-friend-item ${statusClass}`;
            card.dataset.friendLogin = friend.login;
            card.innerHTML = `\n        <div class="sidebar-friend-line-top">\n          <img src="${escapeHTML(this._getCachedAvatar(friend.login))}" class="friend-avatar" alt="">\n          <span class="friend-name" title="${escapeHTML(sidebarName)}">${escapeHTML(sidebarName)}</span>\n          <span class="twixy-profile-mini-wrap" data-login="${friend.login}">${window.TWIXY.profile.ICONS.miniCard}</span>\n          <span class="friend-fav ${isFav ? "active" : ""}" data-login="${friend.login}">${isFav ? "★" : "☆"}</span>\n        </div>\n        <div class="sidebar-friend-line-bottom">\n          <div class="friend-status-container">\n            <span class="friend-status-icon" style="background:${statusColor}"></span>\n            <span class="friend-status-text">${statusText}</span>\n          </div>\n          ${viewHtml}\n        </div>\n      `;
            const avatarEl = card.querySelector(".friend-avatar");
            this._applyAvatar(avatarEl, friend.login);
            card.querySelector(".friend-fav")?.addEventListener("click", e => {
                e.stopPropagation();
                const currentFav = window.TWIXY.settings.isFav(friend.login);
                window.TWIXY.settings.setFav(friend.login, !currentFav);
                this.renderSidebarFriends();
                if (document.querySelector(".twixy-friends-container")) this._renderAccepted();
            });
            const nameEl = card.querySelector(".friend-name");
            nameEl.style.cursor = "pointer";
            avatarEl.style.cursor = "pointer";
            nameEl.addEventListener("click", () => window.TWIXY.profile.openCard(friend.login, card));
            avatarEl.addEventListener("click", () => window.TWIXY.profile.openCard(friend.login, card));
            const miniIcon = card.querySelector(".twixy-profile-mini-wrap");
            if (miniIcon) {
                miniIcon.addEventListener("click", e => {
                    e.stopPropagation();
                    window.TWIXY.profile.openCard(friend.login, card);
                });
            }
            container.appendChild(card);
        }
        const initialShown = Math.min(INITIAL, n);
        const row = document.createElement("div");
        row.className = "twixy-sidebar-friends-controls";
        if (visible < n) {
            const more = document.createElement("button");
            more.type = "button";
            more.className = "twixy-sidebar-friends-btn";
            more.textContent = t.t("sidebarFriendsShowMore");
            more.addEventListener("click", () => {
                tab.dataset.sidebarFriendsVisible = String(Math.min(visible + STEP, n));
                this.renderSidebarFriends();
            });
            row.appendChild(more);
        }
        if (visible > initialShown) {
            const hide = document.createElement("button");
            hide.type = "button";
            hide.className = "twixy-sidebar-friends-btn twixy-sidebar-friends-btn-muted";
            hide.textContent = t.t("sidebarFriendsHide");
            hide.addEventListener("click", () => {
                tab.dataset.sidebarFriendsVisible = String(initialShown);
                this.renderSidebarFriends();
            });
            row.appendChild(hide);
        }
        if (row.childElementCount) container.appendChild(row);
    },
    _togglePanel() {
        const existing = document.getElementById("twixy-draggable");
        if (existing) {
            existing.remove();
            return;
        }
        this._createPanel();
    },
    _createPanel(initialTarget = "changelog", initialPosition = null) {
        if (document.getElementById("twixy-draggable")) return;
        const t = window.TWIXY.i18n;
        const url = this._url.bind(this);
        if (!document.getElementById("twixy-general-style")) {
            const style = document.createElement("style");
            style.id = "twixy-general-style";
            style.textContent = `\n        .menu-friend-item.status-streaming .friend-avatar { border-color: purple !important; }\n        .menu-friend-item.status-online   .friend-avatar  { border-color: green  !important; }\n        .menu-friend-item.status-offline  .friend-avatar  { border-color: grey   !important; }\n        .twixy-changelog-container .formatted-list { list-style:disc; margin-left:20px; padding-left:20px; color:#fff; }\n        .twixy-changelog-container .function-header { font-weight:bold; color:#fff; }\n        .twixy-changelog-container .function-desc   { font-size:14px; color:#ccc; margin-left:15px; }\n      `;
            document.head.appendChild(style);
        }
        const initLeft = initialPosition?.left ?? Math.max(0, (window.innerWidth - 1e3) / 2);
        const initTop = initialPosition?.top ?? Math.max(0, (window.innerHeight - 700) / 2);
        const panel = document.createElement("div");
        panel.id = "twixy-draggable";
        panel.className = "twixy-draggable";
        Object.assign(panel.style, {
            left: initLeft + "px",
            top: initTop + "px"
        });
        const st = window.TWIXY.settings;
        const showOnline = st.getBool("twixy_online_status");
        const shareAct = st.getBool("twixy_share_activity");
        panel.innerHTML = `\n      <div class="twixy-overlay-header">\n        <img src="${url("icons/menu_icon.svg")}" class="twixy-extension-icon" alt="Twixy">\n        <span class="twixy-overlay-title">${t.t("menuTitle")}</span>\n        <span class="twixy-beta-badge">BETA</span>\n        <div class="twixy-auth-container"></div>\n        <div class="twixy-close-btn" title="${t.t("close")}">&times;</div>\n      </div>\n      <div class="twixy-menu-content">\n        <div class="twixy-sidebar">\n          <ul class="twixy-menu-items">\n            <li class="twixy-menu-item ${initialTarget === "changelog" ? "active" : ""}" data-target="changelog">\n              <img src="${url("icons/changelog_icon.svg")}" class="twixy-tab-icon" alt=""> ${t.t("changelogTitle")}\n            </li>\n            <li class="twixy-menu-item ${initialTarget === "features" ? "active" : ""}" data-target="features">\n              <img src="${url("icons/icon_general.svg")}" class="twixy-tab-icon" alt=""> ${t.t("featuresTitle")}\n            </li>\n            <li class="twixy-menu-item ${initialTarget === "friends" ? "active" : ""}" data-target="friends">\n              <img src="${url("icons/icon_friends.svg")}" class="twixy-tab-icon" alt=""> ${t.t("friendsTitle")}\n            </li>\n            <li class="twixy-menu-item ${initialTarget === "analytics" ? "active" : ""}" data-target="analytics">\n              <img src="${url("icons/icon_analytics.svg")}" class="twixy-tab-icon" alt=""> ${t.t("analyticsTitle")}\n            </li>\n            <li class="twixy-menu-item ${initialTarget === "profile" ? "active" : ""}" data-target="profile">\n              <img src="${url("icons/default_avatar.svg")}" class="twixy-tab-icon" alt=""> ${t.t("profileTitle")}\n            </li>\n            <li class="twixy-menu-item ${initialTarget === "settings" ? "active" : ""}" data-target="settings">\n              <img src="${url("icons/icon_settings.svg")}" class="twixy-tab-icon" alt=""> ${t.t("settingsTitle")}\n            </li>\n          </ul>\n        </div>\n        <div class="twixy-content">\n\n          <div id="twixy-content-changelog" class="twixy-content-section ${initialTarget === "changelog" ? "active" : ""}">\n            <div class="twixy-changelog-container"></div>\n          </div>\n\n          <div id="twixy-content-features" class="twixy-content-section ${initialTarget === "features" ? "active" : ""}"></div>\n\n          <div id="twixy-content-friends" class="twixy-content-section ${initialTarget === "friends" ? "active" : ""}">\n            <div class="twixy-function">\n              <div class="twixy-friends-search">\n                <input type="text" id="twixy-friend-search" placeholder="${t.t("friendPlaceholder")}"\n                       autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false">\n                <button id="twixy-send-friend">${t.t("sendRequest")}</button>\n                <div id="twixy-suggestions" class="twixy-suggestions"></div>\n              </div>\n              <div class="twixy-status-options">\n                <div class="twixy-option">\n                  <span id="twixy-status-label">${showOnline ? t.t("online") : t.t("invisibleMode")}</span>\n                  <label class="switch">\n                    <input type="checkbox" id="twixy-status-checkbox" ${showOnline ? "checked" : ""}>\n                    <span class="slider"></span>\n                  </label>\n                  <div class="twixy-option-desc">${t.t("onlineDesc")}</div>\n                </div>\n                <div class="twixy-option">\n                  <span id="twixy-share-label">${shareAct ? t.t("shareViewingOn") : t.t("shareViewingOff")}</span>\n                  <label class="switch">\n                    <input type="checkbox" id="twixy-share-checkbox" ${shareAct ? "checked" : ""}>\n                    <span class="slider"></span>\n                  </label>\n                  <div class="twixy-option-desc">${t.t("shareDesc")}</div>\n                </div>\n              </div>\n              <div class="twixy-func-header">\n                <span class="twixy-func-title">${t.t("friendsTitle")}</span>\n                <button id="twixy-refresh-friends" title="${t.t("refresh")}">${t.t("refresh")}</button>\n              </div>\n            </div>\n            <div id="twixy-incoming-requests"></div>\n            <div id="twixy-outgoing-requests"></div>\n            <div class="twixy-friends-container"></div>\n          </div>\n\n          <div id="twixy-content-analytics" class="twixy-content-section ${initialTarget === "analytics" ? "active" : ""}"></div>\n\n          <div id="twixy-content-profile" class="twixy-content-section ${initialTarget === "profile" ? "active" : ""}"></div>\n\n          <div id="twixy-content-settings" class="twixy-content-section ${initialTarget === "settings" ? "active" : ""}"></div>\n        </div>\n      </div>\n      <div id="twixy-footer">\n        <a href="https://twixy.cc" target="_blank" id="twixy-website-link">\n          <svg class="footer-link-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>\n          <span class="footer-link-text">twixy.cc</span>\n        </a>\n        <a href="https://t.me/twixyttv" target="_blank" id="twixy-telegram-link">\n          <img src="${url("icons/telegram_icon.svg")}" class="telegram-icon" alt="">\n          <span class="telegram-text">Telegram</span>\n        </a>\n      </div>\n    `;
        document.body.appendChild(panel);
        this._makeDraggable(panel);
        this._attachPanelEvents(panel);
        this._renderFeatures();
        this._renderSettings();
        this._updateAuthContainer();
        window.TWIXY.changelog.load(panel.querySelector(".twixy-changelog-container"));
        this._refreshFriendsTabs();
        if (initialTarget === "profile") {
            window.TWIXY.profile.renderEditTab(document.getElementById("twixy-content-profile"));
        }
        if (initialTarget === "analytics") void this._renderAnalytics();
    },
    _rebuildPanelForLangChange() {
        const panel = document.getElementById("twixy-draggable");
        if (!panel) return;
        const activeTarget = panel.querySelector(".twixy-menu-item.active")?.dataset.target || "changelog";
        const rect = panel.getBoundingClientRect();
        panel.remove();
        this._createPanel(activeTarget, {
            left: rect.left,
            top: rect.top
        });
    },
    _attachPanelEvents(panel) {
        const t = window.TWIXY.i18n;
        const st = window.TWIXY.settings;
        panel.querySelector(".twixy-menu-items").addEventListener("click", e => {
            const li = e.target.closest("li.twixy-menu-item");
            if (!li) return;
            panel.querySelectorAll(".twixy-menu-item").forEach(el => el.classList.remove("active"));
            panel.querySelectorAll(".twixy-content-section").forEach(el => el.classList.remove("active"));
            li.classList.add("active");
            const target = document.getElementById("twixy-content-" + li.dataset.target);
            if (target) target.classList.add("active");
            if (li.dataset.target === "friends") {
                window.TWIXY.friends.refresh(null, true).then(() => {
                    this._renderIncoming();
                    this._renderOutgoing();
                    this._renderAccepted();
                });
            }
            if (li.dataset.target === "settings") this._renderSettings();
            if (li.dataset.target === "features") this._renderFeatures();
            if (li.dataset.target === "profile") {
                window.TWIXY.profile.renderEditTab(document.getElementById("twixy-content-profile"));
            }
            if (li.dataset.target === "changelog") {
                window.TWIXY.changelog.load(panel.querySelector(".twixy-changelog-container"));
            }
            if (li.dataset.target === "analytics") void this._renderAnalytics();
        });
        panel.querySelector(".twixy-close-btn").addEventListener("click", () => panel.remove());
        let searchTimeout;
        const searchInput = panel.querySelector("#twixy-friend-search");
        const suggDiv = panel.querySelector("#twixy-suggestions");
        searchInput?.addEventListener("input", e => {
            clearTimeout(searchTimeout);
            const q = e.target.value.trim();
            if (q.length < 2) {
                suggDiv.innerHTML = "";
                suggDiv.classList.remove("open");
                return;
            }
            suggDiv.innerHTML = `<div class="twixy-suggestion-loading">${t.t("searching")}</div>`;
            suggDiv.classList.add("open");
            searchTimeout = setTimeout(async () => {
                const lowQ = q.toLowerCase();
                const [exactResp, searchResp] = await Promise.all([ window.TWIXY.bgMessage({
                    action: "twitch_follow",
                    username: lowQ
                }), window.TWIXY.bgMessage({
                    action: "twitch_search",
                    query: q
                }) ]);
                const results = [];
                const seen = new Set;
                if (exactResp?.success && exactResp.targetUser) {
                    const u = exactResp.targetUser;
                    results.push({
                        display_name: u.display_name,
                        broadcaster_login: u.login,
                        thumbnail_url: u.profile_image_url || ""
                    });
                    seen.add(u.login.toLowerCase());
                }
                if (searchResp?.success && searchResp.results) {
                    for (const r of searchResp.results) {
                        const login = (r.broadcaster_login || "").toLowerCase();
                        if (!seen.has(login)) {
                            seen.add(login);
                            results.push(r);
                        }
                    }
                }
                results.sort((a, b) => {
                    const aLogin = (a.broadcaster_login || a.display_name || "").toLowerCase();
                    const bLogin = (b.broadcaster_login || b.display_name || "").toLowerCase();
                    const aExact = aLogin === lowQ ? 0 : aLogin.startsWith(lowQ) ? 1 : 2;
                    const bExact = bLogin === lowQ ? 0 : bLogin.startsWith(lowQ) ? 1 : 2;
                    return aExact - bExact;
                });
                if (results.length > 0) {
                    suggDiv.innerHTML = results.slice(0, 8).map(r => `<div class="twixy-suggestion-item" data-login="${escapeHTML(r.broadcaster_login || r.display_name)}">\n               <img src="${r.thumbnail_url || ""}" alt="" onerror="this.style.display='none'">\n               <span class="twixy-sugg-name">${escapeHTML(r.display_name)}</span>\n               ${r.broadcaster_login && r.broadcaster_login.toLowerCase() !== r.display_name.toLowerCase() ? `<span class="twixy-sugg-login">${escapeHTML(r.broadcaster_login)}</span>` : ""}\n             </div>`).join("");
                    suggDiv.classList.add("open");
                } else {
                    suggDiv.innerHTML = `<div class="twixy-suggestion-loading" style="color:#888">${t.t("notFound")}</div>`;
                    setTimeout(() => {
                        suggDiv.innerHTML = "";
                        suggDiv.classList.remove("open");
                    }, 1500);
                }
            }, 200);
        });
        suggDiv?.addEventListener("click", e => {
            const item = e.target.closest(".twixy-suggestion-item");
            if (!item) return;
            searchInput.value = item.dataset.login || item.querySelector(".twixy-sugg-name")?.textContent || "";
            suggDiv.innerHTML = "";
            suggDiv.classList.remove("open");
        });
        panel.querySelector("#twixy-send-friend")?.addEventListener("click", () => this._sendFriendRequest());
        searchInput?.addEventListener("keydown", e => {
            if (e.key === "Enter") this._sendFriendRequest();
        });
        panel.querySelector("#twixy-status-checkbox")?.addEventListener("change", e => {
            st.setBool("twixy_online_status", e.target.checked);
            const label = document.getElementById("twixy-status-label");
            if (label) label.textContent = e.target.checked ? t.t("online") : t.t("invisibleMode");
            window.TWIXY.presence.send(location.pathname.slice(1));
        });
        panel.querySelector("#twixy-share-checkbox")?.addEventListener("change", e => {
            st.setBool("twixy_share_activity", e.target.checked);
            const label = document.getElementById("twixy-share-label");
            if (label) label.textContent = e.target.checked ? t.t("shareViewingOn") : t.t("shareViewingOff");
            window.TWIXY.presence.send(location.pathname.slice(1));
        });
        panel.querySelector("#twixy-refresh-friends")?.addEventListener("click", () => this._refreshFriendsTabs());
        const onFriendsUpdated = () => {
            const friendsSection = document.getElementById("twixy-content-friends");
            if (friendsSection?.classList.contains("active")) {
                this._renderIncoming();
                this._renderOutgoing();
                this._renderAccepted();
            }
            this.renderSidebarFriends();
        };
        window.addEventListener("twixy:friendsUpdated", onFriendsUpdated);
        const panelRemoveObserver = new MutationObserver(() => {
            if (!document.contains(panel)) {
                window.removeEventListener("twixy:friendsUpdated", onFriendsUpdated);
                panelRemoveObserver.disconnect();
            }
        });
        panelRemoveObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    _renderFeatures() {
        const section = document.getElementById("twixy-content-features");
        if (!section) return;
        const t = window.TWIXY.i18n;
        const ac = window.TWIXY.autoclaim;
        const st = window.TWIXY.settings;
        const avatarMode = st.get("twixy_avatar_display") || "none";
        const badgeOn = st.getBool("twixy_badge_display");
        const personalTimerOn = st.getBool("twixy_personal_timer_show");
        const rawInitialFriends = parseInt(st.get("twixy_sidebar_friends_initial"), 10);
        const initialFriends = Number.isFinite(rawInitialFriends) && rawInitialFriends > 0 ? Math.min(rawInitialFriends, 100) : 5;
        const highlightOn = st.getBool("twixy_friend_highlight_enabled");
        const highlightColor = st.get("twixy_friend_highlight_color") || "rgba(147, 85, 212, 0.18)";
        const parsedColor = this._parseRgba(highlightColor);
        const followageBtnOn = st.getBool("twixy_followage_btn_show");
        section.innerHTML = `\n      <div class="twixy-general-section">\n        <div class="twixy-general-section-head">\n          <span class="twixy-general-section-ico">\n            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="5 3 19 12 5 21 5 3"/></svg>\n          </span>\n          <span class="twixy-general-section-title">${t.t("generalSectionStream")}</span>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("personalTimerTitle")}</span>\n            <label class="switch">\n              <input type="checkbox" id="twixy-personal-timer-toggle" ${personalTimerOn ? "checked" : ""}>\n              <span class="slider"></span>\n            </label>\n          </div>\n          <div class="twixy-func-desc">${t.t("personalTimerDesc")}</div>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("followageBtnSettingTitle")}</span>\n            <label class="switch">\n              <input type="checkbox" id="twixy-followage-btn-toggle" ${followageBtnOn ? "checked" : ""}>\n              <span class="slider"></span>\n            </label>\n          </div>\n          <div class="twixy-func-desc">${t.t("followageBtnSettingDesc")}</div>\n        </div>\n      </div>\n\n      <div class="twixy-general-section">\n        <div class="twixy-general-section-head">\n          <span class="twixy-general-section-ico">\n            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>\n          </span>\n          <span class="twixy-general-section-title">${t.t("generalSectionFriends")}</span>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("sidebarFriendsInitialTitle")}</span>\n          </div>\n          <div class="twixy-func-desc">${t.t("sidebarFriendsInitialDesc")}</div>\n          <div class="twixy-initial-friends-row">\n            <button type="button" class="twixy-initial-friends-btn" data-dir="-1" aria-label="−">−</button>\n            <input id="twixy-initial-friends-input" type="number" min="1" max="50" step="1" value="${initialFriends}">\n            <button type="button" class="twixy-initial-friends-btn" data-dir="1" aria-label="+">+</button>\n          </div>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("friendHighlightTitle")}</span>\n            <label class="switch">\n              <input type="checkbox" id="twixy-friend-highlight-toggle" ${highlightOn ? "checked" : ""}>\n              <span class="slider"></span>\n            </label>\n          </div>\n          <div class="twixy-func-desc">${t.t("friendHighlightDesc")}</div>\n          <div class="twixy-friend-highlight-row" ${highlightOn ? "" : "hidden"}>\n            <div class="twixy-friend-highlight-controls">\n              <label class="twixy-friend-highlight-field">\n                <span class="twixy-friend-highlight-field-label">${t.t("friendHighlightColor")}</span>\n                <input type="color" id="twixy-friend-highlight-color" value="${escapeHTML(parsedColor.hex)}">\n              </label>\n              <label class="twixy-friend-highlight-field twixy-friend-highlight-alpha">\n                <span class="twixy-friend-highlight-field-label">${t.t("alphaLabel")}</span>\n                <input type="range" id="twixy-friend-highlight-alpha" min="0" max="100" step="1" value="${Math.round(parsedColor.alpha * 100)}">\n                <span class="twixy-friend-highlight-alpha-value" id="twixy-friend-highlight-alpha-value">${Math.round(parsedColor.alpha * 100)}%</span>\n              </label>\n              <button type="button" class="twixy-friend-highlight-reset" id="twixy-friend-highlight-reset">${t.t("resetDefault")}</button>\n            </div>\n            <div class="twixy-friend-highlight-preview-wrap">\n              <div class="twixy-friend-highlight-preview" id="twixy-friend-highlight-preview">\n                <span class="twixy-friend-highlight-preview-name">friend</span>\n                <span class="twixy-friend-highlight-preview-msg">${escapeHTML(t.t("friendHighlightPreview"))}</span>\n              </div>\n            </div>\n            <div class="friends-subdesc">${t.t("friendHighlightColorHint")}</div>\n          </div>\n        </div>\n      </div>\n\n      <div class="twixy-general-section">\n        <div class="twixy-general-section-head">\n          <span class="twixy-general-section-ico">\n            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>\n          </span>\n          <span class="twixy-general-section-title">${t.t("generalSectionChat")}</span>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header"><span class="twixy-func-title">${t.t("avatarSettingsTitle")}</span></div>\n          <div class="twixy-func-desc">${t.t("avatarDisplayDesc")}</div>\n          <div class="twixy-seg-toggle" role="radiogroup" aria-label="${escapeHTML(t.t("avatarDisplay"))}">\n            <button type="button" class="twixy-seg-btn ${avatarMode === "none" ? "active" : ""}" data-avatar-mode="none" role="radio" aria-checked="${avatarMode === "none"}">${t.t("avatarHide")}</button>\n            <button type="button" class="twixy-seg-btn ${avatarMode === "friends" ? "active" : ""}" data-avatar-mode="friends" role="radio" aria-checked="${avatarMode === "friends"}">${t.t("avatarFriendsOnly")}</button>\n            <button type="button" class="twixy-seg-btn ${avatarMode === "all" ? "active" : ""}" data-avatar-mode="all" role="radio" aria-checked="${avatarMode === "all"}">${t.t("avatarAll")}</button>\n          </div>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("badgeTitle")}</span>\n            <label class="switch">\n              <input type="checkbox" id="badge-toggle" ${badgeOn ? "checked" : ""}>\n              <span class="slider"></span>\n            </label>\n          </div>\n          <div class="twixy-func-desc">${t.t("badgeDesc")}</div>\n        </div>\n      </div>\n\n      <div class="twixy-general-section">\n        <div class="twixy-general-section-head">\n          <span class="twixy-general-section-ico">\n            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2 3 14h9l-1 8 10-12h-9z"/></svg>\n          </span>\n          <span class="twixy-general-section-title">${t.t("generalSectionAutomation")}</span>\n        </div>\n\n        <div class="twixy-function">\n          <div class="twixy-func-header">\n            <span class="twixy-func-title">${t.t("autoclaimTitle")}</span>\n            <label class="switch">\n              <input type="checkbox" id="autoclaim-toggle" ${ac.enabled ? "checked" : ""}>\n              <span class="slider"></span>\n            </label>\n          </div>\n          <div class="twixy-func-desc">${t.t("autoclaimDesc")}</div>\n        </div>\n      </div>\n    `;
        section.querySelector("#autoclaim-toggle")?.addEventListener("change", e => {
            ac.enabled = e.target.checked;
        });
        section.querySelectorAll(".twixy-seg-btn[data-avatar-mode]").forEach(btn => {
            btn.addEventListener("click", () => {
                const mode = btn.dataset.avatarMode;
                if (!mode) return;
                section.querySelectorAll(".twixy-seg-btn[data-avatar-mode]").forEach(el => {
                    el.classList.toggle("active", el === btn);
                    el.setAttribute("aria-checked", el === btn ? "true" : "false");
                });
                st.set("twixy_avatar_display", mode);
                window.TWIXY.chatAvatars.refresh();
            });
        });
        section.querySelector("#badge-toggle")?.addEventListener("change", e => {
            st.setBool("twixy_badge_display", e.target.checked);
            window.TWIXY.chatAvatars.refresh();
        });
        section.querySelector("#twixy-personal-timer-toggle")?.addEventListener("change", e => {
            st.setBool("twixy_personal_timer_show", e.target.checked);
        });
        section.querySelector("#twixy-followage-btn-toggle")?.addEventListener("change", e => {
            st.setBool("twixy_followage_btn_show", e.target.checked);
        });
        const initialInput = section.querySelector("#twixy-initial-friends-input");
        const commitInitial = val => {
            const n = Math.max(1, Math.min(50, parseInt(val, 10) || 5));
            initialInput.value = String(n);
            st.set("twixy_sidebar_friends_initial", String(n));
            const tabEl = document.getElementById("twixy-friends-sidebar");
            if (tabEl) delete tabEl.dataset.sidebarFriendsVisible;
            this.renderSidebarFriends();
        };
        initialInput?.addEventListener("change", e => commitInitial(e.target.value));
        initialInput?.addEventListener("blur", e => commitInitial(e.target.value));
        section.querySelectorAll(".twixy-initial-friends-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const dir = parseInt(btn.dataset.dir, 10) || 0;
                commitInitial((parseInt(initialInput.value, 10) || 5) + dir);
            });
        });
        const hlToggle = section.querySelector("#twixy-friend-highlight-toggle");
        const hlRow = section.querySelector(".twixy-friend-highlight-row");
        const hlColor = section.querySelector("#twixy-friend-highlight-color");
        const hlAlpha = section.querySelector("#twixy-friend-highlight-alpha");
        const hlAlphaValue = section.querySelector("#twixy-friend-highlight-alpha-value");
        const hlPreview = section.querySelector("#twixy-friend-highlight-preview");
        const hlReset = section.querySelector("#twixy-friend-highlight-reset");
        const applyPreviewFromInputs = () => {
            const hex = hlColor?.value || "#9355d4";
            const a = Math.max(0, Math.min(100, parseInt(hlAlpha?.value, 10) || 0)) / 100;
            const rgba = this._hexToRgba(hex, a);
            if (hlPreview) hlPreview.style.background = rgba;
            if (hlAlphaValue) hlAlphaValue.textContent = `${Math.round(a * 100)}%`;
            return rgba;
        };
        applyPreviewFromInputs();
        hlToggle?.addEventListener("change", e => {
            st.setBool("twixy_friend_highlight_enabled", e.target.checked);
            if (hlRow) hlRow.hidden = !e.target.checked;
        });
        const persistColor = window.TWIXY.debounce(() => {
            const rgba = applyPreviewFromInputs();
            st.set("twixy_friend_highlight_color", rgba);
        }, 80);
        hlColor?.addEventListener("input", persistColor);
        hlAlpha?.addEventListener("input", persistColor);
        hlReset?.addEventListener("click", () => {
            const defaultColor = "rgba(147, 85, 212, 0.18)";
            st.set("twixy_friend_highlight_color", defaultColor);
            const parsed = this._parseRgba(defaultColor);
            if (hlColor) hlColor.value = parsed.hex;
            if (hlAlpha) hlAlpha.value = String(Math.round(parsed.alpha * 100));
            applyPreviewFromInputs();
        });
    },
    _parseRgba(value) {
        const fallback = {
            hex: "#9355d4",
            alpha: .18
        };
        if (!value) return fallback;
        const s = String(value).trim();
        const m = s.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)$/i);
        if (m) {
            const r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
            const g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
            const b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
            const a = m[4] != null ? Math.max(0, Math.min(1, parseFloat(m[4]))) : 1;
            const hex = "#" + [ r, g, b ].map(n => n.toString(16).padStart(2, "0")).join("");
            return {
                hex: hex,
                alpha: a
            };
        }
        const mm = s.match(/^#([a-f\d]{6})$/i);
        if (mm) return {
            hex: "#" + mm[1].toLowerCase(),
            alpha: 1
        };
        return fallback;
    },
    _hexToRgba(hex, alpha) {
        const clean = (hex || "#9355d4").replace("#", "");
        if (clean.length !== 6) return `rgba(147,85,212,${alpha})`;
        const r = parseInt(clean.slice(0, 2), 16);
        const g = parseInt(clean.slice(2, 4), 16);
        const b = parseInt(clean.slice(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(2)})`;
    },
    async _refreshFriendsTabs() {
        clearTimeout(this._refreshTabsTimer);
        this._refreshTabsTimer = setTimeout(async () => {
            const user = await window.TWIXY.auth.getUser();
            if (!user?.login) return;
            await window.TWIXY.friends.refresh(user.login, true);
            this._renderIncoming();
            this._renderOutgoing();
            this._renderAccepted(user.login);
        }, 300);
    },
    _renderIncoming() {
        const container = document.getElementById("twixy-incoming-requests");
        if (!container) return;
        const t = window.TWIXY.i18n;
        const requests = window.TWIXY.friends.incoming;
        const icon = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 12H4"/><path d="m10 6-6 6 6 6"/></svg>';
        container.innerHTML = `\n      <div class="twixy-friends-section-head">\n        <span class="twixy-friends-section-ico">${icon}</span>\n        <span class="twixy-friends-section-title">${escapeHTML(t.t("incomingRequests"))}</span>\n        ${requests.length ? `<span class="twixy-friends-section-count">${requests.length}</span>` : ""}\n      </div>\n    `;
        if (requests.length === 0) {
            container.insertAdjacentHTML("beforeend", `<div class="twixy-friends-empty">${escapeHTML(t.t("noIncomingRequests"))}</div>`);
            return;
        }
        for (const req of requests) {
            const fromUsername = req.from_username || req.from?.login || req.from?.username || "???";
            const reqId = req.id ?? req._id;
            const card = document.createElement("div");
            card.className = "twixy-request-card";
            card.innerHTML = `\n        <img src="${escapeHTML(this._getCachedAvatar(fromUsername))}" alt="">\n        <span class="friend-name">${escapeHTML(fromUsername)}</span>\n        <button class="action-btn accept-btn" data-id="${reqId}">${t.t("accept")}</button>\n        <button class="action-btn decline-btn" data-id="${reqId}">${t.t("decline")}</button>\n      `;
            const avatarEl = card.querySelector("img");
            this._applyAvatar(avatarEl, fromUsername);
            card.querySelector(".accept-btn").addEventListener("click", async () => {
                await window.TWIXY.api.friends.respond(reqId, "accepted");
                this._refreshFriendsTabs();
            });
            card.querySelector(".decline-btn").addEventListener("click", async () => {
                await window.TWIXY.api.friends.respond(reqId, "declined");
                this._refreshFriendsTabs();
            });
            container.appendChild(card);
        }
    },
    _renderOutgoing() {
        const container = document.getElementById("twixy-outgoing-requests");
        if (!container) return;
        const t = window.TWIXY.i18n;
        const requests = window.TWIXY.friends.outgoing;
        const icon = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h16"/><path d="m14 6 6 6-6 6"/></svg>';
        container.innerHTML = `\n      <div class="twixy-friends-section-head">\n        <span class="twixy-friends-section-ico">${icon}</span>\n        <span class="twixy-friends-section-title">${escapeHTML(t.t("outgoingRequests"))}</span>\n        ${requests.length ? `<span class="twixy-friends-section-count">${requests.length}</span>` : ""}\n      </div>\n    `;
        if (requests.length === 0) {
            container.insertAdjacentHTML("beforeend", `<div class="twixy-friends-empty">${escapeHTML(t.t("noOutgoingRequests"))}</div>`);
            return;
        }
        for (const req of requests) {
            const toLogin = req.to_username || (typeof req.to === "object" ? req.to.login : req.to) || "???";
            const toDisplay = (typeof req.to === "object" ? req.to.display_name || req.to.login : req.to_username) || toLogin;
            const reqId = req.id ?? req._id;
            const card = document.createElement("div");
            card.className = "twixy-request-card";
            card.innerHTML = `\n        <img src="${escapeHTML(this._getCachedAvatar(toLogin))}" alt="">\n        <span class="friend-name">${escapeHTML(toDisplay)}</span>\n        <button class="action-btn cancel-btn" data-id="${reqId}">${t.t("cancel")}</button>\n      `;
            const avatarEl = card.querySelector("img");
            this._applyAvatar(avatarEl, toLogin);
            card.querySelector(".cancel-btn").addEventListener("click", async () => {
                await window.TWIXY.api.friends.remove(reqId);
                this._refreshFriendsTabs();
            });
            container.appendChild(card);
        }
    },
    _renderAccepted(currentLogin) {
        const container = document.querySelector(".twixy-friends-container");
        if (!container) return;
        const t = window.TWIXY.i18n;
        const friends = window.TWIXY.friends.getSortedFriends();
        const svgEye = '<svg class="friend-vis-svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>';
        const svgEyeOff = '<svg class="friend-vis-svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
        const sectionIcon = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
        container.innerHTML = `\n      <div class="twixy-friends-section-head">\n        <span class="twixy-friends-section-ico">${sectionIcon}</span>\n        <span class="twixy-friends-section-title">${escapeHTML(t.t("yourFriends"))}</span>\n        ${friends.length ? `<span class="twixy-friends-section-count">${friends.length}</span>` : ""}\n      </div>\n    `;
        if (friends.length === 0) {
            container.insertAdjacentHTML("beforeend", `<div class="twixy-friends-empty">${escapeHTML(t.t("noFriends"))}</div>`);
            return;
        }
        for (const friend of friends) {
            const pres = window.TWIXY.friends.presences[friend.login] || {};
            const isFav = window.TWIXY.settings.isFav(friend.login);
            const menuName = window.TWIXY.friends.getMenuName(friend);
            const currentNickname = window.TWIXY.settings.getFriendNickname(friend.login);
            const sbHidden = window.TWIXY.settings.isSidebarHidden(friend.login);
            let metaInline = "";
            if (pres.currentView) {
                const streamTip = `${t.t("watching")} ${pres.currentView}`;
                metaInline = `<span class="menu-friend-meta-sep" aria-hidden="true">·</span><a class="menu-friend-stream-link" href="https://www.twitch.tv/${encodeURIComponent(pres.currentView)}" target="_blank" rel="noopener noreferrer" title="${escapeHTML(streamTip)}">${escapeHTML(pres.currentView)}</a>`;
            }
            const tipSidebar = sbHidden ? t.t("friendShowSidebar") : t.t("friendHideSidebar");
            const tipFav = isFav ? t.t("friendTipFavRemove") : t.t("friendTipFavAdd");
            const card = document.createElement("div");
            card.className = `twixy-friend-item menu-friend-item ${pres.isStreaming ? "status-streaming" : pres.online ? "status-online" : "status-offline"}`;
            card.dataset.login = friend.login;
            card.setAttribute("draggable", "true");
            card.innerHTML = `\n        <div class="menu-friend-line menu-friend-row">\n          <div class="menu-friend-lead">\n            <span class="drag-handle" aria-label="${escapeHTML(t.t("friendTipDrag"))}">⋮⋮</span>\n            <img src="${escapeHTML(this._getCachedAvatar(friend.login))}" class="friend-avatar" alt="">\n            <div class="menu-friend-textcol">\n              <span class="friend-name" title="${escapeHTML(menuName)}">${escapeHTML(menuName)}</span>${metaInline}\n            </div>\n          </div>\n          <div class="menu-friend-tools">\n            <span class="twixy-profile-mini-wrap twixy-has-tip" data-login="${friend.login}">${window.TWIXY.profile.ICONS.miniCard}${this._friendTipPopup(t.t("friendTipOpenMiniProfile"))}</span>\n            <button type="button" class="friend-fav-btn twixy-has-tip${isFav ? " is-on" : ""}" aria-pressed="${isFav ? "true" : "false"}" data-login="${friend.login}">${isFav ? "★" : "☆"}${this._friendTipPopup(tipFav)}</button>\n            <button type="button" class="friend-vis-btn friend-sidebar-toggle twixy-has-tip${sbHidden ? " is-active is-muted" : ""}" aria-label="${escapeHTML(tipSidebar)}">${sbHidden ? svgEyeOff : svgEye}${this._friendTipPopup(tipSidebar)}</button>\n            ${!friend.twitch_id ? '<span class="menu-friend-tool-spacer" aria-hidden="true"></span>' : ""}\n          </div>\n          <div class="menu-friend-actions">\n            <button type="button" class="friend-rename-toggle twixy-has-tip" aria-label="${escapeHTML(t.t("friendRenameAria"))}"><svg class="friend-rename-svg" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 0 0 0-1.42l-2.34-2.34a1.003 1.003 0 0 0-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z"/></svg>${this._friendTipPopup(t.t("friendRenameAria"))}</button>\n            <span class="twixy-has-tip twixy-delete-wrap"><button class="action-btn delete-btn" data-id="${friend.id}" aria-label="${escapeHTML(t.t("friendTipDeleteFriend"))}">${t.t("delete")}</button>${this._friendTipPopup(t.t("friendTipDeleteFriend"))}</span>\n          </div>\n        </div>\n        <div class="friend-rename-row" style="display:none">\n          <input class="friend-rename-input" type="text" maxlength="40" value="${escapeHTML(currentNickname)}" placeholder="${escapeHTML(t.t("nicknamePlaceholder"))}">\n          <button type="button" class="friend-rename-icon-btn friend-rename-save" title="${escapeHTML(t.t("save"))}" aria-label="${escapeHTML(t.t("save"))}"><svg class="friend-rename-svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></button>\n          <button type="button" class="friend-rename-icon-btn friend-rename-reset" title="${escapeHTML(t.t("reset"))}" aria-label="${escapeHTML(t.t("reset"))}"><svg class="friend-rename-svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg></button>\n        </div>\n      `;
            const avatarEl = card.querySelector(".friend-avatar");
            this._applyAvatar(avatarEl, friend.login);
            card.querySelector(".friend-fav-btn")?.addEventListener("click", e => {
                e.stopPropagation();
                e.preventDefault();
                const currentFav = window.TWIXY.settings.isFav(friend.login);
                window.TWIXY.settings.setFav(friend.login, !currentFav);
                this._renderAccepted(currentLogin);
                this.renderSidebarFriends();
            });
            card.querySelector(".friend-sidebar-toggle")?.addEventListener("click", e => {
                e.stopPropagation();
                window.TWIXY.settings.toggleSidebarHidden(friend.login);
                this._renderAccepted(currentLogin);
                this.renderSidebarFriends();
            });
            card.querySelector(".delete-btn").addEventListener("click", async () => {
                await window.TWIXY.api.friends.remove(friend.id);
                this._refreshFriendsTabs();
                this.renderSidebarFriends();
            });
            const renameBtn = card.querySelector(".friend-rename-toggle");
            const renameRow = card.querySelector(".friend-rename-row");
            const renameInput = card.querySelector(".friend-rename-input");
            const renameSaveBtn = card.querySelector(".friend-rename-save");
            const renameResetBtn = card.querySelector(".friend-rename-reset");
            renameBtn?.addEventListener("click", e => {
                e.stopPropagation();
                const isOpen = renameRow.style.display !== "none";
                renameRow.style.display = isOpen ? "none" : "flex";
                renameBtn.classList.toggle("is-active", !isOpen);
                if (!isOpen) renameInput?.focus();
            });
            renameSaveBtn?.addEventListener("click", e => {
                e.stopPropagation();
                window.TWIXY.settings.setFriendNickname(friend.login, renameInput?.value || "");
                this._renderAccepted(currentLogin);
                this.renderSidebarFriends();
            });
            renameResetBtn?.addEventListener("click", e => {
                e.stopPropagation();
                window.TWIXY.settings.setFriendNickname(friend.login, "");
                this._renderAccepted(currentLogin);
                this.renderSidebarFriends();
            });
            renameInput?.addEventListener("keydown", e => {
                if (e.key === "Enter") {
                    e.preventDefault();
                    window.TWIXY.settings.setFriendNickname(friend.login, renameInput.value || "");
                    this._renderAccepted(currentLogin);
                    this.renderSidebarFriends();
                }
                if (e.key === "Escape") {
                    e.preventDefault();
                    renameRow.style.display = "none";
                    renameBtn?.classList.remove("is-active");
                }
            });
            const nameEl = card.querySelector(".friend-name");
            nameEl.style.cursor = "pointer";
            avatarEl.style.cursor = "pointer";
            nameEl.addEventListener("click", () => window.TWIXY.profile.openCard(friend.login, card));
            avatarEl.addEventListener("click", () => window.TWIXY.profile.openCard(friend.login, card));
            const miniIcon = card.querySelector(".twixy-profile-mini-wrap");
            if (miniIcon) {
                miniIcon.addEventListener("click", e => {
                    e.stopPropagation();
                    window.TWIXY.profile.openCard(friend.login, card);
                });
            }
            const streamLink = card.querySelector(".menu-friend-stream-link");
            if (streamLink) {
                streamLink.addEventListener("mousedown", e => e.stopPropagation());
                streamLink.addEventListener("click", e => e.stopPropagation());
            }
            card.addEventListener("dragstart", () => card.classList.add("dragging"));
            card.addEventListener("dragend", () => {
                card.classList.remove("dragging");
                window.TWIXY.friends.saveOrderFromDOM();
                this.renderSidebarFriends();
            });
            container.appendChild(card);
        }
        if (!container.dataset.twixyFriendsDragover) {
            container.dataset.twixyFriendsDragover = "1";
            container.addEventListener("dragover", e => {
                e.preventDefault();
                const dragging = container.querySelector(".twixy-friend-item.dragging");
                if (!dragging) return;
                const isFavDrag = window.TWIXY.settings.isFav(dragging.dataset.login);
                const siblings = [ ...container.querySelectorAll(".twixy-friend-item:not(.dragging)") ].filter(el => window.TWIXY.settings.isFav(el.dataset.login) === isFavDrag);
                const after = siblings.reduce((closest, child) => {
                    const box = child.getBoundingClientRect();
                    const offset = e.clientY - box.top - box.height / 2;
                    return offset < 0 && offset > closest.offset ? {
                        offset: offset,
                        element: child
                    } : closest;
                }, {
                    offset: Number.NEGATIVE_INFINITY,
                    element: null
                }).element;
                if (after == null) {
                    const sameGroup = [ ...container.querySelectorAll(".twixy-friend-item") ].filter(el => window.TWIXY.settings.isFav(el.dataset.login) === isFavDrag);
                    const lastInGroup = sameGroup[sameGroup.length - 1];
                    if (lastInGroup && lastInGroup !== dragging) {
                        lastInGroup.after(dragging);
                    }
                } else {
                    container.insertBefore(dragging, after);
                }
            });
        }
    },
    async _sendFriendRequest() {
        const input = document.getElementById("twixy-friend-search");
        const targetLogin = input?.value?.trim()?.toLowerCase();
        if (!targetLogin) return;
        const t = window.TWIXY.i18n;
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) {
            this._showWarning(t.t("loginRequired"));
            return;
        }
        if (user.login.toLowerCase() === targetLogin) {
            this._showWarning(t.t("cantSendSelf"));
            return;
        }
        if (window.TWIXY.friends.isAlreadyFriend(targetLogin)) {
            this._showWarning(t.t("alreadyFriend"));
            return;
        }
        if (window.TWIXY.friends.isOutgoingPending(targetLogin)) {
            this._showWarning(t.t("alreadyRequested"));
            return;
        }
        const modeData = await window.TWIXY.api.settings.getStreamerMode(targetLogin);
        if (modeData?.streamerMode) {
            this._showWarning(t.t("streamerModeWarning"));
            return;
        }
        const resp = await window.TWIXY.bgMessage({
            action: "twitch_follow",
            username: targetLogin
        });
        if (!resp?.success || !resp.targetUser) {
            this._showWarning(t.t("userNotFoundMessage"));
            return;
        }
        const result = await window.TWIXY.api.friends.send({
            to_username: targetLogin
        });
        if (result?.success) {
            input.value = "";
            document.querySelector("#twixy-suggestions")?.classList.remove("open");
            this._refreshFriendsTabs();
        } else {
            this._showWarning(result?.error || t.t("sendRequestFailed"));
        }
    },
    _showWarning(message) {
        const container = document.querySelector(".twixy-friends-search");
        if (!container) return;
        const existing = container.querySelector(".twixy-warning");
        if (existing) existing.remove();
        const div = document.createElement("div");
        div.className = "twixy-warning";
        div.textContent = message;
        container.appendChild(div);
        setTimeout(() => div.remove(), 3e3);
    },
    async _updateAuthContainer() {
        const container = document.querySelector(".twixy-auth-container");
        if (!container) return;
        const translate = window.TWIXY.i18n;
        const url = this._url.bind(this);
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) {
            container.innerHTML = `\n        <button id="twixy-auth-btn" class="twixy-auth-btn">\n          <img src="${url("icons/twitch_icon.svg")}" alt="">\n          ${translate.t("auth")}\n        </button>\n      `;
            container.querySelector("#twixy-auth-btn")?.addEventListener("click", async ev => {
                const btn = ev.currentTarget;
                if (btn.dataset.busy === "1") return;
                btn.dataset.busy = "1";
                const oldText = btn.innerHTML;
                btn.innerHTML = `<span class="twixy-auth-btn-loading">...</span>`;
                try {
                    const result = await window.TWIXY.auth.login();
                    if (result.success) {
                        await window.TWIXY.presence.initSocket();
                        await window.TWIXY.friends.refresh(result.user.login, true);
                        this._updateAuthContainer();
                        this._refreshFriendsTabs();
                        this.renderSidebarFriends();
                    } else if (result.networkError) {
                        this._showWarning?.(window.TWIXY.i18n?.t?.("networkError") || "Сервер временно недоступен, попробуйте через минуту");
                    } else {
                        this._showWarning?.(window.TWIXY.i18n?.t?.("authFailed") || "Не удалось войти");
                    }
                } finally {
                    btn.dataset.busy = "0";
                    if (btn.isConnected && btn.innerHTML.includes("twixy-auth-btn-loading")) btn.innerHTML = oldText;
                }
            });
        } else {
            let streamerOn = false;
            try {
                const sm = await window.TWIXY.api.settings.getStreamerMode(user.login);
                streamerOn = !!sm?.streamerMode;
            } catch {}
            const badgeTitle = escapeHTML(translate.t("streamerModeTitle"));
            const badgeText = escapeHTML(translate.t("streamerModeBadge"));
            container.innerHTML = `\n        <img class="twixy-user-avatar" src="${user.profile_image_url || url("icons/twitch_icon.svg")}" alt="">\n        <div class="twixy-user-meta">\n          <span class="twixy-user-name">${escapeHTML(user.display_name || user.login)}</span>\n        </div>\n        <span class="twixy-streamer-badge" ${streamerOn ? "" : "hidden"} title="${badgeTitle}" aria-label="${badgeTitle}">${badgeText}</span>\n      `;
        }
    },
    _formatWatchMs(ms) {
        const t = window.TWIXY.i18n;
        const sec = Math.max(0, Math.floor(Number(ms) / 1e3));
        if (sec < 60) return `${sec}${t.t("durationSec")}`;
        const d = Math.floor(sec / 86400);
        const h = Math.floor(sec % 86400 / 3600);
        const m = Math.floor(sec % 3600 / 60);
        const s = sec % 60;
        const parts = [];
        if (d) parts.push(`${d}${t.t("durationDay")}`);
        if (h) parts.push(`${h}${t.t("durationHour")}`);
        if (m) parts.push(`${m}${t.t("durationMin")}`);
        if (!d && !h && m < 10 && s) parts.push(`${s}${t.t("durationSec")}`);
        if (!parts.length) parts.push(`${m}${t.t("durationMin")}`);
        return parts.join(" ");
    },
    _analyticsFormatValue(value, kind, t) {
        if (kind === "watch") return escapeHTML(this._formatWatchMs(value));
        if (kind === "points") {
            const loc = t.lang === "ru" ? "ru-RU" : "en-US";
            return escapeHTML(Math.round(value).toLocaleString(loc));
        }
        return escapeHTML(String(Math.round(value)));
    },
    _analyticsEmptyIconFor(kind) {
        const common = 'width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
        if (kind === "watch") return `<svg ${common}><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path></svg>`;
        if (kind === "points") return `<svg ${common}><path d="M12 2 3 10l9 8 9-8-9-8Z"></path><path d="m7 12 5-4 5 4"></path></svg>`;
        return `<svg ${common}><path d="M21 12a8 8 0 0 1-11.7 7.1L3 21l1.9-6.3A8 8 0 1 1 21 12Z"></path></svg>`;
    },
    _buildAnalyticsSection(kind, rows, t, opts) {
        const defAv = this._defaultAvatarUrl();
        const label = kind === "watch" ? t.t("analyticsTabWatch") : kind === "points" ? t.t("analyticsTabPoints") : t.t("analyticsTabMessages");
        const query = (opts.search || "").trim().toLowerCase();
        const filtered = query ? rows.filter(r => r.login && r.login.toLowerCase().includes(query)) : rows;
        const total = rows.reduce((a, r) => a + (Number(r.value) || 0), 0);
        const totalStr = this._analyticsFormatValue(total, kind, t);
        let listHtml;
        if (!rows.length) {
            listHtml = `<div class="twixy-lb-empty">\n        <span class="twixy-lb-empty-ico">${this._analyticsEmptyIconFor(kind)}</span>\n        <span>${escapeHTML(t.t("analyticsEmpty"))}</span>\n      </div>`;
        } else if (!filtered.length) {
            listHtml = `<div class="twixy-lb-empty">\n        <span>${escapeHTML(t.t("analyticsEmptySearch"))}</span>\n      </div>`;
        } else {
            listHtml = filtered.map((r, idx) => `\n        <div class="twixy-lb-row">\n          <span class="twixy-lb-rank" aria-hidden="true">${idx + 1}</span>\n          <img class="twixy-lb-avatar" src="${escapeHTML(defAv)}" alt="" data-avatar-login="${escapeHTML(r.login)}">\n          <a class="twixy-lb-name" href="https://www.twitch.tv/${encodeURIComponent(r.login)}" target="_blank" rel="noopener">${escapeHTML(r.login)}</a>\n          <span class="twixy-lb-value">${this._analyticsFormatValue(r.value, kind, t)}</span>\n        </div>`).join("");
        }
        return `\n      <section class="twixy-lb" data-kind="${escapeHTML(kind)}">\n        <header class="twixy-lb-head">\n          <span class="twixy-lb-ico">${this._analyticsEmptyIconFor(kind)}</span>\n          <span class="twixy-lb-title">${escapeHTML(label)}</span>\n          <span class="twixy-lb-total">${totalStr}</span>\n        </header>\n        <div class="twixy-lb-list">${listHtml}</div>\n      </section>\n    `;
    },
    async _renderAnalytics(opts = {}) {
        const section = document.getElementById("twixy-content-analytics");
        if (!section) return;
        if (!opts.skipServerRefresh) {
            await window.TWIXY.stats.refresh();
        }
        const t = window.TWIXY.i18n;
        if (!section.dataset.analyticsPeriod) section.dataset.analyticsPeriod = "all";
        if (!section.dataset.analyticsSearch) section.dataset.analyticsSearch = "";
        const period = [ "7d", "30d", "all" ].includes(section.dataset.analyticsPeriod) ? section.dataset.analyticsPeriod : "all";
        const search = section.dataset.analyticsSearch || "";
        const lb = window.TWIXY.stats.getLeaderboards(period);
        const user = await window.TWIXY.auth.getUser();
        const loginHint = user?.login ? "" : `<div class="twixy-analytics-login-hint">${escapeHTML(t.t("analyticsLoginHint"))}</div>`;
        const renderOpts = {
            search: search
        };
        const boards = [ this._buildAnalyticsSection("messages", lb.messages, t, renderOpts), this._buildAnalyticsSection("watch", lb.watch, t, renderOpts), this._buildAnalyticsSection("points", lb.points, t, renderOpts) ].join("");
        const searchIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3-3"/></svg>';
        const prevSearch = section.querySelector("#twixy-analytics-search-input");
        const ae = document.activeElement;
        const restoreSearchFocus = !!(prevSearch && (ae === prevSearch || prevSearch.contains(ae)));
        let selStart = 0;
        let selEnd = 0;
        if (restoreSearchFocus && prevSearch) {
            try {
                selStart = typeof prevSearch.selectionStart === "number" ? prevSearch.selectionStart : prevSearch.value.length;
                selEnd = typeof prevSearch.selectionEnd === "number" ? prevSearch.selectionEnd : prevSearch.value.length;
            } catch {
                selStart = selEnd = prevSearch.value.length;
            }
        }
        section.innerHTML = `\n      <div class="twixy-function twixy-analytics-hero">\n        <div class="twixy-func-header">\n          <div class="twixy-analytics-hero-text">\n            <span class="twixy-func-title">${escapeHTML(t.t("analyticsTitle"))}</span>\n            <span class="twixy-analytics-hero-sub">${escapeHTML(t.t("analyticsSubtitle"))}</span>\n          </div>\n          <div class="friends-position-toggle twixy-analytics-period" role="tablist">\n            <button type="button" class="friends-position-btn ${period === "7d" ? "active" : ""}" data-period="7d">${escapeHTML(t.t("analyticsPeriod7d"))}</button>\n            <button type="button" class="friends-position-btn ${period === "30d" ? "active" : ""}" data-period="30d">${escapeHTML(t.t("analyticsPeriod30d"))}</button>\n            <button type="button" class="friends-position-btn ${period === "all" ? "active" : ""}" data-period="all">${escapeHTML(t.t("analyticsPeriodAll"))}</button>\n          </div>\n        </div>\n        ${loginHint}\n        <label class="twixy-analytics-search">\n          <span class="twixy-analytics-search-ico">${searchIcon}</span>\n          <input type="search" id="twixy-analytics-search-input" autocomplete="off" spellcheck="false"\n            placeholder="${escapeHTML(t.t("analyticsSearchPlaceholder"))}" value="${escapeHTML(search)}">\n        </label>\n      </div>\n      <div class="twixy-analytics-boards">${boards}</div>\n    `;
        section.querySelectorAll(".twixy-analytics-period .friends-position-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                section.dataset.analyticsPeriod = btn.dataset.period || "all";
                void this._renderAnalytics({
                    skipServerRefresh: true
                });
            });
        });
        const searchInput = section.querySelector("#twixy-analytics-search-input");
        if (searchInput) {
            let lastVal = search;
            const updateSearch = window.TWIXY.debounce(val => {
                if (val === lastVal) return;
                lastVal = val;
                section.dataset.analyticsSearch = val;
                void this._renderAnalytics({
                    skipServerRefresh: true
                });
            }, 180);
            searchInput.addEventListener("input", e => updateSearch(String(e.target.value || "")));
        }
        section.querySelectorAll("img.twixy-lb-avatar[data-avatar-login]").forEach(img => {
            this._applyAvatar(img, img.getAttribute("data-avatar-login"));
        });
        const ni = section.querySelector("#twixy-analytics-search-input");
        if (ni && restoreSearchFocus) {
            ni.focus();
            try {
                const len = ni.value.length;
                ni.setSelectionRange(Math.min(selStart, len), Math.min(selEnd, len));
            } catch {
                try {
                    ni.setSelectionRange(ni.value.length, ni.value.length);
                } catch {}
            }
        }
    },
    async _renderSettings() {
        const section = document.getElementById("twixy-content-settings");
        if (!section) return;
        const t = window.TWIXY.i18n;
        const st = window.TWIXY.settings;
        const curPos = st.get("twixy_friends_position") || "top";
        const hidden = st.getBool("twixy_friends_hidden");
        const notifEnabled = st.getBool("twixy_notif_enabled");
        const user = await window.TWIXY.auth.getUser();
        section.innerHTML = `\n      <div class="twixy-function">\n        <div class="twixy-func-header">\n          <span class="twixy-func-title">${t.t("settingsTitle")}</span>\n        </div>\n        <div class="twixy-func-desc">\n          <strong>${t.t("language")}:</strong>\n          <div id="twixy-language-container" class="twixy-language-container">\n            <button class="twixy-language-btn ${t.lang === "en" ? "active" : ""}" data-lang="en">${t.t("english")}</button>\n            <button class="twixy-language-btn ${t.lang === "ru" ? "active" : ""}" data-lang="ru">${t.t("russian")}</button>\n          </div>\n        </div>\n      </div>\n\n      <div class="twixy-function">\n        <div class="twixy-func-header">\n          <span class="twixy-func-title">${t.t("streamerModeTitle")}</span>\n          <label class="switch">\n            <input type="checkbox" id="twixy-streamer-toggle" disabled>\n            <span class="slider"></span>\n          </label>\n        </div>\n        <div class="twixy-func-desc">${t.t("streamerModeDesc")}</div>\n      </div>\n\n      <div class="twixy-function">\n        <div class="twixy-func-header">\n          <span class="twixy-func-title">${t.t("hqStreamTitle")}</span>\n          <label class="switch">\n            <input type="checkbox" id="twixy-hq-toggle">\n            <span class="slider"></span>\n          </label>\n        </div>\n        <div class="friends-subdesc" style="margin-top:4px">${t.t("hqStreamReloadHint")}</div>\n        <div class="twixy-hq-msg" id="twixy-hq-msg" style="margin-top:6px;font-size:13px;color:#f87171;min-height:18px"></div>\n      </div>\n\n      <div class="twixy-function">\n        <div class="twixy-func-header"><span class="twixy-func-title">${t.t("friendsSettingsTitle")}</span></div>\n        <div class="friends-subtitle">${t.t("friendsPositionTitle")}</div>\n        <div class="friends-subdesc">${t.t("friendsPositionDesc")}</div>\n        <div class="friends-position-toggle">\n          <button class="friends-position-btn ${curPos === "top" ? "active" : ""}" data-value="top">${t.t("friendsPositionTop")}</button>\n          <button class="friends-position-btn ${curPos === "bottom" ? "active" : ""}" data-value="bottom">${t.t("friendsPositionBottom")}</button>\n        </div>\n        <div class="friends-subtitle" style="margin-top:10px">${t.t("friendsHideTitle")}</div>\n        <div class="friends-subdesc">${t.t("friendsHideDesc")}</div>\n        <label class="switch">\n          <input type="checkbox" id="twixy-friends-hide-toggle" ${hidden ? "checked" : ""}>\n          <span class="slider"></span>\n        </label>\n      </div>\n\n      <div class="twixy-function">\n        <div class="twixy-func-header">\n          <span class="twixy-func-title">${t.t("notifications")}</span>\n          <label class="switch">\n            <input type="checkbox" id="twixy-notif-toggle" ${notifEnabled ? "checked" : ""}>\n            <span class="slider"></span>\n          </label>\n        </div>\n        <div class="twixy-func-desc">${t.t("notifDesc")}</div>\n      </div>\n\n      ${user?.login ? `\n      <div class="twixy-function">\n        <div class="twixy-func-header">\n          <span class="twixy-func-title">${t.t("logout")}</span>\n        </div>\n        <div class="twixy-func-desc">\n          <button id="twixy-settings-logout-btn" class="twixy-logout-btn">\n            <img src="${this._url("icons/twitch_icon.svg")}" alt="">\n            ${t.t("logout")}\n          </button>\n        </div>\n      </div>` : ""}\n    `;
        section.querySelectorAll(".twixy-language-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                window.TWIXY.i18n.setLang(btn.dataset.lang);
            });
        });
        this._loadStreamerMode();
        section.querySelector("#twixy-streamer-toggle")?.addEventListener("change", async e => {
            const ok = await window.TWIXY.api.settings.setStreamerMode(e.target.checked);
            if (!ok) e.target.checked = !e.target.checked; else this._updateAuthContainer();
        });
        void (async () => {
            try {
                const status = await window.TWIXY.api.hq.status();
                const hqCb = section.querySelector("#twixy-hq-toggle");
                if (hqCb) hqCb.checked = Boolean(status?.enabled);
            } catch {}
        })();
        section.querySelector("#twixy-hq-toggle")?.addEventListener("change", async e => {
            const msgEl = section.querySelector("#twixy-hq-msg");
            if (msgEl) msgEl.textContent = "";
            const want = e.target.checked;
            const r = want ? await window.TWIXY.api.hq.enable() : await window.TWIXY.api.hq.disable();
            if (want && !r?.success) {
                e.target.checked = false;
                const key = r?.error === "no_twitch_session" ? "hqErrorNoSession" : r?.error === "script_register" ? "hqErrorScript" : "hqErrorRules";
                if (msgEl) msgEl.textContent = t.t(key);
                return;
            }
            window.TWIXY.settings.setBool("twixy_hq_enabled", want);
        });
        section.querySelectorAll(".friends-position-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                section.querySelectorAll(".friends-position-btn").forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                window.TWIXY.settings.set("twixy_friends_position", btn.dataset.value);
                this._repositionSidebar();
            });
        });
        section.querySelector("#twixy-friends-hide-toggle")?.addEventListener("change", e => {
            window.TWIXY.settings.setBool("twixy_friends_hidden", e.target.checked);
            this._updateSidebarVisibility();
        });
        section.querySelector("#twixy-notif-toggle")?.addEventListener("change", e => {
            window.TWIXY.settings.setBool("twixy_notif_enabled", e.target.checked);
            if (!e.target.checked) window.TWIXY.notifications.clearAll();
        });
        section.querySelector("#twixy-settings-logout-btn")?.addEventListener("click", async () => {
            await window.TWIXY.auth.logout();
            this._updateAuthContainer();
            this._renderSettings();
            this.renderSidebarFriends();
        });
    },
    async _loadStreamerMode() {
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) return;
        const data = await window.TWIXY.api.settings.getStreamerMode(user.login);
        const cb = document.getElementById("twixy-streamer-toggle");
        if (cb && data) {
            cb.checked = !!data.streamerMode;
            cb.disabled = false;
        }
    },
    _makeDraggable(panel) {
        const header = panel.querySelector(".twixy-overlay-header");
        if (!header) return;
        header.style.cursor = "move";
        let isDragging = false, startX = 0, startY = 0, origLeft = 0, origTop = 0;
        header.addEventListener("mousedown", e => {
            if (e.target.closest(".twixy-close-btn, .twixy-auth-container, button")) return;
            e.preventDefault();
            const rect = panel.getBoundingClientRect();
            panel.style.position = "fixed";
            panel.style.left = rect.left + "px";
            panel.style.top = rect.top + "px";
            origLeft = rect.left;
            origTop = rect.top;
            startX = e.clientX;
            startY = e.clientY;
            isDragging = true;
            const onMove = e => {
                if (!isDragging) return;
                let newLeft = origLeft + (e.clientX - startX);
                let newTop = origTop + (e.clientY - startY);
                newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - panel.offsetWidth));
                newTop = Math.max(0, Math.min(newTop, window.innerHeight - panel.offsetHeight));
                panel.style.left = newLeft + "px";
                panel.style.top = newTop + "px";
            };
            const onUp = () => {
                isDragging = false;
                document.removeEventListener("mousemove", onMove);
                document.removeEventListener("mouseup", onUp);
            };
            document.addEventListener("mousemove", onMove);
            document.addEventListener("mouseup", onUp);
        });
    },
    async init() {
        const tryButton = () => {
            this._injectButton();
            this._injectModViewButton();
        };
        tryButton();
        const btnInterval = setInterval(tryButton, 2e3);
        this._initSidebar();
        window.addEventListener("twixy:friendsUpdated", () => this.renderSidebarFriends());
        window.addEventListener("twixy:presenceUpdated", () => {
            this.renderSidebarFriends();
            this._updateYouWatching();
        });
        window.addEventListener("locationchange", () => {
            if (!this._isModeratorViewPath()) {
                document.getElementById("twixy-modview-dock-slot")?.remove();
            }
            this._addOrUpdateSidebar();
            window.TWIXY.chatAvatars.refresh();
            this._updateYouWatching();
        });
        const refreshAnalyticsIfOpen = window.TWIXY.debounce(() => {
            const sec = document.getElementById("twixy-content-analytics");
            if (!sec || !sec.classList.contains("active")) return;
            void this._renderAnalytics({
                skipServerRefresh: true
            });
        }, 500);
        window.addEventListener("twixy:statsUpdated", refreshAnalyticsIfOpen);
        window.addEventListener("twixy:langChanged", () => {
            const title = document.querySelector(".twixy-sidebar-title");
            if (title) title.textContent = window.TWIXY.i18n.t("friendsTitle");
            const sidebarProfileBtn = document.getElementById("twixy-sidebar-profile-btn");
            if (sidebarProfileBtn) sidebarProfileBtn.title = window.TWIXY.i18n.t("profileTitle");
            const sidebarRefreshBtn = document.querySelector(".twixy-sidebar-refresh");
            if (sidebarRefreshBtn) {
                sidebarRefreshBtn.title = window.TWIXY.i18n.t("refresh");
                sidebarRefreshBtn.textContent = window.TWIXY.i18n.t("refresh");
            }
            this.renderSidebarFriends();
            this._updateYouWatching();
            this._rebuildPanelForLangChange();
        });
        window.addEventListener("twixy:loggedOut", () => {
            this._updateAuthContainer();
            this.renderSidebarFriends();
        });
        window.addEventListener("twixy:loggedIn", () => {
            this._updateAuthContainer();
        });
        window.addEventListener("twixy:friendNicknameChanged", () => {
            this.renderSidebarFriends();
            if (document.querySelector(".twixy-friends-container")) this._renderAccepted();
        });
        window.addEventListener("twixy:sidebarHiddenChanged", () => {
            this.renderSidebarFriends();
            if (document.querySelector(".twixy-friends-container")) this._renderAccepted();
        });
        setTimeout(() => clearInterval(btnInterval), 3e4);
    }
};