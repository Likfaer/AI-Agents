"use strict";

window.TWIXY.presence = {
    _socket: null,
    _lastSent: {
        online: null,
        stream_slug: null,
        real_stream_slug: null,
        page_type: null
    },
    _displaySlug: null,
    _channel: null,
    _tabId: null,
    _lastActiveAt: 0,
    _lastDisplaySent: undefined,
    ACTIVE_TAB_KEY: "twixy_active_presence_tab",
    _ensureTabId() {
        if (this._tabId) return this._tabId;
        this._tabId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
        return this._tabId;
    },
    markActive() {
        const id = this._ensureTabId();
        this._lastActiveAt = Date.now();
        try {
            localStorage.setItem(this.ACTIVE_TAB_KEY, JSON.stringify({
                id: id,
                ts: this._lastActiveAt
            }));
        } catch {}
    },
    _readActiveTab() {
        try {
            const raw = localStorage.getItem(this.ACTIVE_TAB_KEY);
            if (!raw) return null;
            const v = JSON.parse(raw);
            if (!v || typeof v.id !== "string" || typeof v.ts !== "number") return null;
            return v;
        } catch {
            return null;
        }
    },
    _initChannel() {
        if (this._channel) return;
        this._ensureTabId();
        try {
            this._channel = new BroadcastChannel("twixy-presence");
            this._channel.onmessage = e => {
                const data = e.data;
                if (!data || !data.type) return;
                if (data.type === "presence_sent") {
                    this._displaySlug = data.stream_slug ?? null;
                    window.dispatchEvent(new Event("twixy:presenceUpdated"));
                    return;
                }
                if (data.type === "tab_closing") {
                    this._handleTabClosing(data.tabId || null);
                    return;
                }
                if (data.type === "presences_snapshot" && Array.isArray(data.statuses)) {
                    this._applyPresencesSnapshot(data.statuses);
                    return;
                }
                if (data.type === "friends_snapshot") {
                    if (Array.isArray(data.accepted)) window.TWIXY.friends.accepted = data.accepted;
                    if (Array.isArray(data.incoming)) window.TWIXY.friends.incoming = data.incoming;
                    if (Array.isArray(data.outgoing)) window.TWIXY.friends.outgoing = data.outgoing;
                    window.TWIXY.friends._lastRefresh = Date.now();
                    window.dispatchEvent(new Event("twixy:friendsUpdated"));
                    return;
                }
            };
        } catch {}
    },
    _applyPresencesSnapshot(statuses) {
        const next = {};
        for (const item of statuses) {
            const raw = item?.username || item?.login;
            if (!raw) continue;
            const login = String(raw).toLowerCase();
            const oneMinAgo = Date.now() - 6e4;
            const isRecent = item.last_seen && new Date(item.last_seen).getTime() > oneMinAgo;
            const isOnline = item.online !== undefined ? item.online : isRecent;
            next[login] = {
                login: login,
                online: isOnline,
                currentView: isOnline ? item.stream_slug || item.currentView || "" : "",
                isStreaming: false,
                timestamp: item.last_seen || item.timestamp
            };
        }
        window.TWIXY.friends.presences = next;
        window.dispatchEvent(new Event("twixy:friendsUpdated"));
    },
    broadcastPresencesSnapshot(statuses) {
        if (!this._channel) this._initChannel();
        try {
            this._channel?.postMessage({
                type: "presences_snapshot",
                statuses: statuses
            });
        } catch {}
    },
    broadcastFriendsSnapshot({accepted: accepted, incoming: incoming, outgoing: outgoing}) {
        if (!this._channel) this._initChannel();
        try {
            this._channel?.postMessage({
                type: "friends_snapshot",
                accepted: accepted,
                incoming: incoming,
                outgoing: outgoing
            });
        } catch {}
    },
    _canDriveServer({force: force = false} = {}) {
        if (force) return true;
        const myId = this._ensureTabId();
        const active = this._readActiveTab();
        if (!active) return true;
        if (active.id === myId) return true;
        if (Date.now() - active.ts > 10 * 60 * 1e3) return true;
        return false;
    },
    async _handleTabClosing(closingId) {
        const myId = this._ensureTabId();
        await new Promise(r => setTimeout(r, 220 + Math.random() * 180));
        let shouldSend = false;
        const active = this._readActiveTab();
        if (active && active.id && active.id !== closingId) {
            shouldSend = active.id === myId;
        } else {
            try {
                localStorage.setItem(this.ACTIVE_TAB_KEY, JSON.stringify({
                    id: myId,
                    ts: Date.now()
                }));
                await new Promise(r => setTimeout(r, 50 + Math.random() * 80));
                const after = this._readActiveTab();
                shouldSend = !!(after && after.id === myId);
            } catch {
                shouldSend = true;
            }
        }
        if (!shouldSend) return;
        this._lastSent = {
            online: null,
            stream_slug: null,
            real_stream_slug: null,
            page_type: null
        };
        try {
            await this.send(undefined, {
                force: true
            });
            await this.heartbeat();
        } catch {}
    },
    async send(pathOrView, opts) {
        if (!this._channel) this._initChannel();
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) return;
        const settings = window.TWIXY.settings;
        const showOnline = settings.getBool("twixy_online_status");
        const shareView = settings.getBool("twixy_share_activity");
        const streamer = window.TWIXY.getStreamerFromPath(pathOrView ?? location.pathname.slice(1));
        const newState = {
            online: showOnline,
            stream_slug: showOnline && shareView && streamer ? streamer : null,
            page_type: streamer ? "watching" : "other",
            real_online: true,
            real_stream_slug: streamer || null
        };
        if (newState.online === this._lastSent.online && newState.stream_slug === this._lastSent.stream_slug && newState.real_stream_slug === this._lastSent.real_stream_slug && newState.page_type === this._lastSent.page_type) return;
        if (!this._canDriveServer(opts || {})) {
            this._lastSent = newState;
            return;
        }
        this._lastSent = newState;
        const resp = await window.TWIXY.api.presence.update(newState);
        if (resp === null) return;
        this._displaySlug = newState.stream_slug;
        if (this._lastDisplaySent !== this._displaySlug) {
            this._lastDisplaySent = this._displaySlug;
            this._channel?.postMessage({
                type: "presence_sent",
                stream_slug: newState.stream_slug,
                tabId: this._ensureTabId()
            });
        }
        window.dispatchEvent(new Event("twixy:presenceUpdated"));
    },
    async initSocket() {
        this._initChannel();
        if (this._socket || !window.io) return;
        const loggedIn = await window.TWIXY.auth.isLoggedIn();
        if (!loggedIn) return;
        const token = await window.TWIXY.auth.getToken();
        if (!token) return;
        let host = window.TWIXY.SERVER_BASE.replace("/api", "");
        if (location.protocol === "https:" && host.startsWith("http://")) {
            host = host.replace("http://", "https://");
        }
        const path = "/api/socket.io";
        this._socket = io(host, {
            path: path,
            transports: [ "websocket" ],
            auth: {
                token: token
            }
        });
        this._socket.on("connect", async () => {
            console.log("[Twixy] Socket connected, id:", this._socket.id);
            this.send(location.pathname.slice(1));
            const data = await window.TWIXY.api.presence.getAll();
            if (data && data.success !== false) {
                const statuses = Array.isArray(data) ? data : data?.statuses ?? null;
                if (Array.isArray(statuses)) {
                    window.TWIXY.friends.presences = {};
                    statuses.forEach(item => window.TWIXY.friends.updatePresence(item));
                    window.dispatchEvent(new Event("twixy:friendsUpdated"));
                }
            }
        });
        this._socket.on("connect_error", () => {});
        this._socket.on("disconnect", reason => {
            if (reason !== "io client disconnect") {
                console.log("[Twixy] Socket disconnected:", reason);
            }
        });
        this._socket.on("friend_request_incoming", async data => {
            console.log("[Twixy] friend_request_incoming received:", data);
            const user = await window.TWIXY.auth.getUser();
            if (!user?.login) return;
            await window.TWIXY.friends.refresh(user.login, true);
            window.dispatchEvent(new Event("twixy:incomingRequest"));
        });
        this._socket.on("friend_request_outgoing", async () => {
            const user = await window.TWIXY.auth.getUser();
            if (user?.login) await window.TWIXY.friends.refresh(user.login);
        });
        this._socket.on("friend_request_accepted", async () => {
            const user = await window.TWIXY.auth.getUser();
            if (user?.login) await window.TWIXY.friends.refresh(user.login, true);
            window.dispatchEvent(new Event("twixy:friendsUpdated"));
        });
        this._socket.on("friend_request_declined", async () => {
            const user = await window.TWIXY.auth.getUser();
            if (user?.login) await window.TWIXY.friends.refresh(user.login, true);
            window.dispatchEvent(new Event("twixy:friendsUpdated"));
        });
        this._socket.on("friend_removed", async data => {
            window.TWIXY.notifications.removePending(data.id);
            const user = await window.TWIXY.auth.getUser();
            if (user?.login) await window.TWIXY.friends.refresh(user.login, true);
            window.dispatchEvent(new Event("twixy:friendsUpdated"));
        });
        this._socket.on("presence_update", data => {
            window.TWIXY.friends.updatePresence(data);
            window.dispatchEvent(new Event("twixy:friendsUpdated"));
        });
    },
    async heartbeat() {
        const user = await window.TWIXY.auth.getUser();
        if (!user?.login) return;
        if (!this._canDriveServer()) return;
        await window.TWIXY.api.presence.update({
            online: this._lastSent.online ?? true,
            stream_slug: this._lastSent.stream_slug ?? null,
            page_type: this._lastSent.page_type ?? "other",
            real_online: this._lastSent.real_online ?? true,
            real_stream_slug: this._lastSent.real_stream_slug ?? null
        });
    },
    async forceRefresh() {
        this._lastSent = {
            online: null,
            stream_slug: null,
            real_stream_slug: null,
            page_type: null
        };
        return this.send(location.pathname.slice(1));
    },
    sendOffline() {
        this._channel?.postMessage({
            type: "tab_closing",
            tabId: this._ensureTabId()
        });
    },
    destroy() {
        this._socket?.disconnect();
        this._socket = null;
        try {
            this._channel?.close();
        } catch {}
        this._channel = null;
    }
};