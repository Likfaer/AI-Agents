'use strict';

window.TWIXY.favStreamers = {
  _observer: null,
  _debounceTimer: null,
  _locationHandler: null,
  _followedChannels: new Map(),
  _pinnedLogins: new Set(),
  _liveStatus: new Map(),
  _pinnedElements: new Map(),
  _originalCards: new Map(),
  _initialized: false,

  _normalizeLogin(login) {
    return String(login ?? '').trim().toLowerCase();
  },

  _key(login) {
    const normalized = this._normalizeLogin(login);
    return normalized ? `twixy_sfav_${normalized}` : '';
  },

  isFav(login) {
    const key = this._key(login);
    if (!key) return false;
    return localStorage.getItem(key) === 'true';
  },

  setFav(login, val) {
    const key = this._key(login);
    if (!key) return;
    if (val) {
      localStorage.setItem(key, 'true');
      this._pinnedLogins.add(login);
    } else {
      localStorage.removeItem(key);
      this._pinnedLogins.delete(login);
    }
    this._scheduleRebuild();
  },

  getAllFavLogins() {
    return Array.from(this._pinnedLogins);
  },

  async _fetchFollowedChannels() {
    try {
      const { twitchToken } = await window.TWIXY.storageGet('twitchToken');
      if (!twitchToken) return;
      const user = await window.TWIXY.auth.getUser();
      const userId = user?.id;
      if (!userId) return;

      const clientId = 'n3dmo0wcnwjhahz88a5rpklz0p6j1r';
      let cursor = null;

      do {
        let url = `https://api.twitch.tv/helix/channels/followed?user_id=${userId}&first=100`;
        if (cursor) url += `&after=${cursor}`;
        const response = await fetch(url, {
          headers: { 'Client-ID': clientId, 'Authorization': `Bearer ${twitchToken}` }
        });
        if (!response.ok) break;
        const data = await response.json();
        for (const ch of data.data ?? []) {
          const login = ch.broadcaster_login.toLowerCase();
          this._followedChannels.set(login, {
            id: ch.broadcaster_id,
            login,
            displayName: ch.broadcaster_name,
          });
        }
        cursor = data.pagination?.cursor ?? null;
      } while (cursor);
    } catch {}
  },

  async _fetchAvatars(logins) {
    try {
      const { twitchToken } = await window.TWIXY.storageGet('twitchToken');
      if (!twitchToken) return;
      const clientId = 'n3dmo0wcnwjhahz88a5rpklz0p6j1r';
      const chunks = [];
      for (let i = 0; i < logins.length; i += 100) chunks.push(logins.slice(i, i + 100));
      for (const chunk of chunks) {
        const url = `https://api.twitch.tv/helix/users?login=${chunk.join('&login=')}`;
        const response = await fetch(url, {
          headers: { 'Client-ID': clientId, 'Authorization': `Bearer ${twitchToken}` }
        });
        if (!response.ok) continue;
        const data = await response.json();
        for (const u of data.data ?? []) {
          const info = this._followedChannels.get(u.login.toLowerCase());
          if (info) info.avatarUrl = u.profile_image_url;
        }
      }
    } catch {}
  },

  async _updateLiveStatus() {
    if (this._pinnedLogins.size === 0) return;
    try {
      const ids = [];
      for (const login of this._pinnedLogins) {
        const info = this._followedChannels.get(login);
        if (info?.id) ids.push(info.id);
      }
      if (!ids.length) return;

      const { twitchToken } = await window.TWIXY.storageGet('twitchToken');
      if (!twitchToken) return;
      const clientId = 'n3dmo0wcnwjhahz88a5rpklz0p6j1r';
      const url = `https://api.twitch.tv/helix/streams?user_id=${ids.join('&user_id=')}`;
      const response = await fetch(url, {
        headers: { 'Client-ID': clientId, 'Authorization': `Bearer ${twitchToken}` }
      });
      if (!response.ok) return;
      const data = await response.json();

      const newStatus = new Map();
      for (const stream of data.data ?? []) {
        const entry = [...this._followedChannels.entries()].find(([, info]) => info.id === stream.user_id);
        if (entry) newStatus.set(entry[0], { isLive: true, viewers: stream.viewer_count });
      }
      for (const login of this._pinnedLogins) {
        if (!newStatus.has(login)) newStatus.set(login, { isLive: false, viewers: 0 });
      }
      this._liveStatus = newStatus;
    } catch {}
  },

  _formatViewers(viewers) {
    if (viewers >= 1e6) return (viewers / 1e6).toFixed(1) + 'M';
    if (viewers >= 1e3) return (viewers / 1e3).toFixed(1) + 'K';
    return viewers.toString();
  },

  // Обновляет статус уже вставленных карточек без пересборки
  _updatePinnedCardsStatus() {
    for (const [login, card] of this._pinnedElements) {
      const liveInfo = this._liveStatus.get(login) || { isLive: false, viewers: 0 };
      const statusEl = card.querySelector('[data-a-target="side-nav-live-status"]');
      if (!statusEl) continue;

      if (liveInfo.isLive) {
        statusEl.innerHTML = `
          <div class="Layout-sc-1xcs6mc-0 kvrzxX">
            <div class="ScChannelStatusIndicator-sc-bjn067-0 fJwlvq tw-channel-status-indicator"></div>
            <p class="CoreText-sc-1txzju1-0 cWFBTs InjectLayout-sc-1i43xsx-0 cdydzE">Live</p>
            <div class="Layout-sc-1xcs6mc-0 dqfEBK">
              <span aria-hidden="true" class="CoreText-sc-1txzju1-0 fYAAA-D">${this._formatViewers(liveInfo.viewers)}</span>
              <p class="CoreText-sc-1txzju1-0 cWFBTs InjectLayout-sc-1i43xsx-0 cdydzE">${this._formatViewers(liveInfo.viewers)} viewers</p>
            </div>
          </div>`;
      } else {
        statusEl.innerHTML = `<span class="CoreText-sc-1txzju1-0 fYAAA-D">Offline</span>`;
      }
    }
  },

  _scheduleRebuild() {
    clearTimeout(this._rebuildTimer);
    this._rebuildTimer = setTimeout(() => this._rebuildPinnedList(), 100);
  },

  async _rebuildPinnedList() {
    if (this._isRebuilding) return;
    this._isRebuilding = true;
    const container = document.querySelector('[aria-label="Followed Channels"] .tw-transition-group');
    if (!container)
      {
        this._isRebuilding = false;
        return;
      } 
    for (const origCard of this._originalCards.values()) {
      if (origCard) origCard.style.display = '';
    }
    this._originalCards.clear();

    for (const card of this._pinnedElements.values()) card.remove();
    this._pinnedElements.clear();

    if (this._pinnedLogins.size === 0) return;

    const sorted = [...this._pinnedLogins];

    for (let i = sorted.length - 1; i >= 0; i--) {
      const login = sorted[i];
      const liveInfo = this._liveStatus.get(login) || { isLive: false, viewers: 0 };

      // Ищем оригинальную карточку в DOM
      const existingLink = container.querySelector(`a[data-test-selector="followed-channel"][href="/${login}"]`);
      const originalCard = existingLink?.closest('.tw-transition-group > *') ?? null;

      let newCard;
      if (originalCard) {
        newCard = originalCard.cloneNode(true);
        newCard.querySelectorAll('.twixy-sfav-wrap').forEach(el => el.remove());
        originalCard.style.display = 'none';
        this._originalCards.set(login, originalCard);
      } else {
        newCard = this._buildCardFromData(login, liveInfo);
        if (!newCard) continue;
      }

      this._addStarToCard(newCard, login);
      container.insertBefore(newCard, container.firstChild);
      this._pinnedElements.set(login, newCard);
    }
    this._isRebuilding = false;
  },

  _buildCardFromData(login, liveInfo) {
    const info = this._followedChannels.get(login);
    const offlineClass = liveInfo.isLive ? '' : ' side-nav-card__avatar--offline';
    const displayName = info?.displayName || login;
    const avatarUrl = info?.avatarUrl || 'https://static-cdn.jtvnw.net/jtv_user_pictures/user-profile_image-300x300.png';

    const liveHtml = liveInfo.isLive
      ? `<div class="Layout-sc-1xcs6mc-0 kvrzxX">
           <div class="ScChannelStatusIndicator-sc-bjn067-0 fJwlvq tw-channel-status-indicator"></div>
           <p class="CoreText-sc-1txzju1-0 cWFBTs InjectLayout-sc-1i43xsx-0 cdydzE">Live</p>
           <div class="Layout-sc-1xcs6mc-0 dqfEBK">
             <span aria-hidden="true" class="CoreText-sc-1txzju1-0 fYAAA-D">${this._formatViewers(liveInfo.viewers)}</span>
             <p class="CoreText-sc-1txzju1-0 cWFBTs InjectLayout-sc-1i43xsx-0 cdydzE">${this._formatViewers(liveInfo.viewers)} viewers</p>
           </div>
         </div>`
      : `<span class="CoreText-sc-1txzju1-0 fYAAA-D">Offline</span>`;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <div class="Layout-sc-1xcs6mc-0 AoXTY side-nav-card">
        <a data-test-selector="followed-channel"
           aria-haspopup="dialog"
           class="ScCoreLink-sc-16kq0mq-0 fytYW InjectLayout-sc-1i43xsx-0 cnzybN side-nav-card__link tw-link"
           href="/${login}">
          <div class="Layout-sc-1xcs6mc-0 kErOMx side-nav-card__avatar${offlineClass}" style="position: relative;">
            <div class="ScAvatar-sc-144b42z-0 dLsNfm tw-avatar">
              <img class="InjectLayout-sc-1i43xsx-0 fAYJcN tw-image tw-image-avatar"
                   alt="" src="${avatarUrl}" style="object-fit: cover;">
            </div>
          </div>
          <div class="Layout-sc-1xcs6mc-0 bLlihH">
            <div class="Layout-sc-1xcs6mc-0 dJfBsr">
              <div data-a-target="side-nav-card-metadata" class="Layout-sc-1xcs6mc-0 ffUuNa">
                <div class="Layout-sc-1xcs6mc-0 kvrzxX side-nav-card__title">
                  <p data-a-target="side-nav-title"
                     class="CoreText-sc-1txzju1-0 dTdgXA InjectLayout-sc-1i43xsx-0 hnBAak">${displayName}</p>
                </div>
              </div>
              <div class="Layout-sc-1xcs6mc-0 cXMAQb side-nav-card__live-status"
                   data-a-target="side-nav-live-status">
                ${liveHtml}
              </div>
            </div>
          </div>
        </a>
      </div>`;
    return wrapper.firstElementChild;
  },

  _addStarToCard(card, login) {
    const avatarWrap = card.querySelector('.side-nav-card__avatar, .tw-avatar, figure, [data-a-target="side-nav-avatar"]');
    if (!avatarWrap) return;
    if (getComputedStyle(avatarWrap).position === 'static') avatarWrap.style.position = 'relative';
    if (avatarWrap.querySelector(`.twixy-sfav-wrap[data-login="${login}"]`)) return;

    const wrap = this._createStarWrap(login, true);
    avatarWrap.appendChild(wrap);
  },

  _addStar(linkEl, login) {
    const avatarWrap = linkEl.querySelector('.side-nav-card__avatar, .tw-avatar, figure, [data-a-target="side-nav-avatar"]');
    if (!avatarWrap) return;
    if (getComputedStyle(avatarWrap).position === 'static') avatarWrap.style.position = 'relative';
    if (avatarWrap.querySelector(`.twixy-sfav-wrap[data-login="${login}"]`)) return;

    const wrap = this._createStarWrap(login, this.isFav(login));
    avatarWrap.appendChild(wrap);
  },

  _createStarWrap(login, isFav) {
    const modAlways = this.isModBtnAlwaysVisible();

    const wrap = document.createElement('span');
    wrap.className = 'twixy-sfav-wrap';
    wrap.dataset.login = login;
    wrap.classList.toggle('has-active', isFav);
    wrap.classList.toggle('mod-always', isFav && modAlways);

    const star = document.createElement('span');
    star.className = 'twixy-sfav';
    star.dataset.login = login;
    this._syncStarState(star, login);

    star.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      const nowFav = !this.isFav(login);
      this.setFav(login, nowFav);
      this._updateAllStars(login, nowFav);
    });

    const modBtn = document.createElement('span');
    modBtn.className = 'twixy-sfav-mod';
    modBtn.textContent = '⚔';
    modBtn.title = window.TWIXY.i18n?.lang === 'ru' ? 'Открыть как модератор' : 'Open as moderator';
    modBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      window.open(`https://www.twitch.tv/moderator/${login}`, '_blank');
    });

    wrap.appendChild(star);
    wrap.appendChild(modBtn);
    return wrap;
  },

  _syncStarState(starEl, login) {
    const active = this.isFav(login);
    const ru = window.TWIXY.i18n?.lang === 'ru';
    starEl.classList.toggle('active', active);
    starEl.textContent = active ? '★' : '☆';
    starEl.title = active
      ? (ru ? 'Убрать из избранного' : 'Unpin streamer')
      : (ru ? 'Добавить в избранное' : 'Pin streamer');
  },

  _updateAllStars(login, active) {
    const modAlways = this.isModBtnAlwaysVisible();
    document.querySelectorAll(`.twixy-sfav-wrap[data-login="${login}"]`).forEach(wrap => {
      wrap.classList.toggle('has-active', active);
      wrap.classList.toggle('mod-always', active && modAlways);
      const star = wrap.querySelector('.twixy-sfav');
      if (star) this._syncStarState(star, login);
    });
  },

  isModBtnAlwaysVisible() {
    return window.TWIXY.settings?.getBool('twixy_mod_btn_always') ?? false;
  },

  _getLogin(linkEl) {
    let href = linkEl.getAttribute('href') || '';
    try { href = new URL(href, location.origin).pathname; } catch {}
    return window.TWIXY.getStreamerFromPath(href)?.toLowerCase() || null;
  },

  _decorateEntries(sideNav) {
    for (const link of sideNav.querySelectorAll('a[data-test-selector="followed-channel"]')) {
      if (link.closest('#twixy-friends-sidebar, #twixy-profile-card, #twixy-draggable')) continue;
      // Пропускаем карточки внутри наших закреплённых (там звёздочки уже есть)
      if (link.closest('[data-twixy-pinned]')) continue;

      const login = this._getLogin(link);
      if (!login) continue;

      const existingWrap = link.querySelector(`.twixy-sfav-wrap[data-login="${login}"]`);
      if (existingWrap) {
        // Обновляем существующую звёздочку
        const star = existingWrap.querySelector('.twixy-sfav');
        if (star) this._syncStarState(star, login);
        const isFav = this.isFav(login);
        existingWrap.classList.toggle('has-active', isFav);
        existingWrap.classList.toggle('mod-always', isFav && this.isModBtnAlwaysVisible());
        continue;
      }

      this._addStar(link, login);
    }
  },

  _scheduleProcess() {
    clearTimeout(this._debounceTimer);
    this._debounceTimer = setTimeout(() => this._process(), 300);
  },

  _process() {
    const sideNav = document.querySelector('nav#side-nav, #side-nav, .side-bar-contents');
    if (!sideNav) return;
    this._rebuildPinnedList();
    this._decorateEntries(sideNav);
  },

  async init() {
    if (this._observer) return;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('twixy_sfav_') && localStorage.getItem(key) === 'true') {
        this._pinnedLogins.add(key.slice('twixy_sfav_'.length));
      }
    }

    if (window.TWIXY.auth && await window.TWIXY.auth.isLoggedIn()) {
      await this._fetchFollowedChannels();
      if (this._pinnedLogins.size > 0) {
        await this._fetchAvatars([...this._pinnedLogins]);
      }
      await this._updateLiveStatus();
    }

    this._locationHandler = () => {
      this._pinnedElements.clear();
      this._originalCards.clear();
      this._scheduleProcess();
    };
    window.addEventListener('locationchange', this._locationHandler);
    window.addEventListener('twixy:langChanged', this._locationHandler);

    this._observer = new MutationObserver(() => this._scheduleProcess());
    this._observer.observe(document.body, { childList: true, subtree: true });

    this._waitForContainerAndBuild();

    setInterval(() => {
      if (document.visibilityState === 'visible' && this._pinnedLogins.size) {
        this._updateLiveStatus().then(() => this._updatePinnedCardsStatus());
      }
    }, 60000);
  },
  _waitForContainerAndBuild() {
    const container = document.querySelector('[aria-label="Followed Channels"] .tw-transition-group');
    if (container) {
      this._process();
      return;
    }
    const waitTimer = setInterval(() => {
      const c = document.querySelector('[aria-label="Followed Channels"] .tw-transition-group');
      if (c) {
        clearInterval(waitTimer);
        this._process();
      }
    }, 500);
    setTimeout(() => clearInterval(waitTimer), 15000);
  },

  destroy() {
    this._observer?.disconnect();
    this._observer = null;
    clearTimeout(this._debounceTimer);
    clearTimeout(this._rebuildTimer);
    if (this._locationHandler) {
      window.removeEventListener('locationchange', this._locationHandler);
      window.removeEventListener('twixy:langChanged', this._locationHandler);
      this._locationHandler = null;
    }
    for (const card of this._pinnedElements.values()) card.remove();
    for (const origCard of this._originalCards.values()) {
      if (origCard) origCard.style.display = '';
    }
    this._pinnedElements.clear();
    this._originalCards.clear();
    document.querySelectorAll('.twixy-sfav-wrap').forEach(el => el.remove());
  },
};