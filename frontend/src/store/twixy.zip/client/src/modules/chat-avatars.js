"use strict";

window.TWIXY.chatAvatars = {
    _cache: {},
    _twixyCache: {},
    _observer: null,
    _viewerCardObserver: null,
    _defaultAvatar: chrome.runtime.getURL("icons/default_avatar.svg"),
    _badgeIcon: chrome.runtime.getURL("icons/chat_badge.svg"),
    _tooltipEl: null,
    _tooltipAnchor: null,
    _tooltipPinned: false,
    _globalListenersBound: false,
    async _getAvatar(login) {
        if (this._cache[login]) return this._cache[login];
        const resp = await window.TWIXY.bgMessage({
            action: "get_avatar",
            login: login
        });
        const url = resp?.url || this._defaultAvatar;
        this._cache[login] = url;
        return url;
    },
    _mode() {
        return window.TWIXY.settings.get("twixy_avatar_display") || "none";
    },
    _isFriend(login) {
        const lo = login.toLowerCase();
        return window.TWIXY.friends.accepted.some(doc => (doc.username || "").toLowerCase() === lo);
    },
    _friendHighlightEnabled() {
        return window.TWIXY.settings.getBool("twixy_friend_highlight_enabled");
    },
    _friendHighlightColor() {
        return window.TWIXY.settings.get("twixy_friend_highlight_color") || "rgba(147, 85, 212, 0.18)";
    },
    _applyFriendHighlightGlobals() {
        const root = document.documentElement;
        if (!root) return;
        const enabled = this._friendHighlightEnabled();
        root.dataset.twixyFriendHl = enabled ? "1" : "0";
        root.style.setProperty("--twixy-friend-hl-color", this._friendHighlightColor());
    },
    _refreshFriendHighlightFlags() {
        if (!this._friendHighlightEnabled()) {
            document.querySelectorAll('[data-twixy-friend-msg="1"]').forEach(el => {
                delete el.dataset.twixyFriendMsg;
            });
            return;
        }
        const apply = (msgNode, login) => {
            if (!login) return;
            if (this._isFriend(login)) msgNode.dataset.twixyFriendMsg = "1"; else delete msgNode.dataset.twixyFriendMsg;
        };
        document.querySelectorAll('[data-a-target="chat-line-message"]').forEach(el => {
            const nameEl = el.querySelector(".chat-author__display-name");
            if (!nameEl) return;
            const login = (nameEl.getAttribute("data-a-user") || nameEl.textContent || "").trim().toLowerCase();
            apply(el, login);
        });
        document.querySelectorAll(".seventv-user-message").forEach(el => {
            const nameEl = el.querySelector(".seventv-chat-user-username");
            if (!nameEl) return;
            const matches = nameEl.textContent.match(/\(([^)]+)\)$/);
            const login = (matches ? matches[1] : nameEl.textContent).trim().toLowerCase();
            apply(el, login);
        });
    },
    _badgeEnabled() {
        return window.TWIXY.settings.getBool("twixy_badge_display");
    },
    async _isTwixyUser(login) {
        const lo = login.toLowerCase();
        if (lo in this._twixyCache) 
            return this._twixyCache[lo];
        try {
            const resp = await window.TWIXY.api.friends.lookupUser(lo);
            const result = resp?.success === true;
            this._twixyCache[lo] = result;
            return result;
        } catch {
            return false;
        }
    },
    async _isTwixyUser(login) {
        const lo = login.toLowerCase();
        if (lo in this._twixyCache) 
            return this._twixyCache[lo];
        this._twixyCache[lo] = window.TWIXY.api.friends.lookupUser(lo).then(resp => resp?.success === true).catch(() => false)

    },
    _getBadgeTooltipText() {
        const text = window.TWIXY.i18n?.t?.("twixyBadgeTooltip");
        if (text && text !== "twixyBadgeTooltip") return text;
        return window.TWIXY.i18n?.lang === "ru" ? "Пользователь использует расширение Twixy" : "This user uses the Twixy extension";
    },
    _ensureTooltipUi() {
        if (!document.getElementById("twixy-chat-badge-tooltip-style")) {
            const style = document.createElement("style");
            style.id = "twixy-chat-badge-tooltip-style";
            style.textContent = `\n        .twixy-chat-badge-wrap {\n          position: relative;\n          display: inline-flex;\n          align-items: center;\n          justify-content: center;\n          vertical-align: middle;\n          line-height: 1;\n          margin: 0 3px 1.5px 0;\n          cursor: pointer;\n          outline: none;\n        }\n\n        .twixy-chat-badge-wrap:focus-visible {\n          outline: none;\n        }\n\n        .twixy-chat-badge-wrap .twixy-chat-badge {\n          width: 18px;\n          height: 18px;\n          min-width: 18px;\n          min-height: 18px;\n          display: block;\n          object-fit: contain;\n          border-radius: 4px;\n          margin: 0;\n          transition:\n            transform 0.16s ease,\n            filter 0.16s ease,\n            opacity 0.16s ease;\n        }\n\n        .twixy-chat-badge-wrap:hover .twixy-chat-badge,\n        .twixy-chat-badge-wrap.twixy-open .twixy-chat-badge,\n        .twixy-chat-badge-wrap:focus-within .twixy-chat-badge {\n          transform: translateY(-1px) scale(1.06);\n          filter: brightness(1.08);\n        }\n\n        #twixy-global-badge-tooltip {\n          position: fixed;\n          top: 0;\n          left: 0;\n          z-index: 2147483647;\n          min-width: 170px;\n          max-width: 240px;\n          padding: 9px 11px;\n          border-radius: 10px;\n          background: rgba(20, 22, 30, 0.96);\n          color: #eef1ff;\n          border: 1px solid rgba(167, 139, 250, 0.30);\n          box-shadow:\n            0 12px 28px rgba(0, 0, 0, 0.35),\n            0 0 0 1px rgba(255, 255, 255, 0.03) inset;\n          backdrop-filter: blur(10px);\n          font-size: 12px;\n          font-weight: 500;\n          line-height: 1.35;\n          letter-spacing: 0.01em;\n          text-align: center;\n          white-space: normal;\n          pointer-events: none;\n          opacity: 0;\n          visibility: hidden;\n          transform: translate(-9999px, -9999px);\n          transition:\n            opacity 0.14s ease,\n            visibility 0.14s ease;\n        }\n\n        #twixy-global-badge-tooltip.twixy-visible {\n          opacity: 1;\n          visibility: visible;\n        }\n\n        #twixy-global-badge-tooltip::after {\n          content: '';\n          position: absolute;\n          left: 50%;\n          width: 10px;\n          height: 10px;\n          background: rgba(20, 22, 30, 0.96);\n          border-right: 1px solid rgba(167, 139, 250, 0.30);\n          border-bottom: 1px solid rgba(167, 139, 250, 0.30);\n          transform: translateX(-50%) rotate(45deg);\n        }\n\n        #twixy-global-badge-tooltip[data-placement="top"]::after {\n          top: calc(100% - 5px);\n        }\n\n        #twixy-global-badge-tooltip[data-placement="bottom"]::after {\n          top: -5px;\n          transform: translateX(-50%) rotate(225deg);\n        }\n      `;
            document.head.appendChild(style);
        }
        if (!this._tooltipEl) {
            const tooltip = document.createElement("div");
            tooltip.id = "twixy-global-badge-tooltip";
            tooltip.setAttribute("data-placement", "top");
            document.body.appendChild(tooltip);
            this._tooltipEl = tooltip;
        }
    },
    _bindGlobalTooltipListeners() {
        if (this._globalListenersBound) return;
        this._globalListenersBound = true;
        document.addEventListener("click", event => {
            if (!event.target.closest(".twixy-chat-badge-wrap")) {
                this._hideTooltip(true);
            }
        });
        window.addEventListener("resize", () => {
            this._positionTooltip();
        });
        window.addEventListener("scroll", () => {
            this._positionTooltip();
        }, true);
    },
    _positionTooltip() {
        const tooltip = this._tooltipEl;
        const anchor = this._tooltipAnchor;
        if (!tooltip || !anchor) return;
        if (!document.contains(anchor)) {
            this._hideTooltip(true);
            return;
        }
        const rect = anchor.getBoundingClientRect();
        const viewportWidth = document.documentElement.clientWidth;
        const viewportHeight = document.documentElement.clientHeight;
        const gap = 10;
        const edge = 8;
        tooltip.style.transform = "translate(-9999px, -9999px)";
        tooltip.classList.add("twixy-visible");
        const tooltipWidth = tooltip.offsetWidth;
        const tooltipHeight = tooltip.offsetHeight;
        let left = rect.left + rect.width / 2 - tooltipWidth / 2;
        left = Math.max(edge, Math.min(left, viewportWidth - tooltipWidth - edge));
        let top = rect.top - tooltipHeight - gap;
        let placement = "top";
        if (top < edge) {
            top = rect.bottom + gap;
            placement = "bottom";
        }
        if (top + tooltipHeight > viewportHeight - edge) {
            top = Math.max(edge, viewportHeight - tooltipHeight - edge);
        }
        tooltip.setAttribute("data-placement", placement);
        tooltip.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
    },
    _showTooltip(anchor, pinned = false) {
        if (!anchor) return;
        this._ensureTooltipUi();
        this._bindGlobalTooltipListeners();
        this._tooltipAnchor = anchor;
        this._tooltipPinned = pinned;
        this._tooltipEl.textContent = this._getBadgeTooltipText();
        this._tooltipEl.classList.add("twixy-visible");
        this._positionTooltip();
    },
    _hideTooltip(force = false) {
        if (!force && this._tooltipPinned) return;
        if (this._tooltipEl) {
            this._tooltipEl.classList.remove("twixy-visible");
            this._tooltipEl.style.transform = "translate(-9999px, -9999px)";
        }
        this._tooltipAnchor = null;
        this._tooltipPinned = false;
        document.querySelectorAll(".twixy-chat-badge-wrap.twixy-open").forEach(el => {
            el.classList.remove("twixy-open");
        });
    },
    _togglePinnedTooltip(anchor) {
        const isSameAnchor = this._tooltipAnchor === anchor;
        const shouldClose = isSameAnchor && this._tooltipPinned;
        if (shouldClose) {
            anchor.classList.remove("twixy-open");
            this._hideTooltip(true);
            return;
        }
        document.querySelectorAll(".twixy-chat-badge-wrap.twixy-open").forEach(el => {
            if (el !== anchor) el.classList.remove("twixy-open");
        });
        anchor.classList.add("twixy-open");
        this._showTooltip(anchor, true);
    },
    _createBadge() {
        const wrap = document.createElement("span");
        wrap.className = "twixy-chat-badge-wrap";
        wrap.setAttribute("tabindex", "0");
        wrap.setAttribute("role", "button");
        wrap.setAttribute("aria-label", this._getBadgeTooltipText());
        const badge = document.createElement("img");
        badge.className = "chat-badge twixy-chat-badge";
        badge.src = this._badgeIcon;
        badge.alt = "Twixy";
        badge.width = 18;
        badge.height = 18;
        badge.decoding = "async";
        badge.draggable = false;
        wrap.addEventListener("mouseenter", () => {
            if (this._tooltipPinned && this._tooltipAnchor !== wrap) return;
            this._showTooltip(wrap, false);
        });
        wrap.addEventListener("mouseleave", () => {
            if (!this._tooltipPinned || this._tooltipAnchor !== wrap) {
                this._hideTooltip(true);
            }
        });
        wrap.addEventListener("focus", () => {
            if (this._tooltipPinned && this._tooltipAnchor !== wrap) return;
            this._showTooltip(wrap, false);
        });
        wrap.addEventListener("blur", () => {
            if (!this._tooltipPinned || this._tooltipAnchor !== wrap) {
                this._hideTooltip(true);
            }
        });
        wrap.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            this._togglePinnedTooltip(wrap);
        });
        wrap.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                this._togglePinnedTooltip(wrap);
            } else if (event.key === "Escape") {
                event.preventDefault();
                this._hideTooltip(true);
            }
        });
        wrap.appendChild(badge);
        return wrap;
    },
    async _addToMessage(msgNode) {
        if (msgNode.dataset.twixyProcessed) return;
        msgNode.dataset.twixyProcessed = "1";
        const container = msgNode.querySelector(".chat-line__username-container");
        if (!container) return;
        const usernameEl = container.querySelector(".chat-author__display-name");
        if (!usernameEl) return;
        const login = (usernameEl.getAttribute("data-a-user") || usernameEl.textContent).trim().toLowerCase();
        if (!login) return;
        if (this._isFriend(login)) msgNode.dataset.twixyFriendMsg = "1"; else delete msgNode.dataset.twixyFriendMsg;
        const avatarMode = this._mode();
        if (avatarMode !== "none") {
            if (avatarMode === "all" || avatarMode === "friends" && this._isFriend(login)) {
                if (!msgNode.dataset.twixyAvatar) {
                    const url = await this._getAvatar(login);
                    const img = document.createElement("img");
                    img.className = "twixy-chat-avatar";
                    img.src = url;
                    img.alt = login;
                    container.insertBefore(img, container.firstChild);
                    msgNode.dataset.twixyAvatar = "1";
                }
            }
        }
        if (this._badgeEnabled() && !msgNode.dataset.twixyBadge) {
            const isTwixy = await this._isTwixyUser(login);
            if (isTwixy) {
                const badge = this._createBadge();
                const parent = usernameEl.parentElement || container;
                parent.insertBefore(badge, usernameEl);
                msgNode.dataset.twixyBadge = "1";
            }
        }
    },
    async _addSevenTvAvatar(msgNode) {
        if (msgNode.dataset.twixyProcessed) return;
        msgNode.dataset.twixyProcessed = "1";
        const nameEl = msgNode.querySelector(".seventv-chat-user-username");
        if (!nameEl) return;
        const matches = nameEl.textContent.match(/\(([^)]+)\)$/);
        const login = (matches ? matches[1] : nameEl.textContent).trim().toLowerCase();
        if (this._isFriend(login)) msgNode.dataset.twixyFriendMsg = "1"; else delete msgNode.dataset.twixyFriendMsg;
        const avatarMode = this._mode();
        if (avatarMode !== "none") {
            if (avatarMode === "all" || avatarMode === "friends" && this._isFriend(login)) {
                if (!msgNode.dataset.twixyAvatar) {
                    const url = await this._getAvatar(login);
                    const img = document.createElement("img");
                    img.className = "twixy-chat-avatar";
                    img.src = url;
                    img.alt = login;
                    const userDiv = msgNode.querySelector(".seventv-chat-user");
                    if (userDiv) {
                        userDiv.insertBefore(img, userDiv.firstChild);
                        msgNode.dataset.twixyAvatar = "1";
                    }
                }
            }
        }
        if (this._badgeEnabled() && !msgNode.dataset.twixyBadge) {
            const isTwixy = await this._isTwixyUser(login);
            if (isTwixy) {
                const badge = this._createBadge();
                const userDiv = msgNode.querySelector(".seventv-chat-user");
                if (userDiv && nameEl) {
                    nameEl.parentElement.insertBefore(badge, nameEl);
                    msgNode.dataset.twixyBadge = "1";
                }
            }
        }
    },
    refresh() {
        this._applyFriendHighlightGlobals();
        document.querySelectorAll(".twixy-chat-avatar").forEach(el => el.remove());
        document.querySelectorAll(".twixy-chat-badge-wrap").forEach(el => el.remove());
        document.querySelectorAll('[data-a-target="chat-line-message"]').forEach(el => {
            delete el.dataset.twixyProcessed;
            delete el.dataset.twixyAvatar;
            delete el.dataset.twixyBadge;
            delete el.dataset.twixyFriendMsg;
        });
        document.querySelectorAll(".seventv-user-message").forEach(el => {
            delete el.dataset.twixyProcessed;
            delete el.dataset.twixyAvatar;
            delete el.dataset.twixyBadge;
            delete el.dataset.twixyFriendMsg;
        });
        this._hideTooltip(true);
        document.querySelectorAll('[data-a-target="chat-line-message"]').forEach(el => this._addToMessage(el));
        document.querySelectorAll(".seventv-user-message").forEach(el => this._addSevenTvAvatar(el));
    },
    init() {
        this._ensureTooltipUi();
        this._bindGlobalTooltipListeners();
        this._applyFriendHighlightGlobals();
        window.addEventListener("twixy:settingChanged", e => {
            const key = e?.detail?.key;
            if (key === "twixy_friend_highlight_enabled" || key === "twixy_friend_highlight_color") {
                this._applyFriendHighlightGlobals();
                this._refreshFriendHighlightFlags();
            }
        });
        window.addEventListener("twixy:friendsUpdated", () => {
            if (this._friendHighlightEnabled()) this._refreshFriendHighlightFlags();
        });
        this._observer = new MutationObserver(mutations => {
            for (const {addedNodes: addedNodes} of mutations) {
                for (const node of addedNodes) {
                    if (!(node instanceof HTMLElement)) continue;
                    if (node.matches('[data-a-target="chat-line-message"]')) {
                        this._addToMessage(node);
                    } else if (node.querySelector('[data-a-target="chat-line-message"]')) {
                        node.querySelectorAll('[data-a-target="chat-line-message"]').forEach(el => this._addToMessage(el));
                    }
                    if (node.matches(".seventv-user-message")) {
                        this._addSevenTvAvatar(node);
                    } else if (node.querySelector(".seventv-user-message")) {
                        node.querySelectorAll(".seventv-user-message").forEach(el => this._addSevenTvAvatar(el));
                    }
                }
            }
        });
        this._observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        this.refresh();
        this._viewerCardObserver = new MutationObserver(mutations => {
            for (const {addedNodes: addedNodes} of mutations) {
                for (const node of addedNodes) {
                    if (!(node instanceof HTMLElement)) continue;
                    if (node.matches('[data-a-target="viewer-card"]') || node.querySelector('[data-a-target="viewer-card"]')) {
                        node.querySelectorAll(".viewer-card-header__display-name").forEach(h => this._decorateViewerCard(h));
                    }
                    if (node.matches(".seventv-user-card-header")) {
                        this._decorate7tvCard(node);
                    } else if (node.querySelector(".seventv-user-card-header")) {
                        this._decorate7tvCard(node.querySelector(".seventv-user-card-header"));
                    }
                }
            }
        });
        this._viewerCardObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
        window.addEventListener("twixy:langChanged", () => {
            if (this._tooltipEl?.classList.contains("twixy-visible") && this._tooltipAnchor) {
                this._tooltipEl.textContent = this._getBadgeTooltipText();
                this._positionTooltip();
            }
            this.refresh();
        });
    },
    async _decorateViewerCard(header) {
        if (header.dataset.twixyInjected) return;
        header.dataset.twixyInjected = "1";
        const link = header.querySelector("a.tw-link");
        if (!link) return;
        const login = link.getAttribute("href").slice(1).toLowerCase();
        const info = await window.TWIXY.api.friends.lookupUser(login);
        if (!info || info.success !== true) return;
        const translate = window.TWIXY.i18n;
        const icon = document.createElement("img");
        icon.src = chrome.runtime.getURL("icons/menu_icon.svg");
        icon.alt = translate.t("twixyUserLabel");
        icon.title = translate.t("twixyUserLabel");
        icon.className = "twixy-user-icon";
        header.appendChild(icon);
        const label = document.createElement("span");
        label.textContent = translate.t("twixyUserLabel");
        label.className = "twixy-user-label";
        header.appendChild(label);
        const you = await window.TWIXY.auth.getUser();
        if (!you?.login || you.login.toLowerCase() === login) return;
        if (info.user?.can_open_profile) {
            this._appendOpenProfileBtn(header, login);
        }
        const friends = window.TWIXY.friends;
        if (friends.isAlreadyFriend(login)) {
            const mark = document.createElement("span");
            mark.textContent = translate.t("friend");
            mark.className = "twixy-friend-label";
            header.appendChild(mark);
            return;
        }
        if (friends.isOutgoingPending(login)) {
            const mark = document.createElement("span");
            mark.textContent = translate.t("requested");
            mark.className = "twixy-friend-label";
            header.appendChild(mark);
            return;
        }
        this._appendAddFriendBtn(header, login, you);
    },
    async _decorate7tvCard(headerEl) {
        if (headerEl.dataset.twixyInjected) return;
        headerEl.dataset.twixyInjected = "1";
        const cardRoot = headerEl.closest(".seventv-user-card");
        if (!cardRoot) return;
        const actions = cardRoot.querySelector(".seventv-user-card-actions");
        if (!actions) return;
        const nameSpan = headerEl.querySelector(".seventv-chat-user-username span:last-child");
        if (!nameSpan) return;
        const login = nameSpan.textContent.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,25}$/.test(login)) return;
        const info = await window.TWIXY.api.friends.lookupUser(login);
        if (!info || info.success !== true) return;
        const translate = window.TWIXY.i18n;
        const icon = document.createElement("img");
        icon.src = chrome.runtime.getURL("icons/menu_icon.svg");
        icon.className = "twixy-user-icon";
        icon.alt = translate.t("twixyUserLabel");
        actions.appendChild(icon);
        const label = document.createElement("span");
        label.textContent = translate.t("twixyUserLabel");
        label.className = "twixy-user-label";
        actions.appendChild(label);
        const you = await window.TWIXY.auth.getUser();
        if (!you?.login || you.login.toLowerCase() === login) return;
        if (info.user?.can_open_profile) {
            this._appendOpenProfileBtn(actions, login);
        }
        const friends = window.TWIXY.friends;
        if (friends.isAlreadyFriend(login)) {
            const mark = document.createElement("span");
            mark.textContent = translate.t("friend");
            mark.className = "twixy-friend-label";
            actions.appendChild(mark);
            return;
        }
        if (friends.isOutgoingPending(login)) {
            const mark = document.createElement("span");
            mark.textContent = translate.t("requested");
            mark.className = "twixy-friend-label";
            actions.appendChild(mark);
            return;
        }
        this._appendAddFriendBtn(actions, login, you);
    },
    _appendAddFriendBtn(container, targetLogin, you) {
        const translate = window.TWIXY.i18n;
        const btn = document.createElement("button");
        btn.textContent = translate.t("addFriendBtn");
        btn.className = "twixy-add-friend-btn";
        [ "pointerdown", "mousedown" ].forEach(ev => btn.addEventListener(ev, e => {
            e.preventDefault();
            e.stopPropagation();
        }));
        btn.addEventListener("click", async () => {
            const resp = await window.TWIXY.bgMessage({
                action: "twitch_follow",
                username: targetLogin
            });
            if (!resp?.success || !resp.targetUser) return;
            const res = await window.TWIXY.api.friends.send({
                to_username: targetLogin
            });
            if (res) {
                btn.textContent = translate.t("requested");
                btn.disabled = true;
                await window.TWIXY.friends.refresh(you.login);
                window.dispatchEvent(new Event("twixy:friendsUpdated"));
            }
        });
        container.appendChild(btn);
    },
    _appendOpenProfileBtn(container, targetLogin) {
        const translate = window.TWIXY.i18n;
        const btn = document.createElement("button");
        btn.textContent = translate.t("openTwixyProfile");
        btn.className = "twixy-add-friend-btn";
        [ "pointerdown", "mousedown" ].forEach(ev => btn.addEventListener(ev, e => {
            e.preventDefault();
            e.stopPropagation();
        }));
        btn.addEventListener("click", e => {
            e.preventDefault();
            e.stopPropagation();
            window.TWIXY.profile.openCard(targetLogin);
        });
        container.appendChild(btn);
    }
};