"use strict";

window.TWIXY = window.TWIXY || {};

window.TWIXY.autoclaim = {
    _enabled: window.TWIXY.settings?.getBool("twixy_autoclaim") ?? false,
    _observer: null,
    _interval: null,
    get enabled() {
        return this._enabled;
    },
    set enabled(val) {
        this._enabled = val;
        window.TWIXY.settings?.setBool("twixy_autoclaim", val);
    },
    _claim() {
        if (!this._enabled) return;
        const SELECTORS = [ 'button[aria-label="Claim Bonus"]:not([data-twixy-claimed])', 'button[aria-label="Получить бонус"]:not([data-twixy-claimed])' ];
        for (const sel of SELECTORS) {
            const btn = document.querySelector(sel);
            if (btn) {
                btn.click();
                btn.setAttribute("data-twixy-claimed", "true");
            }
        }
    },
    init() {
        this._interval = setInterval(() => this._claim(), 1e3);
        this._observer = new MutationObserver(mutations => {
            if (!this._enabled) return;
            for (const {addedNodes: addedNodes} of mutations) {
                for (const node of addedNodes) {
                    if (!(node instanceof HTMLElement)) continue;
                    const SELECTORS = [ 'button[aria-label="Claim Bonus"]:not([data-twixy-claimed])', 'button[aria-label="Получить бонус"]:not([data-twixy-claimed])' ];
                    for (const sel of SELECTORS) {
                        const btn = node.matches(sel) ? node : node.querySelector(sel);
                        if (btn) {
                            btn.click();
                            btn.setAttribute("data-twixy-claimed", "true");
                        }
                    }
                }
            }
        });
        this._observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    },
    destroy() {
        clearInterval(this._interval);
        this._observer?.disconnect();
    }
};