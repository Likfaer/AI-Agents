"use strict";

window.TWIXY.profile = {
    ICONS: {
        telegram: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M11.944 0A12 12 0 1 0 24 12.056A12.01 12.01 0 0 0 11.944 0Zm4.962 7.166c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472c-.18 1.898-.962 6.502-1.36 8.627c-.168.9-.499 1.201-.82 1.23c-.696.065-1.225-.46-1.9-.902c-1.056-.693-1.653-1.124-2.678-1.8c-1.185-.78-.417-1.21.258-1.91c.177-.184 3.247-2.977 3.307-3.23c.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345c-.48.33-.913.49-1.302.48c-.428-.008-1.252-.241-1.865-.44c-.752-.245-1.349-.374-1.297-.789c.027-.216.325-.437.893-.663c3.498-1.524 5.83-2.529 6.998-3.014c3.332-1.386 4.025-1.627 4.476-1.635Z"/></svg>`,
        discord: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418Z"/></svg>`,
        tiktok: `<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5a2.89 2.89 0 0 1-2.89-2.89a2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.2a6.34 6.34 0 0 0 6.34 6.34a6.34 6.34 0 0 0 6.34-6.34V8.71a8.16 8.16 0 0 0 4.76 1.52v-3.4a4.85 4.85 0 0 1-1-.14Z"/></svg>`,
        link: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,
        profileBtn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="12" cy="10" r="3"/><path d="M7 20v-1a5 5 0 0 1 10 0v1"/></svg>`,
        miniCard: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" class="twixy-mini-card-svg"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="12" cy="10" r="3"/><path d="M7 20v-1a5 5 0 0 1 10 0v1"/></svg>`
    },
    PLATFORMS: {
        telegram: {
            label: "Telegram",
            prefix: "https://t.me/",
            placeholder: "username"
        },
        discord: {
            label: "Discord",
            prefix: null,
            placeholder: "user#0000"
        },
        tiktok: {
            label: "TikTok",
            prefix: "https://tiktok.com/@",
            placeholder: "username"
        }
    },
    EMOJI_CATEGORIES: [ {
        id: "recent",
        name: "⏱️",
        label: "Recent",
        emojis: []
    }, {
        id: "smileys",
        name: "😊",
        label: "Smileys",
        emojis: [ [ "😊", "smile" ], [ "😄", "happy" ], [ "😁", "grin" ], [ "😆", "laugh" ], [ "🤣", "lol" ], [ "😅", "sweat" ], [ "😂", "tears" ], [ "😇", "angel" ], [ "😉", "wink" ], [ "😍", "love eyes" ], [ "🤩", "star eyes" ], [ "🥰", "hearts" ], [ "😘", "kiss" ], [ "😎", "cool" ], [ "🤓", "nerd" ], [ "🧐", "monocle" ], [ "😏", "smirk" ], [ "😌", "relieved" ], [ "😴", "sleep" ], [ "🤔", "think" ], [ "🤫", "shh" ], [ "🤭", "oops" ], [ "🤗", "hug" ], [ "😐", "neutral" ], [ "😑", "blank" ], [ "🙄", "eye roll" ], [ "😤", "angry" ], [ "😡", "rage" ], [ "🥺", "please" ], [ "😢", "cry" ], [ "😭", "sob" ], [ "🤯", "mind blown" ], [ "😱", "scream" ], [ "😰", "anxious" ], [ "😓", "sweat" ], [ "🤮", "sick" ], [ "🥳", "party" ], [ "😈", "devil" ], [ "👻", "ghost" ], [ "💀", "skull" ], [ "🤡", "clown" ], [ "👽", "alien" ], [ "🫡", "salute" ], [ "🫠", "melt" ], [ "🥱", "yawn" ], [ "🤤", "drool" ], [ "😋", "yummy" ], [ "🤑", "money" ] ]
    }, {
        id: "gestures",
        name: "👋",
        label: "Gestures",
        emojis: [ [ "👋", "wave" ], [ "✌️", "peace" ], [ "🤞", "crossed" ], [ "🤟", "love" ], [ "🤙", "call" ], [ "👍", "thumbs up" ], [ "👎", "thumbs down" ], [ "👀", "eyes" ], [ "👁️", "eye" ], [ "🫶", "heart hands" ], [ "🤝", "handshake" ], [ "🙌", "celebrate" ], [ "👏", "clap" ], [ "💪", "strong" ], [ "✊", "fist" ], [ "🤘", "rock" ], [ "☝️", "point" ] ]
    }, {
        id: "hearts",
        name: "❤️",
        label: "Hearts",
        emojis: [ [ "❤️", "red heart" ], [ "🧡", "orange" ], [ "💛", "yellow" ], [ "💚", "green" ], [ "💙", "blue" ], [ "💜", "purple" ], [ "🖤", "black" ], [ "🤍", "white" ], [ "🤎", "brown" ], [ "💔", "broken" ], [ "💖", "sparkle" ], [ "💗", "growing" ], [ "💕", "two hearts" ], [ "💞", "revolving" ], [ "💘", "arrow" ], [ "❣️", "exclamation" ] ]
    }, {
        id: "symbols",
        name: "⭐",
        label: "Symbols",
        emojis: [ [ "⭐", "star" ], [ "🌟", "glow" ], [ "✨", "sparkles" ], [ "⚡", "lightning" ], [ "🔥", "fire" ], [ "💥", "boom" ], [ "❄️", "snow" ], [ "🌈", "rainbow" ], [ "☀️", "sun" ], [ "🌙", "moon" ], [ "⛅", "cloud" ], [ "🌊", "wave" ], [ "💫", "dizzy" ], [ "🎪", "circus" ], [ "♾️", "infinity" ], [ "💯", "100" ], [ "‼️", "double excl" ] ]
    }, {
        id: "gaming",
        name: "🎮",
        label: "Gaming & Tech",
        emojis: [ [ "🎮", "gamepad" ], [ "🕹️", "joystick" ], [ "🎧", "headphones" ], [ "🎵", "music" ], [ "🎶", "notes" ], [ "🎬", "movie" ], [ "🎨", "art" ], [ "🎯", "target" ], [ "🏆", "trophy" ], [ "🎲", "dice" ], [ "🎸", "guitar" ], [ "🎤", "mic" ], [ "📺", "tv" ], [ "💻", "laptop" ], [ "📱", "phone" ], [ "⌨️", "keyboard" ], [ "🖥️", "pc" ], [ "📸", "camera" ], [ "🔧", "wrench" ], [ "⚙️", "gear" ], [ "🤖", "robot" ], [ "📡", "satellite" ] ]
    }, {
        id: "food",
        name: "☕",
        label: "Food & Drink",
        emojis: [ [ "☕", "coffee" ], [ "🍵", "tea" ], [ "🧋", "boba" ], [ "🍺", "beer" ], [ "🥤", "soda" ], [ "🍷", "wine" ], [ "🍕", "pizza" ], [ "🍔", "burger" ], [ "🍟", "fries" ], [ "🌮", "taco" ], [ "🍣", "sushi" ], [ "🍜", "noodle" ], [ "🍰", "cake" ], [ "🍩", "donut" ], [ "🍪", "cookie" ], [ "🍫", "chocolate" ], [ "🍿", "popcorn" ], [ "🥐", "croissant" ] ]
    }, {
        id: "animals",
        name: "🐱",
        label: "Animals",
        emojis: [ [ "🐱", "cat" ], [ "🐶", "dog" ], [ "🐸", "frog" ], [ "🦊", "fox" ], [ "🐻", "bear" ], [ "🐼", "panda" ], [ "🐨", "koala" ], [ "🦄", "unicorn" ], [ "🐙", "octopus" ], [ "🦋", "butterfly" ], [ "🐝", "bee" ], [ "🐧", "penguin" ], [ "🦉", "owl" ], [ "🐢", "turtle" ], [ "🐍", "snake" ], [ "🦈", "shark" ], [ "🐬", "dolphin" ], [ "🐺", "wolf" ] ]
    }, {
        id: "travel",
        name: "✈️",
        label: "Travel",
        emojis: [ [ "🏠", "home" ], [ "✈️", "plane" ], [ "🚀", "rocket" ], [ "🌍", "world" ], [ "⛰️", "mountain" ], [ "🏖️", "beach" ], [ "🎡", "ferris" ], [ "🏕️", "camp" ], [ "🗼", "tower" ], [ "🏰", "castle" ], [ "🚗", "car" ], [ "🚲", "bike" ], [ "⛵", "boat" ], [ "🛸", "ufo" ], [ "🗺️", "map" ] ]
    }, {
        id: "objects",
        name: "💎",
        label: "Objects",
        emojis: [ [ "💤", "zzz" ], [ "💡", "idea" ], [ "🎉", "party" ], [ "🎁", "gift" ], [ "🏴‍☠️", "pirate" ], [ "🛡️", "shield" ], [ "⚔️", "swords" ], [ "💎", "gem" ], [ "🔮", "crystal" ], [ "🧲", "magnet" ], [ "📚", "books" ], [ "✍️", "write" ], [ "📝", "memo" ], [ "🔑", "key" ], [ "💰", "money" ], [ "🎭", "masks" ], [ "🧸", "teddy" ], [ "🪄", "wand" ], [ "🏅", "medal" ], [ "🎖️", "badge" ], [ "📌", "pin" ], [ "🔔", "bell" ], [ "💣", "bomb" ], [ "🧩", "puzzle" ] ]
    }, {
        id: "flags",
        name: "🏁",
        label: "Flags",
        emojis: [ [ "🏁", "checkered" ], [ "🚩", "red flag" ], [ "🏳️", "white" ], [ "🏴", "black" ], [ "🏳️‍🌈", "rainbow flag" ], [ "🇷🇺", "ru" ], [ "🇺🇸", "us" ], [ "🇬🇧", "uk" ], [ "🇩🇪", "de" ], [ "🇫🇷", "fr" ], [ "🇯🇵", "jp" ], [ "🇰🇷", "kr" ], [ "🇧🇷", "br" ], [ "🇺🇦", "ua" ] ]
    } ],
    _recentEmojis: [],
    _loadRecent() {
        try {
            this._recentEmojis = JSON.parse(localStorage.getItem("twixy_recent_emojis") || "[]").slice(0, 16);
        } catch {
            this._recentEmojis = [];
        }
    },
    _addRecent(emoji) {
        if (!emoji) return;
        this._recentEmojis = [ emoji, ...this._recentEmojis.filter(e => e !== emoji) ].slice(0, 16);
        localStorage.setItem("twixy_recent_emojis", JSON.stringify(this._recentEmojis));
    },
    _card: null,
    _ensureUrl(url) {
        if (!url) return "";
        url = url.trim();
        if (/^https?:\/\//i.test(url)) return url;
        if (url.startsWith("//")) return "https:" + url;
        return "https://" + url;
    },
    _defaultAvatarUrl() {
        try {
            return chrome.runtime.getURL("icons/default_avatar.svg");
        } catch {
            return "";
        }
    },
    async openCard(login, triggerEl) {
        this.closeCard();
        const u = String(login || "").trim().toLowerCase();
        if (!u) return;
        const t = window.TWIXY.i18n;
        const me = await window.TWIXY.auth.getUser();
        const isMe = me?.login?.toLowerCase() === u;
        const card = document.createElement("div");
        card.id = "twixy-profile-card";
        card.className = "tpc";
        if (triggerEl) {
            const rect = triggerEl.getBoundingClientRect();
            card.style.left = Math.min(rect.right + 12, window.innerWidth - 380) + "px";
            card.style.top = Math.max(rect.top - 20, 8) + "px";
        } else {
            card.style.left = (window.innerWidth - 360) / 2 + "px";
            card.style.top = Math.max((window.innerHeight - 500) / 2, 40) + "px";
        }
        card.innerHTML = '<div class="tpc-head tpc-drag-handle"><span class="tpc-close">&times;</span></div><div class="tpc-body-area"><div class="tpc-spinner-wrap"><div class="tpc-spinner"></div></div></div>';
        document.body.appendChild(card);
        this._card = card;
        this._makeDraggable(card, card.querySelector(".tpc-drag-handle"));
        card.querySelector(".tpc-close").addEventListener("click", () => this.closeCard());
        const onEsc = e => {
            if (e.key === "Escape") this.closeCard();
        };
        document.addEventListener("keydown", onEsc);
        card._onEsc = onEsc;
        const onClickOutside = e => {
            if (card && !card.contains(e.target)) this.closeCard();
        };
        setTimeout(() => document.addEventListener("mousedown", onClickOutside), 150);
        card._onClickOutside = onClickOutside;
        const [profileResp, avatarResp, noteResp, mutualResp] = await Promise.all([ window.TWIXY.api.profile.get(u), window.TWIXY.bgMessage({
            action: "get_avatar",
            login: u
        }), !isMe ? window.TWIXY.api.profile.getNote(u) : Promise.resolve(null), !isMe ? window.TWIXY.api.profile.getMutual(u) : Promise.resolve(null) ]);
        if (!this._card) return;
        if (profileResp?.error === "Profile is private") {
            card.querySelector(".tpc-body-area").innerHTML = `<div class="tpc-empty">${t.t("profilePrivate")}</div>`;
            return;
        }
        if (profileResp?.rateLimited || profileResp?.networkError) {
            card.querySelector(".tpc-body-area").innerHTML = `<div class="tpc-empty">${t.t("profileLoading")}</div>`;
            if (!this._profileRetryFor || this._profileRetryFor !== u) {
                this._profileRetryFor = u;
                setTimeout(() => {
                    this._profileRetryFor = null;
                    if (this._card && document.body.contains(this._card)) {
                        this.closeCard();
                        this.openCard(login);
                    }
                }, 8e3);
            }
            return;
        }
        const p = profileResp?.profile;
        if (!p) {
            const msg = profileResp?.error === "User not found" ? t.t("profileNotFound") : t.t("profileLoadError");
            card.querySelector(".tpc-body-area").innerHTML = `<div class="tpc-empty">${escapeHTML(msg)}</div>`;
            return;
        }
        const avatarUrl = avatarResp?.url || "";
        const pres = window.TWIXY.friends.presences[u] || {};
        const online = pres.online ?? p.online;
        const watching = pres.currentView || p.stream_slug;
        const noteText = noteResp?.note_text || "";
        let socialsHtml = "";
        const links = p.social_links || {};
        for (const [key, val] of Object.entries(links)) {
            if (key === "custom" || !val) continue;
            const plat = this.PLATFORMS[key];
            if (!plat) continue;
            const href = plat.prefix ? plat.prefix + val.replace(/^@/, "") : null;
            socialsHtml += `<a class="tpc-link" ${href ? `href="${escapeHTML(href)}" target="_blank"` : ""}><span class="tpc-link-icon">${this.ICONS[key] || this.ICONS.link}</span><span class="tpc-link-label">${plat.label}</span><span class="tpc-link-val">${escapeHTML(val)}</span></a>`;
        }
        if (Array.isArray(links.custom)) {
            for (const item of links.custom) {
                if (!item.label || !item.url) continue;
                socialsHtml += `<a class="tpc-link" href="${escapeHTML(this._ensureUrl(item.url))}" target="_blank"><span class="tpc-link-icon">${this.ICONS.link}</span><span class="tpc-link-val">${escapeHTML(item.label)}</span></a>`;
            }
        }
        const dotClass = online ? "tpc-on" : "tpc-off";
        const statusEmoji = p.status_emoji || "";
        const statusLine = p.status_text ? `<div class="tpc-status-text">${statusEmoji ? `<span class="tpc-status-emoji">${statusEmoji}</span> ` : ""}${escapeHTML(p.status_text)}</div>` : statusEmoji ? `<div class="tpc-status-text"><span class="tpc-status-emoji">${statusEmoji}</span></div>` : "";
        const mutualList = Array.isArray(mutualResp?.mutual) ? mutualResp.mutual : [];
        const mutualHtml = mutualList.length ? `\n      <div class="tpc-sect tpc-mutual-sect">\n        <div class="tpc-sect-head">\n          <span>${t.t("mutualFriendsTitle")}</span>\n          <span class="tpc-mutual-count">${mutualList.length}</span>\n        </div>\n        <div class="tpc-mutual-scroll" role="group" aria-label="${t.t("mutualFriendsTitle")}">\n          <div class="tpc-mutual-grid">\n            ${mutualList.map(m => `\n            <button type="button" class="tpc-mutual-item" data-mutual-login="${escapeHTML(m.username)}" title="${escapeHTML(m.username)}">\n              <img class="tpc-mutual-avatar" src="${escapeHTML(this._defaultAvatarUrl())}" data-mutual-avatar="${escapeHTML(m.username)}" alt="">\n              <span class="tpc-mutual-name">${escapeHTML(m.username)}</span>\n            </button>\n          `).join("")}\n          </div>\n        </div>\n      </div>\n    ` : isMe ? "" : `<div class="tpc-sect tpc-mutual-sect"><div class="tpc-sect-head"><span>${t.t("mutualFriendsTitle")}</span></div><div class="tpc-mutual-empty">${t.t("mutualFriendsEmpty")}</div></div>`;
        card.querySelector(".tpc-body-area").innerHTML = `\n      <div class="tpc-profile-head">\n        ${avatarUrl ? `<img class="tpc-avatar" src="${escapeHTML(avatarUrl)}" alt="">` : '<div class="tpc-avatar tpc-avatar-empty"></div>'}\n        <div class="tpc-info"><div class="tpc-name">${escapeHTML(p.username)}</div>\n          <div class="tpc-status-row"><span class="tpc-dot ${dotClass}"></span><span class="tpc-status-lbl">${online ? t.t("online") : t.t("offline")}</span>\n            ${watching ? `<span class="tpc-sep">·</span><a class="tpc-watch-link" href="https://www.twitch.tv/${encodeURIComponent(watching)}" target="_blank">${t.t("watching")} ${escapeHTML(watching)}</a>` : ""}\n          </div>${statusLine}</div></div>\n      ${p.bio ? `<div class="tpc-sect"><div class="tpc-sect-head">${t.t("profileBio")}</div><div class="tpc-bio-text">${escapeHTML(p.bio)}</div></div>` : ""}\n      ${socialsHtml ? `<div class="tpc-sect"><div class="tpc-sect-head">${t.t("profileSocials")}</div><div class="tpc-links">${socialsHtml}</div></div>` : ""}\n      ${mutualHtml}\n      ${!isMe ? `<div class="tpc-sect tpc-note-sect"><div class="tpc-sect-head"><span>${t.t("profileNote")}</span><button class="tpc-note-toggle" id="tpc-note-toggle">${noteText ? t.t("profileNoteEdit") : t.t("profileNoteAdd")}</button></div>${noteText ? `<div class="tpc-note-preview" id="tpc-note-preview">${escapeHTML(noteText)}</div>` : ""}<div class="tpc-note-editor" id="tpc-note-editor" style="display:none"><textarea class="tpc-note-ta" id="tpc-note-ta" maxlength="500" placeholder="${t.t("profileNotePlaceholder")}">${escapeHTML(noteText)}</textarea><div class="tpc-note-bar"><span class="tpc-note-count"><span id="tpc-note-count">${noteText.length}</span>/500</span><button class="tpc-note-save" id="tpc-note-save">${t.t("profileNoteSave")}</button><span class="tpc-note-msg" id="tpc-note-msg"></span></div></div></div>` : ""}\n      ${isMe ? `<div class="tpc-sect tpc-hint">${t.t("profileEditHint")}</div>` : ""}\n      <div class="tpc-foot">${t.t("profileJoined")} ${new Date(p.created_at).toLocaleDateString()}</div>`;
        card.querySelectorAll(".tpc-mutual-item").forEach(btn => {
            const login = btn.dataset.mutualLogin;
            if (!login) return;
            btn.addEventListener("click", e => {
                e.stopPropagation();
                this.openCard(login, btn);
            });
        });
        card.querySelectorAll("img[data-mutual-avatar]").forEach(img => {
            const login = img.getAttribute("data-mutual-avatar");
            if (!login) return;
            window.TWIXY.bgMessage({
                action: "get_avatar",
                login: login
            }).then(resp => {
                if (resp?.url && img.isConnected) img.src = resp.url;
            });
        });
        const noteToggle = card.querySelector("#tpc-note-toggle"), noteEditor = card.querySelector("#tpc-note-editor"), notePreview = card.querySelector("#tpc-note-preview");
        if (noteToggle) {
            noteToggle.addEventListener("click", () => {
                const s = noteEditor.style.display !== "none";
                noteEditor.style.display = s ? "none" : "";
                if (notePreview) notePreview.style.display = s ? "" : "none";
                if (!s) card.querySelector("#tpc-note-ta")?.focus();
            });
        }
        const noteTa = card.querySelector("#tpc-note-ta");
        if (noteTa) noteTa.addEventListener("input", () => {
            card.querySelector("#tpc-note-count").textContent = noteTa.value.length;
        });
        const noteSave = card.querySelector("#tpc-note-save");
        if (noteSave) {
            noteSave.addEventListener("click", async () => {
                const msg = card.querySelector("#tpc-note-msg");
                msg.textContent = "...";
                msg.className = "tpc-note-msg";
                const res = await window.TWIXY.api.profile.updateNote(u, noteTa.value);
                if (res?.success) {
                    msg.textContent = "✓";
                    msg.classList.add("tpc-ok");
                    if (notePreview) {
                        notePreview.textContent = noteTa.value;
                        notePreview.style.display = "";
                    }
                    noteEditor.style.display = "none";
                    if (noteToggle) noteToggle.textContent = noteTa.value ? t.t("profileNoteEdit") : t.t("profileNoteAdd");
                } else {
                    msg.textContent = "✗";
                    msg.classList.add("tpc-err");
                }
                setTimeout(() => {
                    msg.textContent = "";
                }, 2e3);
            });
        }
    },
    closeCard() {
        if (this._card) {
            if (this._card._onEsc) document.removeEventListener("keydown", this._card._onEsc);
            if (this._card._onClickOutside) document.removeEventListener("mousedown", this._card._onClickOutside);
            this._card.remove();
            this._card = null;
        }
    },
    _makeDraggable(el, handle) {
        let d = false, sx, sy, ox, oy;
        handle.style.cursor = "grab";
        handle.addEventListener("mousedown", e => {
            if (e.target.closest(".tpc-close")) return;
            e.preventDefault();
            d = true;
            handle.style.cursor = "grabbing";
            const r = el.getBoundingClientRect();
            ox = r.left;
            oy = r.top;
            sx = e.clientX;
            sy = e.clientY;
            const onM = ev => {
                if (!d) return;
                el.style.left = Math.max(0, Math.min(ox + ev.clientX - sx, window.innerWidth - el.offsetWidth)) + "px";
                el.style.top = Math.max(0, Math.min(oy + ev.clientY - sy, window.innerHeight - el.offsetHeight)) + "px";
            };
            const onU = () => {
                d = false;
                handle.style.cursor = "grab";
                document.removeEventListener("mousemove", onM);
                document.removeEventListener("mouseup", onU);
            };
            document.addEventListener("mousemove", onM);
            document.addEventListener("mouseup", onU);
        });
    },
    _buildEmojiPickerHTML(currentEmoji) {
        this._loadRecent();
        const cats = this.EMOJI_CATEGORIES.map(c => c.id === "recent" ? {
            ...c,
            emojis: this._recentEmojis.map(e => [ e, "" ])
        } : c);
        const tabs = cats.filter(c => c.id !== "recent" || c.emojis.length > 0).map(c => `<span class="tpe-ep-tab" data-cat="${c.id}" title="${c.label}">${c.name}</span>`).join("");
        const sections = cats.filter(c => c.emojis.length > 0).map(c => `\n      <div class="tpe-ep-section" data-cat="${c.id}">\n        <div class="tpe-ep-cat-label">${c.label}</div>\n        <div class="tpe-ep-grid">${c.emojis.map(([em, kw]) => `<span class="tpe-ep-em ${em === currentEmoji ? "active" : ""}" data-emoji="${em}" data-kw="${kw}" title="${kw || em}">${em}</span>`).join("")}</div>\n      </div>\n    `).join("");
        return `\n      <div class="tpe-ep">\n        <div class="tpe-ep-search-row">\n          <input class="tpe-ep-search" type="text" placeholder="Search emoji..." autocomplete="off">\n          <span class="tpe-ep-clear" title="Clear">✕</span>\n        </div>\n        <div class="tpe-ep-tabs">${tabs}</div>\n        <div class="tpe-ep-body">${sections}</div>\n      </div>\n    `;
    },
    _wireEmojiPicker(container, emojiSelBtn, onSelect) {
        const searchInput = container.querySelector(".tpe-ep-search");
        const clearBtn = container.querySelector(".tpe-ep-clear");
        const body = container.querySelector(".tpe-ep-body");
        const tabs = container.querySelectorAll(".tpe-ep-tab");
        const allEmojis = container.querySelectorAll(".tpe-ep-em");
        const allSections = container.querySelectorAll(".tpe-ep-section");
        searchInput?.addEventListener("input", () => {
            const q = searchInput.value.toLowerCase().trim();
            if (!q) {
                allSections.forEach(s => s.style.display = "");
                allEmojis.forEach(e => e.style.display = "");
                return;
            }
            allSections.forEach(sec => {
                const ems = sec.querySelectorAll(".tpe-ep-em");
                let any = false;
                ems.forEach(em => {
                    const match = em.dataset.emoji.includes(q) || (em.dataset.kw || "").includes(q);
                    em.style.display = match ? "" : "none";
                    if (match) any = true;
                });
                sec.style.display = any ? "" : "none";
            });
        });
        clearBtn?.addEventListener("click", () => {
            onSelect("");
            emojiSelBtn.textContent = "😊";
            container.style.display = "none";
        });
        tabs.forEach(tab => {
            tab.addEventListener("click", () => {
                const target = body.querySelector(`.tpe-ep-section[data-cat="${tab.dataset.cat}"]`);
                if (target) target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
                searchInput.value = "";
                allSections.forEach(s => s.style.display = "");
                allEmojis.forEach(e => e.style.display = "");
            });
        });
        allEmojis.forEach(em => {
            em.addEventListener("click", () => {
                allEmojis.forEach(e => e.classList.remove("active"));
                em.classList.add("active");
                const emoji = em.dataset.emoji;
                this._addRecent(emoji);
                onSelect(emoji);
                emojiSelBtn.textContent = emoji || "😊";
                container.style.display = "none";
            });
        });
    },
    async renderEditTab(section) {
        if (!section) return;
        const t = window.TWIXY.i18n;
        const me = await window.TWIXY.auth.getUser();
        if (!me?.login) {
            section.innerHTML = `<p style="color:#aaa">${t.t("profileLoginRequired")}</p>`;
            return;
        }
        section.innerHTML = '<div class="tpc-spinner-wrap"><div class="tpc-spinner"></div></div>';
        const [resp, avatarResp, profileVisibilityResp] = await Promise.all([ window.TWIXY.api.profile.get(me.login), window.TWIXY.bgMessage({
            action: "get_avatar",
            login: me.login
        }), window.TWIXY.api.settings.getProfileVisibility(me.login) ]);
        const p = resp?.profile || {
            username: me.display_name || me.login,
            created_at: null,
            status_text: "",
            status_emoji: "",
            bio: "",
            social_links: {}
        };
        const links = p.social_links || {};
        const avatarUrl = avatarResp?.url || "";
        const currentEmoji = p.status_emoji || "";
        const profilePublic = profileVisibilityResp?.profilePublic ?? p.profile_public ?? true;
        const platformRows = Object.entries(this.PLATFORMS).map(([key, plat]) => `\n      <div class="tpe-soc-row">\n        <span class="tpe-soc-icon">${this.ICONS[key]}</span>\n        <span class="tpe-soc-name">${plat.label}</span>\n        <input class="tpe-soc-input" data-platform="${key}" type="text" value="${escapeHTML(links[key] || "")}" placeholder="${plat.placeholder}" maxlength="100">\n      </div>\n    `).join("");
        const customLinks = Array.isArray(links.custom) ? links.custom : [];
        const customRows = [ 0, 1, 2 ].map(i => {
            const item = customLinks[i] || {
                label: "",
                url: ""
            };
            return `<div class="tpe-custom-row">\n        <input class="tpe-custom-label" data-idx="${i}" type="text" value="${escapeHTML(item.label)}" placeholder="${t.t("profileCustomLabel")}" maxlength="30">\n        <input class="tpe-custom-url" data-idx="${i}" type="text" value="${escapeHTML(item.url)}" placeholder="example.com" maxlength="200">\n      </div>`;
        }).join("");
        const emojiPickerHTML = this._buildEmojiPickerHTML(currentEmoji);
        section.innerHTML = `\n      <div class="tpe-min">\n        <div class="tpe-min-cols">\n          <div class="tpe-min-editor">\n            <div class="tpe-min-group">\n              <div class="tpe-min-label">${t.t("profileStatus")}</div>\n              <div class="tpe-min-status-row">\n                <span class="tpe-min-emoji-btn" id="tpe-emoji-sel">${currentEmoji || "😊"}</span>\n                <input class="tpe-min-input" id="tpe-status" type="text" value="${escapeHTML(p.status_text)}" maxlength="100" placeholder="${t.t("profileStatusPlaceholder")}">\n                <span class="tpe-min-counter"><span id="tpe-status-cnt">${(p.status_text || "").length}</span>/100</span>\n              </div>\n              <div id="tpe-emoji-picker-wrap" style="display:none">${emojiPickerHTML}</div>\n            </div>\n            <div class="tpe-min-group">\n              <div class="tpe-min-label">${t.t("profileBio")} <span class="tpe-min-counter-inline"><span id="tpe-bio-cnt">${(p.bio || "").length}</span>/500</span></div>\n              <textarea class="tpe-min-textarea" id="tpe-bio" maxlength="500" placeholder="${t.t("profileBioPlaceholder")}">${escapeHTML(p.bio)}</textarea>\n            </div>\n            <div class="tpe-min-group">\n              <div class="tpe-min-label">${t.t("profileSocials")}</div>\n              ${platformRows}\n            </div>\n            <div class="tpe-min-group">\n              <div class="tpe-min-label">${t.t("profileCustomLinks")}</div>\n              ${customRows}\n            </div>\n            <div class="tpe-min-group tpe-privacy-group">\n              <div class="friends-subtitle">${t.t("profileVisibilityTitle")}</div>\n              <div class="friends-subdesc tpe-privacy-desc">${t.t("profileVisibilityDesc")}</div>\n              <div class="friends-position-toggle tpe-privacy-toggle" role="group" aria-label="${t.t("profileVisibilityTitle")}">\n                <button type="button" class="friends-position-btn ${profilePublic ? "active" : ""}" data-value="public">${t.t("profileVisibilityPublic")}</button>\n                <button type="button" class="friends-position-btn ${!profilePublic ? "active" : ""}" data-value="friends">${t.t("profileVisibilityFriends")}</button>\n              </div>\n            </div>\n          </div>\n          <div class="tpe-min-preview">\n            <div class="tpe-min-preview-label">${t.t("profilePreview")}</div>\n            <div class="tpe-min-preview-card" id="tpe-live-preview"></div>\n            <button class="tpe-min-open-card" id="tpe-open-card">${t.t("profileOpenCardPreview")}</button>\n            <div class="tpe-min-preview-actions">\n              <button class="tpe-min-save" id="tpe-save">${t.t("profileSave")}</button>\n              <span class="tpe-min-msg" id="tpe-msg"></span>\n            </div>\n          </div>\n        </div>\n      </div>\n    `;
        let selectedEmoji = currentEmoji;
        let selectedProfilePublic = !!profilePublic;
        const livePreview = section.querySelector("#tpe-live-preview");
        const emojiSelBtn = section.querySelector("#tpe-emoji-sel");
        const emojiWrap = section.querySelector("#tpe-emoji-picker-wrap");
        const refreshPreview = () => {
            const statusText = section.querySelector("#tpe-status")?.value || "";
            const bio = section.querySelector("#tpe-bio")?.value || "";
            const sl = {};
            section.querySelectorAll(".tpe-soc-input").forEach(inp => {
                const v = inp.value.trim();
                if (v) sl[inp.dataset.platform] = v;
            });
            const custom = [];
            for (let i = 0; i < 3; i++) {
                const label = section.querySelector(`.tpe-custom-label[data-idx="${i}"]`)?.value.trim();
                const url = section.querySelector(`.tpe-custom-url[data-idx="${i}"]`)?.value.trim();
                if (label && url) custom.push({
                    label: label,
                    url: this._ensureUrl(url)
                });
            }
            if (custom.length) sl.custom = custom;
            this._renderMiniPreview(livePreview, {
                username: p.username,
                status_text: statusText,
                status_emoji: selectedEmoji,
                bio: bio,
                social_links: sl,
                created_at: p.created_at
            }, avatarUrl);
        };
        refreshPreview();
        section.querySelector("#tpe-status")?.addEventListener("input", e => {
            section.querySelector("#tpe-status-cnt").textContent = e.target.value.length;
            refreshPreview();
        });
        section.querySelector("#tpe-bio")?.addEventListener("input", e => {
            section.querySelector("#tpe-bio-cnt").textContent = e.target.value.length;
            refreshPreview();
        });
        section.querySelectorAll(".tpe-soc-input, .tpe-custom-label, .tpe-custom-url").forEach(inp => inp.addEventListener("input", refreshPreview));
        section.querySelectorAll(".tpe-privacy-toggle .friends-position-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                selectedProfilePublic = btn.dataset.value === "public";
                section.querySelectorAll(".tpe-privacy-toggle .friends-position-btn").forEach(el => el.classList.remove("active"));
                btn.classList.add("active");
            });
        });
        emojiSelBtn?.addEventListener("click", () => {
            emojiWrap.style.display = emojiWrap.style.display === "none" ? "" : "none";
        });
        this._wireEmojiPicker(emojiWrap, emojiSelBtn, emoji => {
            selectedEmoji = emoji;
            refreshPreview();
        });
        section.querySelector("#tpe-open-card")?.addEventListener("click", () => this.openCard(me.login));
        section.querySelector("#tpe-save")?.addEventListener("click", async () => {
            const msg = section.querySelector("#tpe-msg");
            msg.textContent = "...";
            msg.className = "tpe-min-msg";
            const social_links = {};
            section.querySelectorAll(".tpe-soc-input").forEach(inp => {
                const v = inp.value.trim();
                if (v) social_links[inp.dataset.platform] = v;
            });
            const custom = [];
            for (let i = 0; i < 3; i++) {
                const label = section.querySelector(`.tpe-custom-label[data-idx="${i}"]`)?.value.trim();
                let url = section.querySelector(`.tpe-custom-url[data-idx="${i}"]`)?.value.trim();
                if (label && url) {
                    url = this._ensureUrl(url);
                    custom.push({
                        label: label,
                        url: url
                    });
                }
            }
            if (custom.length) social_links.custom = custom;
            const [res, visibilityRes] = await Promise.all([ window.TWIXY.api.profile.update({
                status_text: section.querySelector("#tpe-status").value,
                status_emoji: selectedEmoji,
                bio: section.querySelector("#tpe-bio").value,
                social_links: social_links
            }), window.TWIXY.api.settings.setProfileVisibility(selectedProfilePublic) ]);
            if (res?.success && visibilityRes?.success) {
                msg.textContent = "✓ " + t.t("profileSaved");
                msg.classList.add("tpe-ok");
            } else {
                msg.textContent = "✗ " + (res?.error || "Error");
                msg.classList.add("tpe-err");
            }
            setTimeout(() => {
                msg.textContent = "";
            }, 3e3);
        });
    },
    _renderMiniPreview(container, data, avatarUrl) {
        if (!container) return;
        const t = window.TWIXY.i18n;
        const links = data.social_links || {};
        let linksHtml = "";
        for (const [key, val] of Object.entries(links)) {
            if (!val || key === "custom") continue;
            const plat = this.PLATFORMS[key];
            if (!plat) continue;
            linksHtml += `<div class="tpe-pv-link">${this.ICONS[key] || this.ICONS.link} <span>${plat.label}:</span> <span class="tpe-pv-link-val">${escapeHTML(val)}</span></div>`;
        }
        if (Array.isArray(links.custom)) {
            for (const item of links.custom) {
                if (!item?.label || !item?.url) continue;
                linksHtml += `<div class="tpe-pv-link">${this.ICONS.link} <span class="tpe-pv-link-val">${escapeHTML(item.label)}</span></div>`;
            }
        }
        const emoji = data.status_emoji || "", status = data.status_text || "", bio = data.bio || "";
        container.innerHTML = `\n      <div class="tpe-pv-head">${avatarUrl ? `<img class="tpe-pv-avatar" src="${escapeHTML(avatarUrl)}" alt="">` : '<div class="tpe-pv-avatar tpe-pv-avatar-empty"></div>'}\n        <div><div class="tpe-pv-name">${escapeHTML(data.username || "")}</div><div class="tpe-pv-online"><span class="tpe-pv-dot"></span> ${t.t("online")}</div></div></div>\n      ${emoji || status ? `<div class="tpe-pv-status">${emoji ? `<span>${emoji}</span> ` : ""}${escapeHTML(status)}</div>` : ""}\n      ${bio ? `<div class="tpe-pv-section"><div class="tpe-pv-section-title">${t.t("profileBio")}</div><div class="tpe-pv-bio">${escapeHTML(bio)}</div></div>` : ""}\n      ${linksHtml ? `<div class="tpe-pv-section"><div class="tpe-pv-section-title">${t.t("profileSocials")}</div>${linksHtml}</div>` : ""}\n      <div class="tpe-pv-footer">${t.t("profileJoined")} ${data.created_at ? new Date(data.created_at).toLocaleDateString() : "—"}</div>`;
    }
};