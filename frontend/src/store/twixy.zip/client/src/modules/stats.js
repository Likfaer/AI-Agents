"use strict";

window.TWIXY.stats = {
    STORAGE_KEY: "twixy_personal_stats_v2",
    LEGACY_KEY: "twixy_personal_stats_v1",
    WATCH_INTERVAL_MS: 2e3,
    WATCH_CAP_MS: 4e3,
    SERVER_FLUSH_MS: 8e3,
    _saveTimer: null,
    _state: null,
    _serverPeriods: null,
    _dirty: false,
    _lastServerFlushAt: 0,
    _watchAnchor: null,
    _watchTimer: null,
    _flushTimer: null,
    _pointsDomTimer: null,
    _hookInstalled: false,
    _initialized: false,
    _onGqlBound: null,
    _onNavBound: null,
    _onVisBound: null,
    _onHiddenBound: null,
    _liveHint: new Map,
    _meLogin: null,
    _chatDomObserver: null,
    _chatDomGraceUntil: 0,
    _ircSeenIds: new Set,
    _ircLastSeenAt: 0,
    IRC_HEALTHY_WINDOW_MS: 6e4,
    _onIrcMsgBound: null,
    async refresh() {
        this._serverPeriods = null;
        const ok = await window.TWIXY.auth.isLoggedIn();
        if (ok) {
            try {
                const r = await window.TWIXY.api.stats.getMe(this._localDateKey());
                if (r?.success && r.periods) this._serverPeriods = r.periods;
            } catch {}
        }
    },
    _emptyState() {
        return {
            version: 2,
            carryover: {
                messages: {},
                watchLiveMs: {},
                points: {}
            },
            days: {}
        };
    },
    _localDateKey(d = new Date) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        return `${y}-${m}-${day}`;
    },
    _dateKeysForLastNDays(n) {
        const keys = [];
        for (let i = 0; i < n; i++) {
            const d = new Date;
            d.setHours(12, 0, 0, 0);
            d.setDate(d.getDate() - i);
            keys.push(this._localDateKey(d));
        }
        return keys;
    },
    async _load() {
        try {
            const raw = await window.TWIXY.storageGet([ this.STORAGE_KEY, this.LEGACY_KEY ]);
            let v = raw[this.STORAGE_KEY];
            const legacy = raw[this.LEGACY_KEY];
            if (!v || typeof v !== "object" || v.version !== 2) {
                v = this._emptyState();
            } else {
                v = {
                    version: 2,
                    carryover: {
                        messages: {
                            ...v.carryover?.messages || {}
                        },
                        watchLiveMs: {
                            ...v.carryover?.watchLiveMs || {}
                        },
                        points: {
                            ...v.carryover?.points || {}
                        }
                    },
                    days: {
                        ...v.days || {}
                    }
                };
            }
            if (legacy && typeof legacy === "object" && !v.carryover._migratedFromV1) {
                const m = legacy.messages || {};
                const p = legacy.points || {};
                for (const [login, n] of Object.entries(m)) {
                    const L = this._normLogin(login);
                    if (!L) continue;
                    v.carryover.messages[L] = (v.carryover.messages[L] || 0) + (Number(n) || 0);
                }
                for (const [login, n] of Object.entries(p)) {
                    const L = this._normLogin(login);
                    if (!L) continue;
                    v.carryover.points[L] = Math.max(v.carryover.points[L] || 0, Number(n) || 0);
                }
                v.carryover._migratedFromV1 = true;
                await window.TWIXY.storageSet({
                    [this.STORAGE_KEY]: v
                });
                await window.TWIXY.storageRemove(this.LEGACY_KEY);
            }
            this._state = v;
            this._pruneOldDays(400);
        } catch {
            this._state = this._emptyState();
        }
    },
    _pruneOldDays(keep) {
        const keys = Object.keys(this._state.days || {}).sort();
        if (keys.length <= keep) return;
        const drop = keys.slice(0, keys.length - keep);
        for (const k of drop) delete this._state.days[k];
    },
    _scheduleSave() {
        clearTimeout(this._saveTimer);
        this._saveTimer = setTimeout(() => {
            this._saveTimer = null;
            this._pruneOldDays(400);
            window.TWIXY.storageSet({
                [this.STORAGE_KEY]: this._state
            }).catch(() => {});
        }, 400);
    },
    _markDirty() {
        this._dirty = true;
        try {
            window.dispatchEvent(new CustomEvent("twixy:statsUpdated"));
        } catch {}
    },
    async _flushServerSnapshot(force = false) {
        if (!force && !this._dirty) return;
        if (!await window.TWIXY.auth.isLoggedIn()) return;
        const day = this._localDateKey();
        const bucket = this._state?.days?.[day];
        if (!bucket || typeof bucket !== "object") return;
        const snapshot = {};
        for (const [login, cell] of Object.entries(bucket)) {
            const L = this._normLogin(login);
            if (!L || !cell) continue;
            const m = Number(cell.m) || 0;
            const w = Number(cell.w) || 0;
            const p = cell.p == null ? null : Number(cell.p);
            if (m === 0 && w === 0 && (p == null || p === 0)) continue;
            snapshot[L] = {
                m: m,
                w: w,
                p: p == null || !Number.isFinite(p) ? null : p
            };
        }
        if (!Object.keys(snapshot).length) {
            this._dirty = false;
            return;
        }
        try {
            await window.TWIXY.api.stats.sync({
                day: day,
                snapshot: snapshot
            });
            this._dirty = false;
            this._lastServerFlushAt = Date.now();
        } catch {}
    },
    _normLogin(s) {
        const x = String(s ?? "").trim().toLowerCase();
        return /^[a-z0-9_]{3,25}$/.test(x) ? x : "";
    },
    _pageChannel() {
        const path = location.pathname.replace(/^\//, "");
        const direct = window.TWIXY.getStreamerFromPath(path);
        if (direct) return direct;
        const m = path.match(/^popout\/([a-z0-9_]{3,25})\//i);
        return m ? m[1].toLowerCase() : null;
    },
    _ensureDayCell(login) {
        const dk = this._localDateKey();
        if (!this._state.days[dk]) this._state.days[dk] = {};
        if (!this._state.days[dk][login]) this._state.days[dk][login] = {
            m: 0,
            w: 0,
            p: 0
        };
        return this._state.days[dk][login];
    },
    _bumpMessages(login, n = 1) {
        const L = this._normLogin(login);
        if (!L || n <= 0) return;
        const c = this._ensureDayCell(L);
        c.m += n;
        this._scheduleSave();
        this._markDirty();
    },
    _loginFromTwitchChatLine(msgNode) {
        const container = msgNode.querySelector?.(".chat-line__username-container");
        if (!container) return "";
        const usernameEl = container.querySelector(".chat-author__display-name");
        if (!usernameEl) return "";
        const raw = (usernameEl.getAttribute("data-a-user") || usernameEl.textContent || "").trim().toLowerCase();
        return this._normLogin(raw);
    },
    _loginFromSevenTvLine(msgNode) {
        const nameEl = msgNode.querySelector?.(".seventv-chat-user-username");
        if (!nameEl) return "";
        const matches = nameEl.textContent.match(/\(([^)]+)\)$/);
        const raw = (matches ? matches[1] : nameEl.textContent).trim().toLowerCase();
        return this._normLogin(raw);
    },
    _detectMeLogin() {
        const fromAuth = this._normLogin(this._meLogin);
        if (fromAuth) return fromAuth;
        try {
            const raw = document.cookie || "";
            const m = raw.match(/(?:^|;\s*)login=([^;]+)/i);
            if (m) {
                const decoded = decodeURIComponent(m[1]).trim().toLowerCase();
                const norm = this._normLogin(decoded);
                if (norm) return norm;
            }
        } catch {}
        return "";
    },
    _ircIsHealthy() {
        return this._ircLastSeenAt > 0 && Date.now() - this._ircLastSeenAt < this.IRC_HEALTHY_WINDOW_MS;
    },
    _tryCountOwnMessageFromChatDom(msgNode, isSevenTv) {
        if (!(msgNode instanceof HTMLElement) || msgNode.dataset.twixyStatsMsg) return;
        msgNode.dataset.twixyStatsMsg = "1";
        if (Date.now() < this._chatDomGraceUntil) return;
        if (this._ircIsHealthy()) return;
        const me = this._detectMeLogin();
        if (!me) return;
        const slug = this._pageChannel();
        if (!slug) return;
        const author = isSevenTv ? this._loginFromSevenTvLine(msgNode) : this._loginFromTwitchChatLine(msgNode);
        if (!author || author !== me) return;
        this._bumpMessages(slug, 1);
    },
    _handleIrcPrivmsg(evtData) {
        const id = String(evtData?.id || "");
        const login = this._normLogin(evtData?.login);
        const channel = this._normLogin(evtData?.channel);
        if (!id || !login || !channel) return;
        this._ircLastSeenAt = Date.now();
        const me = this._detectMeLogin();
        if (!me || login !== me) return;
        if (this._ircSeenIds.has(id)) return;
        this._ircSeenIds.add(id);
        while (this._ircSeenIds.size > 800) {
            const first = this._ircSeenIds.values().next().value;
            this._ircSeenIds.delete(first);
        }
        this._bumpMessages(channel, 1);
    },
    _flushAddedNodesForChatStats(node) {
        if (!(node instanceof HTMLElement)) return;
        if (node.matches?.('[data-a-target="chat-line-message"]')) {
            this._tryCountOwnMessageFromChatDom(node, false);
        } else {
            node.querySelectorAll?.('[data-a-target="chat-line-message"]').forEach(el => {
                this._tryCountOwnMessageFromChatDom(el, false);
            });
        }
        if (node.matches?.(".seventv-user-message")) {
            this._tryCountOwnMessageFromChatDom(node, true);
        } else {
            node.querySelectorAll?.(".seventv-user-message").forEach(el => {
                this._tryCountOwnMessageFromChatDom(el, true);
            });
        }
    },
    _startChatDomObserver() {
        if (this._chatDomObserver) return;
        this._chatDomGraceUntil = Date.now() + 2800;
        this._chatDomObserver = new MutationObserver(mutations => {
            for (const {addedNodes: addedNodes} of mutations) {
                for (const n of addedNodes) {
                    this._flushAddedNodesForChatStats(n);
                }
            }
        });
        try {
            this._chatDomObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        } catch {
            this._chatDomObserver = null;
        }
    },
    _stopChatDomObserver() {
        if (this._chatDomObserver) {
            try {
                this._chatDomObserver.disconnect();
            } catch {}
            this._chatDomObserver = null;
        }
    },
    _bumpWatchLiveMs(login, ms) {
        const L = this._normLogin(login);
        if (!L || ms <= 0) return;
        const c = this._ensureDayCell(L);
        c.w += ms;
        this._scheduleSave();
        this._markDirty();
    },
    _setPointsSnapshot(login, balance) {
        const L = this._normLogin(login);
        if (!L || balance == null || !Number.isFinite(balance)) return;
        const n = Math.max(0, Math.round(balance));
        if (n > 2e8) return;
        const c = this._ensureDayCell(L);
        const prev = c.p || 0;
        if (prev > 0 && n > prev * 25 && n > 5e5) return;
        if (n === prev) return;
        c.p = n;
        this._scheduleSave();
        this._markDirty();
    },
    _setLiveHint(login, isLive) {
        const L = this._normLogin(login);
        if (!L) return;
        this._liveHint.set(L, {
            live: !!isLive,
            at: Date.now()
        });
    },
    _isDomLiveStream() {
        if (document.querySelector('[data-a-target="stream-live-badge"]')) return true;
        if (document.querySelector('[data-a-target="StreamerLiveStatus"]')) return true;
        const liveSvg = document.querySelector('svg[title="LIVE"], svg[title="В ЭФИРЕ"]');
        if (liveSvg?.closest("div, a, button")) return true;
        return false;
    },
    _isOfflineChannelUi() {
        if (document.querySelector('[data-a-target="host-channel-content"]')) return false;
        return !!(document.querySelector('[data-a-target="off-line-banner"]') || document.querySelector('[data-a-target="channel-header-offline"]'));
    },
    _gqlSaysChannelLive(slug) {
        const L = this._normLogin(slug);
        if (!L) return null;
        const row = this._liveHint.get(L);
        if (!row) return null;
        if (Date.now() - row.at > 12e4) return null;
        return row.live;
    },
    _shouldCountLiveWatch(slug) {
        const L = this._normLogin(slug);
        if (!L || L !== this._pageChannel()) return false;
        if (document.visibilityState !== "visible") return false;
        if (!document.hasFocus?.() && document.visibilityState !== "visible") return false;
        if (/^\/videos\//i.test(location.pathname)) return false;
        const v = document.querySelector("video");
        if (!v || v.paused || v.ended) return false;
        if (v.readyState < 2) return false;
        if (this._isDomLiveStream()) return true;
        if (this._gqlSaysChannelLive(L) === true) return true;
        if (!this._isOfflineChannelUi() && v.currentTime > 0) return true;
        return false;
    },
    _tickWatchtime() {
        const now = Date.now();
        const slug = this._pageChannel();
        const should = !!slug && this._shouldCountLiveWatch(slug);
        if (!should) {
            this._watchAnchor = null;
            return;
        }
        if (this._watchAnchor == null) {
            this._watchAnchor = now;
            return;
        }
        const elapsed = now - this._watchAnchor;
        this._watchAnchor = now;
        if (elapsed < 250) return;
        const dt = Math.min(Math.max(0, elapsed), this.WATCH_CAP_MS);
        this._bumpWatchLiveMs(slug, dt);
    },
    _ingestStreamLiveFromData(data) {
        if (!data || typeof data !== "object") return;
        const apply = node => {
            if (!node || typeof node !== "object") return;
            const login = this._normLogin(node.login);
            const st = node.stream;
            if (!login || !st || typeof st !== "object") return;
            const typ = String(st.type || "").toLowerCase();
            if (typ === "live") this._setLiveHint(login, true); else if (typ === "vod" || typ === "archive" || typ === "rerun" || typ === "playlist") {
                this._setLiveHint(login, false);
            }
        };
        const walk = (obj, depth = 0) => {
            if (!obj || typeof obj !== "object" || depth > 6) return;
            if (obj.user) apply(obj.user);
            if (obj.channel) apply(obj.channel);
            for (const k of Object.keys(obj)) {
                if (k === "__typename") continue;
                walk(obj[k], depth + 1);
            }
        };
        walk(data);
    },
    _ingestPointsFromData(data, pageCh) {
        const page = this._normLogin(pageCh);
        if (!page || !data || typeof data !== "object") return;
        const tryNode = node => {
            if (!node || typeof node !== "object") return;
            const login = this._normLogin(node.login);
            if (login && login !== page) return;
            if (node.self && typeof node.self.currentBalance === "number") {
                this._setPointsSnapshot(page, node.self.currentBalance);
            }
            if (typeof node.currentBalance === "number") {
                this._setPointsSnapshot(page, node.currentBalance);
            }
        };
        const cp = data.communityPoints;
        if (cp?.channel) tryNode(cp.channel);
        if (data.channel && (data.channel.self || data.channel.communityPoints)) {
            tryNode(data.channel);
            if (data.channel.communityPoints) tryNode(data.channel.communityPoints);
        }
    },
    _parsePointsFromDom() {
        const slug = this._pageChannel();
        if (!slug) return;
        const summary = document.querySelector('[data-test-selector="community-points-summary"]') || document.querySelector('[data-a-target="community-points-summary"]');
        if (!summary) return;
        const copo = summary.querySelector('[data-test-selector="copo-balance-string"]');
        const scope = copo || summary;
        const animated = scope.querySelector(".ScAnimatedNumber-sc-1iib0w9-0");
        const raw = (animated?.textContent || scope.textContent || "").replace(/\u00a0/g, " ").replace(/\s+/g, "").trim();
        const digits = raw.replace(/[^\d]/g, "");
        if (!digits || digits.length > 9) return;
        const n = parseInt(digits, 10);
        if (!Number.isFinite(n) || n < 0 || n > 2e8) return;
        this._setPointsSnapshot(slug, n);
    },
    _injectFetchHook() {
        if (this._hookInstalled) return;
        this._hookInstalled = true;
        try {
            const el = document.createElement("script");
            el.src = chrome.runtime.getURL("modules/stats-gql-hook.js");
            el.async = true;
            (document.documentElement || document.head).appendChild(el);
        } catch {
            this._hookInstalled = false;
        }
    },
    _handleGql(detail) {
        const {reqBody: reqBody, json: json} = detail || {};
        if (!json) return;
        const reqs = Array.isArray(reqBody) ? reqBody : reqBody ? [ reqBody ] : [];
        const ress = Array.isArray(json) ? json : [ json ];
        const pageCh = this._pageChannel();
        for (let i = 0; i < ress.length; i++) {
            const block = ress[i];
            if (!block || block.errors && block.errors.length) continue;
            const data = block.data;
            if (!data) continue;
            this._ingestStreamLiveFromData(data);
            this._ingestPointsFromData(data, pageCh);
        }
    },
    _rowsToMap(rows) {
        const o = {};
        for (const r of rows || []) {
            if (r?.login) o[r.login] = Math.max(o[r.login] || 0, Number(r.value) || 0);
        }
        return o;
    },
    _mergeMaps(a, b) {
        const out = {
            ...a
        };
        for (const [k, v] of Object.entries(b || {})) {
            const L = this._normLogin(k);
            if (!L) continue;
            out[L] = Math.max(out[L] || 0, Number(v) || 0);
        }
        return out;
    },
    _aggregateForPeriod(period) {
        const carry = this._state?.carryover || {
            messages: {},
            watchLiveMs: {},
            points: {}
        };
        const dayKeys = period === "all" ? Object.keys(this._state?.days || {}).sort() : this._dateKeysForLastNDays(period === "30d" ? 30 : 7);
        const messages = {};
        const watchLiveMs = {};
        const points = {};
        for (const dk of dayKeys) {
            const bucket = this._state?.days?.[dk];
            if (!bucket) continue;
            for (const [login, cell] of Object.entries(bucket)) {
                const L = this._normLogin(login);
                if (!L) continue;
                messages[L] = (messages[L] || 0) + (Number(cell.m) || 0);
                watchLiveMs[L] = (watchLiveMs[L] || 0) + (Number(cell.w) || 0);
            }
        }
        for (const dk of [ ...dayKeys ].sort()) {
            const bucket = this._state?.days?.[dk];
            if (!bucket) continue;
            for (const [login, cell] of Object.entries(bucket)) {
                const L = this._normLogin(login);
                if (!L) continue;
                const p = Number(cell.p) || 0;
                if (p > 0) points[L] = p;
            }
        }
        if (period === "all") {
            const add = (tgt, src) => {
                for (const [k, v] of Object.entries(src || {})) {
                    if (k.startsWith("_")) continue;
                    const L = this._normLogin(k);
                    if (!L) continue;
                    tgt[L] = (tgt[L] || 0) + (Number(v) || 0);
                }
            };
            add(messages, carry.messages);
            add(watchLiveMs, carry.watchLiveMs);
            for (const [k, v] of Object.entries(carry.points || {})) {
                if (k.startsWith("_")) continue;
                const L = this._normLogin(k);
                if (!L) continue;
                points[L] = Math.max(points[L] || 0, Number(v) || 0);
            }
        }
        return {
            messages: messages,
            watchLiveMs: watchLiveMs,
            points: points
        };
    },
    _sortedMap(obj, limit = 40) {
        return Object.entries(obj || {}).map(([login, value]) => ({
            login: login,
            value: Number(value) || 0
        })).filter(x => x.login && x.value > 0).sort((a, b) => b.value - a.value).slice(0, limit);
    },
    getLeaderboards(period = "7d") {
        const p = period === "all" || period === "30d" ? period : "7d";
        const local = this._aggregateForPeriod(p);
        const srv = this._serverPeriods?.[p];
        if (!srv) {
            return {
                period: p,
                messages: this._sortedMap(local.messages),
                watch: this._sortedMap(local.watchLiveMs),
                points: this._sortedMap(local.points)
            };
        }
        const mm = this._mergeMaps(local.messages, this._rowsToMap(srv.messages));
        const ww = this._mergeMaps(local.watchLiveMs, this._rowsToMap(srv.watch));
        const pp = {
            ...local.points
        };
        for (const row of srv.points || []) {
            const L = this._normLogin(row.login);
            if (!L) continue;
            const v = Number(row.value) || 0;
            if (v > 0) pp[L] = Math.max(pp[L] || 0, v);
        }
        return {
            period: p,
            messages: this._sortedMap(mm),
            watch: this._sortedMap(ww),
            points: this._sortedMap(pp)
        };
    },
    async resetAll() {
        this._state = this._emptyState();
        this._dirty = false;
        this._watchAnchor = null;
        await window.TWIXY.storageSet({
            [this.STORAGE_KEY]: this._state
        });
        await window.TWIXY.storageRemove(this.LEGACY_KEY);
        if (await window.TWIXY.auth.isLoggedIn()) {
            try {
                await window.TWIXY.api.stats.resetRemote();
            } catch {}
        }
        this._serverPeriods = null;
        try {
            window.dispatchEvent(new CustomEvent("twixy:statsUpdated"));
        } catch {}
    },
    exportSnapshot() {
        const s = JSON.parse(JSON.stringify(this._state || this._emptyState()));
        if (s.carryover) {
            for (const k of Object.keys(s.carryover)) {
                if (k.startsWith("_")) delete s.carryover[k];
            }
        }
        return s;
    },
    destroy() {
        clearInterval(this._watchTimer);
        this._watchTimer = null;
        clearInterval(this._flushTimer);
        this._flushTimer = null;
        clearInterval(this._pointsDomTimer);
        this._pointsDomTimer = null;
        clearTimeout(this._saveTimer);
        this._saveTimer = null;
        if (this._onGqlBound) window.removeEventListener("message", this._onGqlBound);
        if (this._onNavBound) window.removeEventListener("locationchange", this._onNavBound);
        if (this._onVisBound) window.removeEventListener("visibilitychange", this._onVisBound);
        if (this._onHiddenBound) document.removeEventListener("visibilitychange", this._onHiddenBound);
        this._stopChatDomObserver();
        if (this._onIrcMsgBound) {
            window.removeEventListener("message", this._onIrcMsgBound);
            this._onIrcMsgBound = null;
        }
        this._ircSeenIds.clear();
        this._initialized = false;
    },
    async init() {
        if (this._initialized) return;
        this._initialized = true;
        await this._load();
        this._injectFetchHook();
        this._onGqlBound = e => {
            if (e.source !== window) return;
            const d = e?.data;
            if (!d || d.source !== "twixy-stats" || d.type !== "gql") return;
            this._handleGql({
                reqBody: d.reqBody,
                json: d.json
            });
        };
        window.addEventListener("message", this._onGqlBound);
        this._watchAnchor = null;
        this._watchTimer = setInterval(() => this._tickWatchtime(), this.WATCH_INTERVAL_MS);
        this._flushTimer = setInterval(() => {
            if (this._dirty) void this._flushServerSnapshot();
        }, this.SERVER_FLUSH_MS);
        this._onNavBound = () => {
            this._watchAnchor = null;
            this._chatDomGraceUntil = Date.now() + 2800;
        };
        this._onVisBound = () => {
            this._watchAnchor = null;
        };
        this._onHiddenBound = () => {
            if (document.visibilityState === "hidden") void this._flushServerSnapshot(true);
        };
        window.addEventListener("locationchange", this._onNavBound);
        window.addEventListener("visibilitychange", this._onVisBound);
        document.addEventListener("visibilitychange", this._onHiddenBound);
        window.addEventListener("pagehide", () => void this._flushServerSnapshot(true), {
            once: false
        });
        window.addEventListener("beforeunload", () => void this._flushServerSnapshot(true));
        this._pointsDomTimer = setInterval(() => this._parsePointsFromDom(), 7e3);
        setTimeout(() => this._parsePointsFromDom(), 1500);
        const u = await window.TWIXY.auth.getUser();
        this._meLogin = u?.login ? String(u.login).toLowerCase() : null;
        this._onIrcMsgBound = e => {
            if (e.source !== window) return;
            const d = e?.data;
            if (!d || d.source !== "twixy-chat-irc" || d.type !== "privmsg") return;
            this._handleIrcPrivmsg(d);
        };
        window.addEventListener("message", this._onIrcMsgBound);
        this._startChatDomObserver();
        window.addEventListener("twixy:loggedIn", async () => {
            const nu = await window.TWIXY.auth.getUser();
            this._meLogin = nu?.login ? String(nu.login).toLowerCase() : null;
            await this._load();
            void this.refresh();
            this._stopChatDomObserver();
            this._startChatDomObserver();
        });
        window.addEventListener("twixy:loggedOut", () => {
            this._meLogin = null;
            this._serverPeriods = null;
            this._stopChatDomObserver();
        });
    }
};