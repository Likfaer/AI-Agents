"use strict";

(function() {
    const HOST = "twixy.cc";
    function chooseProto() {
        if (typeof window.location !== "undefined") {
            if (window.location.protocol === "http:") return "http";
            if (window.location.protocol === "https:") return "https";
        }
        return "https";
    }
    window.TWIXY = {
        SERVER_BASE: `${chooseProto()}://${HOST}/api`
    };
})();

window.escapeHTML = function(str) {
    const div = document.createElement("div");
    div.textContent = String(str ?? "");
    return div.innerHTML;
};

window.formatNotes = function(text) {
    const escaped = escapeHTML(text);
    let html = escaped.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/~~(.+?)~~/g, "<s>$1</s>");
    const lines = html.split("\n");
    let out = "", inList = false;
    for (const line of lines) {
        const raw = line.trim();
        if (!raw) {
            if (inList) {
                out += "</ul>";
                inList = false;
            }
            continue;
        }
        if (/^[-*]\s+/.test(raw)) {
            if (!inList) {
                out += "<ul class='formatted-list'>";
                inList = true;
            }
            out += `<li>${raw.replace(/^[-*]\s+/, "")}</li>`;
        } else if (/^\+\s+/.test(raw)) {
            if (!inList) {
                out += "<ul class='formatted-list'>";
                inList = true;
            }
            out += `<li class="cl-improve">✦ ${raw.replace(/^\+\s+/, "")}</li>`;
        } else if (/^!\s+/.test(raw)) {
            if (!inList) {
                out += "<ul class='formatted-list'>";
                inList = true;
            }
            out += `<li class="cl-warn">⚠ ${raw.replace(/^!\s+/, "")}</li>`;
        } else {
            if (inList) {
                out += "</ul>";
                inList = false;
            }
            out += `<p>${raw}</p>`;
        }
    }
    if (inList) out += "</ul>";
    return out;
};

window.TWIXY.waitFor = function(selector, timeout = 1e4) {
    return new Promise(resolve => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        const obs = new MutationObserver(() => {
            const found = document.querySelector(selector);
            if (found) {
                obs.disconnect();
                resolve(found);
            }
        });
        obs.observe(document.body, {
            childList: true,
            subtree: true
        });
        setTimeout(() => {
            obs.disconnect();
            resolve(null);
        }, timeout);
    });
};

window.TWIXY.debounce = function(fn, wait = 300) {
    let t;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn(...args), wait);
    };
};

window.TWIXY.storageGet = keys => new Promise(resolve => chrome.storage.local.get(keys, resolve));

window.TWIXY.storageSet = items => new Promise(resolve => chrome.storage.local.set(items, resolve));

window.TWIXY.storageRemove = keys => new Promise(resolve => chrome.storage.local.remove(keys, resolve));

window.TWIXY.getStreamerFromPath = function(path) {
    const parts = path.replace(/^\//, "").split("/");
    const first = parts[0].toLowerCase();
    if (first === "moderator" && parts[1]) {
        return /^[a-z0-9_]{3,25}$/.test(parts[1]) ? parts[1].toLowerCase() : null;
    }
    const RESERVED = new Set([ "directory", "settings", "popout", "jobs", "messages", "inventory", "store", "turbo", "search", "subscriptions", "collections", "clips", "team", "login", "signup", "drops", "extensions", "oauth2", "create", "videos", "history", "moderator", "console", "authorize" ]);
    if (!/^[a-z0-9_]{3,25}$/.test(first) || RESERVED.has(first)) return null;
    return first;
};

window.TWIXY.canonTwitchId = function(raw) {
    if (raw == null || raw === "") return "";
    const s = typeof raw === "string" ? raw.trim() : String(raw).trim();
    if (!s) return "";
    if (/^\d+$/.test(s)) {
        try {
            return BigInt(s).toString();
        } catch {
            return s;
        }
    }
    return s;
};

window.TWIXY.bgMessage = message => new Promise(resolve => {
    try {
        chrome.runtime.sendMessage(message, response => {
            if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("Extension context invalidated") || errMsg.includes("context invalidated")) {
                    console.warn("[Twixy] Extension context invalidated, cannot send message.");
                    resolve(null);
                    return;
                }
                setTimeout(() => {
                    try {
                        chrome.runtime.sendMessage(message, resolve);
                    } catch (retryErr) {
                        console.warn("[Twixy] bgMessage retry failed:", retryErr);
                        resolve(null);
                    }
                }, 600);
                return;
            }
            resolve(response);
        });
    } catch (e) {
        if (e && e.message && e.message.includes("context invalidated")) {
            return resolve(null);
        }
        console.warn("[Twixy] bgMessage threw:", e);
        resolve(null);
    }
});