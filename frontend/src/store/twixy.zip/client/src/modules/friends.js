"use strict";

window.TWIXY.friends = {
    accepted: [],
    incoming: [],
    outgoing: [],
    presences: {},
    _lastRefresh: 0,
    _lastRateLimitedAt: 0,
    _inflight: null,
    async refresh(login, force = false) {
        const now = Date.now();
        if (this._inflight) return this._inflight;
        if (now - this._lastRateLimitedAt < 3e4) {
            return {
                accepted: this.accepted,
                incoming: this.incoming,
                outgoing: this.outgoing
            };
        }
        const cooldownMs = force ? 3e3 : 3e4;
        if (now - this._lastRefresh < cooldownMs) {
            return {
                accepted: this.accepted,
                incoming: this.incoming,
                outgoing: this.outgoing
            };
        }
        if (!login) {
            const user = await window.TWIXY.auth.getUser();
            login = user?.login;
        }
        if (!login) return;
        this._inflight = (async () => {
            let accData;
            let incData;
            let outData;
            try {
                [accData, incData, outData] = await Promise.all([ window.TWIXY.api.friends.list(login), window.TWIXY.api.friends.incoming(login), window.TWIXY.api.friends.outgoing(login) ]);
            } catch (err) {
                console.warn("[Twixy] friends.refresh failed (network):", err?.message || err);
                return {
                    accepted: this.accepted,
                    incoming: this.incoming,
                    outgoing: this.outgoing
                };
            }
            const got429 = accData?.rateLimited || incData?.rateLimited || outData?.rateLimited || accData?.error === "Too many requests, slow down." || incData?.error === "Too many requests, slow down." || outData?.error === "Too many requests, slow down.";
            if (got429) {
                this._lastRateLimitedAt = Date.now();
                console.warn("[Twixy] friends.refresh got 429 — backing off");
                if (!this._lastRefresh && !this._retryScheduled) {
                    this._retryScheduled = true;
                    setTimeout(() => {
                        this._retryScheduled = false;
                        this.refresh(login, true).catch(() => {});
                    }, 31e3);
                }
                return {
                    accepted: this.accepted,
                    incoming: this.incoming,
                    outgoing: this.outgoing
                };
            }
            const anyOk = Array.isArray(accData?.friends) || Array.isArray(incData?.requests) || Array.isArray(outData?.requests);
            if (!anyOk) {
                return {
                    accepted: this.accepted,
                    incoming: this.incoming,
                    outgoing: this.outgoing
                };
            }
            if (Array.isArray(accData?.friends)) this.accepted = accData.friends;
            if (Array.isArray(incData?.requests)) this.incoming = incData.requests;
            if (Array.isArray(outData?.requests)) this.outgoing = outData.requests;
            this._lastRefresh = Date.now();
            this._updateBadge();
            window.dispatchEvent(new Event("twixy:friendsUpdated"));
            return {
                accepted: this.accepted,
                incoming: this.incoming,
                outgoing: this.outgoing
            };
        })();
        try {
            return await this._inflight;
        } finally {
            this._inflight = null;
        }
    },
    getFriendObj(doc) {
        const login = String(doc.username ?? "").trim().toLowerCase();
        return {
            login: login,
            display_name: doc.username ?? login,
            profile_image_url: "",
            id: doc.friendship_id ?? doc.id,
            twitch_id: window.TWIXY.canonTwitchId(doc.twitch_id)
        };
    },
    getFriendsArray() {
        return this.accepted.map(doc => ({
            ...this.getFriendObj(doc),
            id: doc.friendship_id ?? doc.id
        }));
    },
    getSidebarName(friend) {
        const original = friend?.display_name || friend?.login || "";
        return window.TWIXY.settings.getFriendNickname(friend?.login) || original;
    },
    getMenuName(friend) {
        const original = friend?.display_name || friend?.login || "";
        const custom = window.TWIXY.settings.getFriendNickname(friend?.login);
        return custom ? `${original} (${custom})` : original;
    },
    getSortedFriends() {
        const arr = this.getFriendsArray();
        const order = window.TWIXY.settings.getFriendsOrder();
        if (order.length !== arr.length) {
            const existing = order.filter(login => arr.some(f => f.login === login));
            const added = arr.map(f => f.login).filter(login => !order.includes(login));
            window.TWIXY.settings.setFriendsOrder([ ...existing, ...added ]);
        }
        arr.sort((a, b) => {
            const fa = window.TWIXY.settings.isFav(a.login);
            const fb = window.TWIXY.settings.isFav(b.login);
            if (fa !== fb) return fb - fa;
            const presA = this.presences[a.login];
            const presB = this.presences[b.login];
            const onlineA = presA?.online ? 1 : 0;
            const onlineB = presB?.online ? 1 : 0;
            if (onlineA !== onlineB) return onlineB - onlineA;
            const ia = order.indexOf(a.login);
            const ib = order.indexOf(b.login);
            return (ia === -1 ? Infinity : ia) - (ib === -1 ? Infinity : ib);
        });
        return arr;
    },
    isAlreadyFriend(targetLogin) {
        const t = targetLogin.toLowerCase();
        return this.accepted.some(doc => doc.username?.toLowerCase() === t);
    },
    isOutgoingPending(targetLogin) {
        const t = targetLogin.toLowerCase();
        return this.outgoing.some(r => (r.to_username ?? "").toLowerCase() === t);
    },
    updatePresence(data) {
        const raw = data.username || data.login;
        if (!raw) return;
        const login = String(raw).toLowerCase();
        const oneMinAgo = Date.now() - 1 * 60 * 1e3;
        const isRecent = data.last_seen && new Date(data.last_seen).getTime() > oneMinAgo;
        const isOnline = data.online !== undefined ? data.online : isRecent;
        this.presences[login] = {
            login: login,
            online: isOnline,
            currentView: isOnline ? data.stream_slug || data.currentView || "" : "",
            isStreaming: false,
            timestamp: data.last_seen || data.timestamp
        };
        window.dispatchEvent(new Event("twixy:presenceUpdated"));
    },
    saveOrderFromDOM() {
        const container = document.querySelector(".twixy-friends-container");
        if (!container) return;
        const order = [ ...container.querySelectorAll(".twixy-friend-item") ].map(el => el.dataset.login).filter(Boolean);
        window.TWIXY.settings.setFriendsOrder(order);
    },
    _updateBadge() {
        const btn = document.getElementById("twixy-settings-button");
        if (!btn) return;
        if (this.incoming.length > 0) btn.classList.add("twixy-has-notif"); else btn.classList.remove("twixy-has-notif");
    }
};