"use strict";

const TWIXY_NOTIF_AUTO_DISMISS_MS = 6e4;

window.TWIXY.notifications = {
    _pending: [],
    _container: null,
    _avatarCache: {},
    _autoDismissTimer: null,
    init() {
        this._ensureContainer();
        window.addEventListener("twixy:incomingRequest", () => {
            this._syncFromFriends();
        });
    },
    _ensureContainer() {
        if (document.getElementById("twixy-notif-container")) {
            this._container = document.getElementById("twixy-notif-container");
            return;
        }
        const el = document.createElement("div");
        el.id = "twixy-notif-container";
        Object.assign(el.style, {
            position: "fixed",
            top: "80px",
            right: "20px",
            zIndex: "10001",
            display: "flex",
            flexDirection: "column",
            gap: "10px",
            pointerEvents: "none"
        });
        document.body.appendChild(el);
        this._container = el;
    },
    async _getAvatar(login) {
        if (this._avatarCache[login]) return this._avatarCache[login];
        const resp = await window.TWIXY.bgMessage({
            action: "get_avatar",
            login: login
        });
        const url = resp?.url || chrome.runtime.getURL("icons/default_avatar.svg");
        this._avatarCache[login] = url;
        return url;
    },
    async add(req) {
        if (window.TWIXY.settings.get("twixy_notif_enabled") === "false") return;
        if (this._pending.find(r => r._id === req._id)) return;
        const avatar = await this._getAvatar(req.from.login);
        this._pending.push({
            ...req,
            avatar: avatar
        });
        this._render();
    },
    removePending(id) {
        this._pending = this._pending.filter(r => String(r._id) !== String(id));
        this._render();
    },
    _clearAutoDismiss() {
        if (this._autoDismissTimer == null) return;
        clearTimeout(this._autoDismissTimer);
        this._autoDismissTimer = null;
    },
    _scheduleAutoDismiss() {
        this._clearAutoDismiss();
        this._autoDismissTimer = setTimeout(() => {
            this._autoDismissTimer = null;
            this.clearAll();
        }, TWIXY_NOTIF_AUTO_DISMISS_MS);
    },
    clearAll() {
        this._clearAutoDismiss();
        this._pending = [];
        if (this._container) this._container.innerHTML = "";
    },
    async _syncFromFriends() {
        const incoming = window.TWIXY.friends.incoming;
        for (const req of incoming) {
            const normalized = {
                _id: req.id,
                from: {
                    login: req.from_username,
                    display_name: req.from_username
                }
            };
            await this.add(normalized);
        }
        this._render();
    },
    _AvatarUrl(url) {
        if (!url) return chrome.runtime.getURL("icons/default_avatar.svg");
        try {
            const parsed = new URL(url);
            if (parsed.protocol === "https:" || parsed.protocol === "http:" || parsed.protocol === "chrome-extension:") {
                return url;
            }
        } catch {}
        return chrome.runtime.getURL("icons/default_avatar.svg");
    },
    _render() {
        if (!this._container) this._ensureContainer();
        this._container.innerHTML = "";
        const n = this._pending.length;
        if (n === 0) {
            this._clearAutoDismiss();
            return;
        }
        const t = window.TWIXY.i18n;
        const card = document.createElement("div");
        card.className = "twixy-notif unified";
        card.style.pointerEvents = "auto";
        const titleHtml = t.t("notifTitle").replace("{n}", n);
        card.innerHTML = `\n      <div class="unified-header">\n        <span class="unified-title">${titleHtml}</span>\n        <button class="close-all-btn" aria-label="close">&times;</button>\n      </div>\n      <ul class="request-list"></ul>\n    `;
        const list = card.querySelector(".request-list");
        for (const req of this._pending) {
            const li = document.createElement("li");
            li.innerHTML = `\n        <img src="${this._AvatarUrl(req.avatar)}" class="notif-avatar" alt="avatar">\n        <span class="notif-name">${escapeHTML(req.from.display_name || req.from.login)}</span>\n        <button class="accept-btn" data-id="${req._id}">${t.t("accept")}</button>\n      `;
            li.querySelector(".accept-btn").addEventListener("click", async () => {
                await window.TWIXY.api.friends.respond(req._id, "accepted");
                this.removePending(req._id);
                const user = await window.TWIXY.auth.getUser();
                if (user?.login) await window.TWIXY.friends.refresh(user.login);
                window.dispatchEvent(new Event("twixy:friendsUpdated"));
            });
            list.appendChild(li);
        }
        card.querySelector(".close-all-btn").addEventListener("click", () => this.clearAll());
        this._container.appendChild(card);
        this._scheduleAutoDismiss();
    }
};