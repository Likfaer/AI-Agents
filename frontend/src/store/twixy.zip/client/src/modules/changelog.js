"use strict";

window.TWIXY.changelog = {
    _cache: null,
    async load(container) {
        if (!container) return;
        const t = window.TWIXY.i18n;
        if (!this._cache?.length) {
            container.innerHTML = '<p style="color:#aaa;">Loading…</p>';
        }
        try {
            const data = await window.TWIXY.api.changelog.get();
            let entries = Array.isArray(data?.entries) ? data.entries : Array.isArray(data) ? data : null;
            const isTransient = data?.rateLimited || data?.networkError || entries == null;
            if (isTransient) {
                if (this._cache && this._cache.length) {
                    entries = this._cache;
                    if (data?.rateLimited && !this._retryScheduled) {
                        this._retryScheduled = true;
                        setTimeout(() => {
                            this._retryScheduled = false;
                            if (container.isConnected) this.load(container);
                        }, 3e4);
                    }
                } else {
                    container.innerHTML = `<p style="color:#f66;">${window.TWIXY.i18n.t("changelogError")}</p>`;
                    return;
                }
            } else {
                this._cache = entries;
            }
            let html = `<div class="twixy-changelog-header">\n        <a href="https://t.me/twixyttv" target="_blank" class="twixy-report-bug">${t.t("reportBug")}</a>\n      </div>`;
            if (entries.length === 0) {
                html += `<p style="color:#aaa;">${t.t("noChangelog")}</p>`;
            } else {
                for (const entry of entries) {
                    const date = new Date(entry.created_at).toLocaleString();
                    const notesHtml = window.formatNotes(entry.content || "");
                    html += `\n            <div class="twixy-changelog-item">\n              <div class="patch-header">${t.t("patchPrefix")} ${escapeHTML(entry.version)}</div>\n              <div class="changelog-notes collapsed">${notesHtml}</div>\n              <button class="toggle-notes-btn">${t.t("showMore")}</button>\n              <div class="patch-timestamp">${escapeHTML(date)}</div>\n            </div>\n          `;
                }
            }
            container.innerHTML = html;
            container.querySelectorAll(".toggle-notes-btn").forEach(btn => {
                btn.addEventListener("click", () => {
                    const notes = btn.previousElementSibling;
                    btn.textContent = notes.classList.toggle("expanded") ? t.t("showLess") : t.t("showMore");
                });
            });
        } catch (err) {
            console.error("[Twixy] Changelog error:", err);
            container.innerHTML = `<p style="color:#f66;">${window.TWIXY.i18n.t("changelogError")}</p>`;
        }
    }
};