"use strict";

window.TWIXY.auth = {
    _user: null,
    _token: null,
    async getUser() {
        if (this._user) return this._user;
        const {twitchUser: twitchUser} = await window.TWIXY.storageGet("twitchUser");
        this._user = twitchUser ?? null;
        return this._user;
    },
    async getToken() {
        if (this._token) return this._token;
        const {serverToken: serverToken} = await window.TWIXY.storageGet("serverToken");
        this._token = serverToken ?? null;
        return this._token;
    },
    async isLoggedIn() {
        const token = await this.getToken();
        if (!token) return false;
        try {
            const {exp: exp} = JSON.parse(atob(token.split(".")[1]));
            return !exp || Date.now() < exp * 1e3;
        } catch {
            return false;
        }
    },
    async login(opts) {
        const forceInteractive = !!(opts && opts.forceInteractive);
        const resp = await window.TWIXY.bgMessage({
            action: "twitch_authorize",
            forceInteractive: forceInteractive
        });
        if (!resp?.success) {
            return {
                success: false,
                networkError: !!resp?.networkError,
                error: resp?.error || "Auth failed"
            };
        }
        const {twitchUser: twitchUser, serverToken: serverToken} = await window.TWIXY.storageGet([ "twitchUser", "serverToken" ]);
        this._user = twitchUser ?? null;
        this._token = serverToken ?? null;
        window.dispatchEvent(new CustomEvent("twixy:loggedIn", {
            detail: {
                user: this._user
            }
        }));
        return {
            success: true,
            user: this._user
        };
    },
    async logout() {
        this._user = null;
        this._token = null;
        window.TWIXY.presence._lastSent = {
            online: null,
            stream_slug: null
        };
        await window.TWIXY.storageRemove([ "serverToken", "twitchToken", "twitchUser" ]);
        window.dispatchEvent(new Event("twixy:loggedOut"));
    }
};

let _silentReauthInFlight = false;

let _lastSilentReauthAt = 0;

window.addEventListener("twixy:tokenExpired", async () => {
    if (Date.now() < (window.TWIXY.api?._suppressTokenExpiredUntil || 0)) return;
    if (Date.now() - _lastSilentReauthAt < 6e4) return;
    if (_silentReauthInFlight) return;
    _silentReauthInFlight = true;
    _lastSilentReauthAt = Date.now();
    window.TWIXY.auth._token = null;
    await window.TWIXY.storageRemove([ "serverToken" ]);
    try {
        const resp = await window.TWIXY.bgMessage({
            action: "twitch_authorize"
        });
        if (resp?.success) {
            const {twitchUser: twitchUser, serverToken: serverToken} = await window.TWIXY.storageGet([ "twitchUser", "serverToken" ]);
            window.TWIXY.auth._user = twitchUser ?? null;
            window.TWIXY.auth._token = serverToken ?? null;
            if (window.TWIXY.auth._token) return;
        }
        if (resp && (resp.networkError || resp.error?.includes?.("fetch"))) return;
    } catch {
        return;
    } finally {
        _silentReauthInFlight = false;
    }
    window.TWIXY.auth._user = null;
    window.TWIXY.auth._token = null;
    await window.TWIXY.storageRemove([ "twitchToken", "twitchUser" ]);
    window.dispatchEvent(new Event("twixy:loggedOut"));
});