"use strict";

window.TWIXY.api = {
    _rateLimitedUntil: 0,
    _suppressTokenExpiredUntil: 0,
    isRateLimited() {
        return Date.now() < this._rateLimitedUntil;
    },
    async fetch(method, path, body) {
        if (Date.now() < this._rateLimitedUntil) {
            return {
                success: false,
                rateLimited: true
            };
        }
        const data = await window.TWIXY.bgMessage({
            action: "server_request",
            method: method,
            path: path,
            body: body
        });
        if (data?.networkError) {
            this._suppressTokenExpiredUntil = Date.now() + 3e4;
            return null;
        }
        if (data?.error === "Too many requests, slow down.") {
            const retryMs = Math.max(5e3, Number(data.retryAfterMs) || 3e4);
            this._rateLimitedUntil = Date.now() + retryMs;
            this._suppressTokenExpiredUntil = Date.now() + retryMs;
            console.warn(`[Twixy] rate-limited by server, backing off ${Math.round(retryMs / 1e3)}s`);
            return {
                success: false,
                rateLimited: true,
                error: data.error
            };
        }
        if (data?.unauthorized) {
            window.dispatchEvent(new Event("twixy:tokenExpired"));
            return null;
        }
        return data;
    },
    friends: {
        list: () => window.TWIXY.api.fetch("GET", "/friends"),
        incoming: () => window.TWIXY.api.fetch("GET", "/friends/incoming"),
        outgoing: () => window.TWIXY.api.fetch("GET", "/friends/outgoing"),
        send: payload => window.TWIXY.api.fetch("POST", "/friends/request", payload),
        respond: (id, status) => window.TWIXY.api.fetch("PATCH", `/friends/request/${id}`, {
            status: status
        }),
        remove: id => window.TWIXY.api.fetch("DELETE", `/friends/${id}`),
        lookupUser: login => window.TWIXY.api.fetch("GET", `/friends/lookup/${encodeURIComponent(login)}`)
    },
    presence: {
        update: payload => window.TWIXY.api.fetch("POST", "/presence", payload),
        getAll: () => window.TWIXY.api.fetch("GET", "/presence")
    },
    _settingsCache: new Map,
    _settingsGet(login, key, path, ttlMs = 6e4) {
        const cacheKey = `${key}:${login}`;
        const cached = this._settingsCache.get(cacheKey);
        if (cached && Date.now() - cached.at < ttlMs) return Promise.resolve(cached.value);
        return this.fetch("GET", path).then(value => {
            if (value && !value.rateLimited && !value.networkError && value.success !== false) {
                this._settingsCache.set(cacheKey, {
                    value: value,
                    at: Date.now()
                });
            }
            return value;
        });
    },
    settings: {
        getStreamerMode: login => window.TWIXY.api._settingsGet(login, "sm", `/settings/streamerMode/${encodeURIComponent(login)}`),
        setStreamerMode: val => {
            window.TWIXY.api._settingsCache.clear();
            return window.TWIXY.api.fetch("POST", "/settings/streamerMode", {
                streamerMode: val
            });
        },
        getProfileVisibility: login => window.TWIXY.api._settingsGet(login, "pv", `/settings/profileVisibility/${encodeURIComponent(login)}`),
        setProfileVisibility: val => {
            window.TWIXY.api._settingsCache.clear();
            return window.TWIXY.api.fetch("POST", "/settings/profileVisibility", {
                profilePublic: val
            });
        }
    },
    changelog: {
        get: () => window.TWIXY.api.fetch("GET", "/changelog")
    },
    hq: {
        enable: () => window.TWIXY.bgMessage({
            action: "hq_enable"
        }),
        disable: () => window.TWIXY.bgMessage({
            action: "hq_disable"
        }),
        status: () => window.TWIXY.bgMessage({
            action: "hq_status"
        })
    },
    profile: {
        get: username => window.TWIXY.api.fetch("GET", `/profile/${encodeURIComponent(username)}`),
        update: data => window.TWIXY.api.fetch("PUT", "/profile", data),
        getNote: username => window.TWIXY.api.fetch("GET", `/profile/notes/${encodeURIComponent(username)}`),
        updateNote: (username, note_text) => window.TWIXY.api.fetch("PUT", `/profile/notes/${encodeURIComponent(username)}`, {
            note_text: note_text
        }),
        getMutual: username => window.TWIXY.api.fetch("GET", `/profile/mutual/${encodeURIComponent(username)}`)
    },
    stats: {
        getMe: todayYyyyMmDd => window.TWIXY.api.fetch("GET", `/stats/me${todayYyyyMmDd ? `?today=${encodeURIComponent(todayYyyyMmDd)}` : ""}`),
        sync: body => window.TWIXY.api.fetch("POST", "/stats/sync", body),
        resetRemote: () => window.TWIXY.api.fetch("DELETE", "/stats/me")
    }
};