"use strict";

(function initHqQualityBadge() {
    let debounceTimer;
    const STYLE_ID = "twixy-hq-quality-badge-styles";
    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `\n[data-a-target="player-settings-submenu-quality-option"] .twixy-hq-quality-tag-wrap,\n[role="menuitemradio"] > .twixy-hq-quality-tag-wrap.twixy-hq-quality-tag-wrap--row {\n  display: block !important;\n  width: 100%;\n  max-width: 100%;\n  box-sizing: border-box !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  line-height: 1.25 !important;\n  flex-shrink: 0 !important;\n}\n[data-a-target="player-settings-submenu-quality-option"] .twixy-hq-quality-tag,\n[role="menuitemradio"] .twixy-hq-quality-tag {\n  display: inline-flex !important;\n  align-items: center !important;\n  gap: 4px !important;\n  box-sizing: border-box !important;\n  font-size: 10px !important;\n  font-weight: 700 !important;\n  font-family: system-ui, -apple-system, "Segoe UI", sans-serif !important;\n  letter-spacing: 0.04em !important;\n  line-height: 1 !important;\n  color: #ede9fe !important;\n  background: linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%) !important;\n  border: 1px solid rgba(196, 181, 253, 0.5) !important;\n  border-radius: 999px !important;\n  padding: 3px 8px 3px 6px !important;\n  box-shadow: 0 1px 3px rgba(91, 33, 182, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.12) !important;\n  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.25) !important;\n  white-space: nowrap !important;\n  vertical-align: middle !important;\n  text-transform: uppercase !important;\n}\n[data-a-target="player-settings-submenu-quality-option"] .twixy-hq-quality-tag svg,\n[role="menuitemradio"] .twixy-hq-quality-tag svg {\n  width: 10px !important;\n  height: 10px !important;\n  flex-shrink: 0 !important;\n  fill: #c4b5fd !important;\n}\n[role="menuitemradio"] > .twixy-hq-quality-tag-wrap.twixy-hq-quality-tag-wrap--row {\n  padding: 2px 0 4px 36px !important;\n}\n`;
        (document.head || document.documentElement).appendChild(style);
    }
    function badgeLabel() {
        try {
            return window.TWIXY?.i18n?.t?.("hqQualityBadge") || "Twixy";
        } catch {
            return "Twixy";
        }
    }
    function isHighQualityRow(text) {
        const raw = String(text || "").trim();
        if (!raw) return false;
        const t = raw.toLowerCase().replace(/\s+/g, " ");
        if (/^(автоматически|авто)$/i.test(raw)) return false;
        if (/^(automatically|auto)$/i.test(raw) && !/\d/.test(raw)) return false;
        if (/^720p\d*|^480p|^360p|^160p/i.test(t)) return false;
        return /1080p|1440p|2160p|4320p|8640p|4k|8k|источник|исходн|source|chunked|оригинал/i.test(t);
    }
    function findLabel(radioRoot) {
        return radioRoot.querySelector("label.tw-radio__label") || radioRoot.querySelector('label[class*="tw-radio__label"]') || radioRoot.querySelector("label[for]");
    }
    function scan() {
        void chrome.storage.local.get("hqEnabled", ({hqEnabled: hqEnabled}) => {
            if (!hqEnabled) {
                document.querySelectorAll(".twixy-hq-quality-tag-wrap").forEach(n => {
                    const row = n.closest('[role="menuitemradio"]');
                    if (row?.getAttribute("data-twixy-hq-row") === "1") {
                        row.removeAttribute("data-twixy-hq-row");
                        row.style.flexDirection = "";
                        row.style.alignItems = "";
                    }
                    const mount = n.parentElement;
                    n.remove();
                    if (mount?.getAttribute("data-twixy-hq-mount") === "1") {
                        mount.removeAttribute("data-twixy-hq-mount");
                        mount.style.display = "";
                        mount.style.flexDirection = "";
                        mount.style.alignItems = "";
                        mount.style.gap = "";
                    }
                });
                document.querySelectorAll("[data-twixy-hq-row]").forEach(r => {
                    if (!r.querySelector(".twixy-hq-quality-tag-wrap")) {
                        r.removeAttribute("data-twixy-hq-row");
                        r.style.flexDirection = "";
                        r.style.alignItems = "";
                    }
                });
                return;
            }
            injectStyles();
            document.querySelectorAll('[data-a-target="player-settings-submenu-quality-option"]').forEach(el => {
                if (el.querySelector(".twixy-hq-quality-tag-wrap")) return;
                const text = (el.innerText || el.textContent || "").trim();
                if (!isHighQualityRow(text)) return;
                const wrap = document.createElement("div");
                wrap.className = "twixy-hq-quality-tag-wrap";
                const span = document.createElement("span");
                span.className = "twixy-hq-quality-tag";
                const ico = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                ico.setAttribute("viewBox", "0 0 24 24");
                ico.setAttribute("aria-hidden", "true");
                const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
                path.setAttribute("d", "M12 2 3 7v5c0 5 4 8.5 9 10 5-1.5 9-5 9-10V7l-9-5Zm-1.1 13.3L7.6 12l1.4-1.4 1.9 1.9 4.1-4.1L16.4 9.8l-5.5 5.5Z");
                ico.appendChild(path);
                span.appendChild(ico);
                span.appendChild(document.createTextNode(badgeLabel()));
                wrap.appendChild(span);
                const label = findLabel(el);
                const inner = label?.firstElementChild;
                if (inner) {
                    inner.setAttribute("data-twixy-hq-mount", "1");
                    inner.style.display = "flex";
                    inner.style.flexDirection = "column";
                    inner.style.alignItems = "flex-start";
                    inner.style.gap = "4px";
                    inner.appendChild(wrap);
                    return;
                }
                const item = el.closest('[role="menuitemradio"]');
                if (item && !item.querySelector(".twixy-hq-quality-tag-wrap")) {
                    wrap.classList.add("twixy-hq-quality-tag-wrap--row");
                    item.setAttribute("data-twixy-hq-row", "1");
                    item.style.flexDirection = "column";
                    item.style.alignItems = "stretch";
                    item.appendChild(wrap);
                }
            });
        });
    }
    function debouncedScan() {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(scan, 60);
    }
    function instantScan() {
        clearTimeout(debounceTimer);
        scan();
        setTimeout(scan, 30);
        setTimeout(scan, 120);
    }
    document.addEventListener("click", e => {
        const target = e.target;
        if (!(target instanceof Element)) return;
        if (target.closest('[data-a-target="player-settings-button"]') || target.closest('[data-a-target="player-settings-menu-item-quality"]') || target.closest('[aria-label*="настройк" i]') || target.closest('[aria-label*="setting" i]') || target.closest('[aria-label*="quality" i]') || target.closest('[aria-label*="качеств" i]')) {
            instantScan();
        }
    }, true);
    injectStyles();
    try {
        new MutationObserver(debouncedScan).observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    } catch {
        return;
    }
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.hqEnabled) debouncedScan();
    });
    window.addEventListener("twixy:langChanged", () => {
        document.querySelectorAll(".twixy-hq-quality-tag").forEach(el => {
            el.textContent = badgeLabel();
        });
    });
    debouncedScan();
})();