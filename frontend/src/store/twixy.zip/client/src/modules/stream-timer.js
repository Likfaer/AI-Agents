"use strict";

window.TWIXY.streamTimer = {
    STORAGE_KEY: "twixy_personal_stream_timers",
    MAX_CHANNELS: 40,
    NEW_STREAM_DROP_MS: 10 * 60 * 1e3,
    _timer: null,
    _uiTimer: null,
    _state: null,
    _currentSlug: null,
    _currentStreamKey: null,
    _lastTickAt: 0,
    _observer: null,
    _initialized: false,
    _readState() {
        try {
            const raw = localStorage.getItem(this.STORAGE_KEY);
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            return parsed && typeof parsed === "object" ? parsed : {};
        } catch {
            return {};
        }
    },
    _writeState(state) {
        try {
            const entries = Object.entries(state || {});
            if (entries.length > this.MAX_CHANNELS) {
                entries.sort((a, b) => (b[1]?.updatedAt || 0) - (a[1]?.updatedAt || 0));
                const trimmed = {};
                for (const [k, v] of entries.slice(0, this.MAX_CHANNELS)) trimmed[k] = v;
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(trimmed));
                this._state = trimmed;
                return;
            }
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(state));
            this._state = state;
        } catch {}
    },
    _ensureState() {
        if (!this._state) this._state = this._readState();
        return this._state;
    },
    _pageSlug() {
        const p = location.pathname.replace(/^\//, "");
        return window.TWIXY.getStreamerFromPath(p);
    },
    _parseUptimeTextToMs(txt) {
        const t = String(txt || "").trim();
        if (!t) return null;
        const m = t.match(/^(?:(\d+):)?(\d{1,2}):(\d{2})$/);
        if (!m) return null;
        const h = m[1] ? parseInt(m[1], 10) : 0;
        const mm = parseInt(m[2], 10);
        const ss = parseInt(m[3], 10);
        if (![ h, mm, ss ].every(Number.isFinite)) return null;
        return (h * 3600 + mm * 60 + ss) * 1e3;
    },
    _readLiveTimeMsStandard() {
        const host = document.querySelector(".live-time");
        if (!host) return null;
        const inner = host.querySelector('span[aria-hidden="true"]') || host;
        const txt = (inner.textContent || "").trim();
        return this._parseUptimeTextToMs(txt);
    },
    _isModeratorViewPage() {
        return /^\/moderator\/[a-z0-9_]{3,25}/i.test(location.pathname || "");
    },
    _findModViewUptimeParagraph() {
        for (const p of document.querySelectorAll("p")) {
            if (!p.isConnected) continue;
            const raw = (p.textContent || "").replace(/\s+/g, " ").trim();
            if (/^(?:Трансляция|Stream|В эфире|Live|Broadcast|Uptime)\s+((?:(?:\d+):)?\d{1,2}:\d{2})$/i.test(raw)) {
                return p;
            }
        }
        return null;
    },
    _readLiveTimeMsModView() {
        const p = this._findModViewUptimeParagraph();
        if (!p) return null;
        const raw = (p.textContent || "").replace(/\s+/g, " ").trim();
        const m = raw.match(/^(?:Трансляция|Stream|В эфире|Live|Broadcast|Uptime)\s+((?:(?:\d+):)?\d{1,2}:\d{2})$/i);
        if (!m) return null;
        return this._parseUptimeTextToMs(m[1]);
    },
    _readLiveTimeMs() {
        if (this._isModeratorViewPage()) {
            return this._readLiveTimeMsModView() ?? this._readLiveTimeMsStandard();
        }
        return this._readLiveTimeMsStandard() ?? this._readLiveTimeMsModView();
    },
    _isSettingOn() {
        return window.TWIXY.settings.getBool("twixy_personal_timer_show");
    },
    _isWatchingNow() {
        const v = document.querySelector("video");
        if (!v || v.paused || v.ended) return false;
        return true;
    },
    _getOrCreateChannelEntry(slug, currentUptimeMs) {
        const state = this._readState();
        this._state = state;
        const now = Date.now();
        const prev = state[slug];
        if (prev && typeof prev.lastUptimeMs === "number") {
            const dropped = prev.lastUptimeMs - currentUptimeMs > this.NEW_STREAM_DROP_MS;
            if (!dropped) {
                prev.lastUptimeMs = Math.max(currentUptimeMs, prev.lastUptimeMs);
                prev.updatedAt = now;
                return {
                    entry: prev,
                    fresh: false
                };
            }
        }
        const fresh = {
            streamStartedAt: now - currentUptimeMs,
            lastUptimeMs: currentUptimeMs,
            watchMs: 0,
            lastWatchTickAt: now,
            updatedAt: now
        };
        state[slug] = fresh;
        this._writeState(state);
        return {
            entry: fresh,
            fresh: true
        };
    },
    _persistEntry(slug) {
        const state = this._ensureState();
        if (!state[slug]) return;
        state[slug].updatedAt = Date.now();
        this._writeState(state);
    },
    _formatTimer(ms) {
        const total = Math.max(0, Math.floor(ms / 1e3));
        const h = Math.floor(total / 3600);
        const m = Math.floor(total % 3600 / 60);
        const s = total % 60;
        const pad = n => String(n).padStart(2, "0");
        return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
    },
    _findUptimeAnchorNode() {
        if (this._isModeratorViewPage()) {
            const p = this._findModViewUptimeParagraph();
            if (p) return {
                node: p,
                modView: true
            };
            const liveTime = document.querySelector(".live-time");
            if (liveTime) return {
                node: liveTime,
                modView: false
            };
            return null;
        }
        const liveTime = document.querySelector(".live-time");
        if (liveTime) return {
            node: liveTime,
            modView: false
        };
        const p = this._findModViewUptimeParagraph();
        if (p) return {
            node: p,
            modView: true
        };
        return null;
    },
    _ensureTimerElement() {
        if (!this._isSettingOn()) {
            this._removeTimerElement();
            return null;
        }
        let el = document.getElementById("twixy-personal-watch");
        if (el && el.isConnected) return el;
        const anchor = this._findUptimeAnchorNode();
        if (!anchor) return null;
        const {node: liveTime, modView: modView} = anchor;
        const parent = liveTime.parentElement;
        if (!parent) return null;
        el = document.createElement("span");
        el.id = "twixy-personal-watch";
        el.className = "twixy-personal-watch twixy-has-tip" + (modView ? " twixy-personal-watch--modview" : "");
        el.innerHTML = `\n      <span class="twixy-personal-watch-dot" aria-hidden="true"></span>\n      <span class="twixy-personal-watch-value" aria-hidden="true">00:00</span>\n      <span class="twixy-tip-popup" role="tooltip"></span>\n    `;
        this._setTimerTooltip(el);
        if (modView) {
            el.style.marginInlineStart = "0.5rem";
            if (liveTime.nextSibling) parent.insertBefore(el, liveTime.nextSibling); else parent.appendChild(el);
        } else if (liveTime.nextSibling) {
            parent.insertBefore(el, liveTime.nextSibling);
        } else {
            parent.appendChild(el);
        }
        if (modView) this._bindModViewWatchTooltip(el);
        return el;
    },
    _removeTimerElement() {
        document.getElementById("twixy-personal-watch")?.remove();
    },
    _setTimerTooltip(el) {
        const t = window.TWIXY.i18n;
        const tip = el?.querySelector(".twixy-tip-popup");
        if (tip) tip.textContent = t.t("personalWatchTooltip");
    },
    _bindModViewWatchTooltip(wrap) {
        if (!wrap || wrap.dataset.twixyModTip === "1") return;
        wrap.dataset.twixyModTip = "1";
        const tip = wrap.querySelector(".twixy-tip-popup");
        if (!tip) return;
        const MOD_CLS = "twixy-personal-watch-tooltip--mod-fixed";
        let hideTimer = 0;
        const cancelHide = () => {
            if (hideTimer) {
                clearTimeout(hideTimer);
                hideTimer = 0;
            }
        };
        const scheduleHide = () => {
            cancelHide();
            hideTimer = window.setTimeout(() => {
                hideTimer = 0;
                if (!wrap.matches(":hover") && !tip.matches(":hover")) {
                    doClear();
                }
            }, 100);
        };
        const doClear = () => {
            cancelHide();
            if (tip.parentNode === document.body) {
                wrap.appendChild(tip);
            }
            tip.classList.remove(MOD_CLS);
            tip.removeAttribute("style");
        };
        const nudgeIntoViewport = () => {
            const margin = 12;
            for (let i = 0; i < 12; i += 1) {
                const iw = window.innerWidth;
                const ih = window.innerHeight;
                const b = tip.getBoundingClientRect();
                let dx = 0;
                let dy = 0;
                if (b.left < margin) dx = margin - b.left; else if (b.right > iw - margin) dx = iw - margin - b.right;
                if (b.top < margin) dy = margin - b.top; else if (b.bottom > ih - margin) dy = ih - margin - b.bottom;
                if (!dx && !dy) break;
                const curL = parseFloat(tip.style.left) || 0;
                const curT = parseFloat(tip.style.top) || 0;
                tip.style.left = `${Math.round(curL + dx)}px`;
                tip.style.top = `${Math.round(curT + dy)}px`;
            }
        };
        const isTipVisible = () => wrap.matches(":hover") || tip.matches(":hover") || wrap.contains(document.activeElement);
        const place = () => {
            if (!wrap.classList.contains("twixy-personal-watch--modview") || !wrap.isConnected) return;
            if (!isTipVisible()) return;
            if (tip.parentNode !== document.body) {
                document.body.appendChild(tip);
            }
            const margin = 12;
            const iw = window.innerWidth;
            const ih = window.innerHeight;
            const maxW = Math.min(320, Math.max(100, iw - 2 * margin));
            const maxH = Math.max(80, ih - 2 * margin);
            const r = wrap.getBoundingClientRect();
            tip.classList.add(MOD_CLS);
            Object.assign(tip.style, {
                position: "fixed",
                left: "-9999px",
                top: "0",
                width: `${maxW}px`,
                maxWidth: "min(320px, calc(100vw - 24px))",
                maxHeight: `${maxH}px`,
                right: "auto",
                bottom: "auto",
                transform: "none",
                zIndex: "2147483647",
                visibility: "hidden"
            });
            let w = Math.min(tip.offsetWidth || maxW, maxW);
            let h = Math.min(Math.max(Math.ceil(tip.getBoundingClientRect().height), 40), maxH);
            const videoBandTop = ih * .52;
            const crossesVideoBand = (top, boxH) => top + boxH > videoBandTop;
            const clamp = (l, t, wp, hp) => {
                const W = Math.min(wp, iw - 2 * margin);
                const H = Math.min(hp, ih - 2 * margin);
                return {
                    l: Math.max(margin, Math.min(l, iw - margin - W)),
                    t: Math.max(margin, Math.min(t, ih - margin - H))
                };
            };
            const above = {
                l: r.left + r.width / 2 - w / 2,
                t: r.top - h - margin
            };
            const below = {
                l: r.left + r.width / 2 - w / 2,
                t: r.bottom + margin
            };
            const right = {
                l: r.right + margin,
                t: r.top + (r.height - h) / 2
            };
            const leftP = {
                l: r.left - w - margin,
                t: r.top + (r.height - h) / 2
            };
            const center = {
                l: (iw - w) / 2,
                t: (ih - h) / 2
            };
            const tryOrder = [ above, right, leftP, below, center ];
            let best = clamp(center.l, center.t, w, h);
            for (const p of tryOrder) {
                const c = clamp(p.l, p.t, w, h);
                if (p === center || !crossesVideoBand(c.t, h)) {
                    best = c;
                    break;
                }
            }
            Object.assign(tip.style, {
                left: `${Math.round(best.l)}px`,
                top: `${Math.round(best.t)}px`,
                width: `${w}px`,
                maxWidth: "min(320px, calc(100vw - 24px))",
                maxHeight: `${maxH}px`,
                visibility: "visible",
                opacity: "1",
                pointerEvents: "auto"
            });
            nudgeIntoViewport();
        };
        const rafPlace = () => {
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    place();
                });
            });
        };
        const onLayout = () => {
            if (isTipVisible()) rafPlace();
        };
        const onEnterWrap = () => {
            cancelHide();
            rafPlace();
        };
        const onLeaveWrap = e => {
            if (e.relatedTarget && (e.relatedTarget === tip || tip.contains(e.relatedTarget))) {
                return;
            }
            scheduleHide();
        };
        const onLeaveTip = e => {
            if (e.relatedTarget && (e.relatedTarget === wrap || wrap.contains(e.relatedTarget))) {
                return;
            }
            scheduleHide();
        };
        wrap.addEventListener("mouseenter", onEnterWrap);
        tip.addEventListener("mouseenter", onEnterWrap);
        tip.addEventListener("mouseleave", onLeaveTip);
        wrap.addEventListener("focusin", onEnterWrap);
        const onFocusOut = e => {
            if (wrap.contains(e.relatedTarget) || e.relatedTarget && tip.contains(e.relatedTarget)) return;
            doClear();
        };
        wrap.addEventListener("mouseleave", onLeaveWrap);
        wrap.addEventListener("focusout", onFocusOut);
        window.addEventListener("scroll", onLayout, true);
        window.addEventListener("resize", onLayout);
    },
    _renderTimer(ms) {
        const el = this._ensureTimerElement();
        if (!el) return;
        const valueEl = el.querySelector(".twixy-personal-watch-value");
        if (valueEl) valueEl.textContent = this._formatTimer(ms);
        this._setTimerTooltip(el);
    },
    _tick() {
        if (!this._isSettingOn()) {
            this._removeTimerElement();
            return;
        }
        const slug = this._pageSlug();
        if (!slug) {
            this._currentSlug = null;
            this._currentStreamKey = null;
            this._removeTimerElement();
            return;
        }
        const uptime = this._readLiveTimeMs();
        if (uptime == null) {
            this._removeTimerElement();
            return;
        }
        const now = Date.now();
        const {entry: entry, fresh: fresh} = this._getOrCreateChannelEntry(slug, uptime);
        const sameAsBefore = this._currentSlug === slug && this._currentStreamKey === entry.streamStartedAt;
        if (!sameAsBefore) {
            this._currentSlug = slug;
            this._currentStreamKey = entry.streamStartedAt;
            if (fresh) {
                this._lastTickAt = now;
                entry.watchMs = 0;
                entry.lastWatchTickAt = now;
            }
            this._persistEntry(slug);
        }
        if (this._isWatchingNow()) {
            const lastTick = entry.lastWatchTickAt || entry.updatedAt || now;
            const elapsed = Math.max(0, now - lastTick);
            if (elapsed >= 900) {
                const bounded = Math.min(elapsed, 5e3);
                entry.watchMs = (entry.watchMs || 0) + bounded;
                entry.lastWatchTickAt = now;
                this._lastTickAt = now;
                this._persistEntry(slug);
            } else {
                this._lastTickAt = now;
            }
        } else {
            this._lastTickAt = now;
        }
        this._renderTimer(entry.watchMs);
    },
    _onSettingChanged(e) {
        const key = e?.detail?.key;
        if (key === "twixy_personal_timer_show") {
            if (this._isSettingOn()) {
                this._tick();
            } else {
                this._removeTimerElement();
            }
        }
    },
    _onLocationChange() {
        this._currentSlug = null;
        this._currentStreamKey = null;
        this._removeTimerElement();
    },
    init() {
        if (this._initialized) return;
        this._initialized = true;
        this._ensureState();
        this._timer = setInterval(() => this._tick(), 1e3);
        this._observer = new MutationObserver(() => {
            if (!this._isSettingOn()) return;
            if (document.getElementById("twixy-personal-watch")) return;
            if (this._findUptimeAnchorNode()) this._tick();
        });
        this._observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        window.addEventListener("locationchange", () => this._onLocationChange());
        window.addEventListener("twixy:settingChanged", e => this._onSettingChanged(e));
        window.addEventListener("twixy:langChanged", () => {
            const el = document.getElementById("twixy-personal-watch");
            if (el) this._setTimerTooltip(el);
        });
        window.addEventListener("visibilitychange", () => {
            this._lastTickAt = Date.now();
            if (document.visibilityState === "visible") this._tick();
        });
        window.addEventListener("storage", e => {
            if (e.key === this.STORAGE_KEY) this._tick();
        });
    }
};