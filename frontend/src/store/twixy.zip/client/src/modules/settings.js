"use strict";

window.TWIXY.settings = {
    _defaults: {
        twixy_lang: "en",
        twixy_notif_enabled: "true",
        twixy_avatar_display: "none",
        twixy_online_status: "true",
        twixy_share_activity: "true",
        twixy_friends_position: "top",
        twixy_friends_hidden: "false",
        twixy_autoclaim: "true",
        twixy_badge_display: "true",
        twixy_mod_btn_always: "true",
        twixy_hq_enabled: "false",
        twixy_personal_timer_show: "true",
        twixy_followage_btn_show: "true",
        twixy_profile_mutual_friends_show: "true",
        twixy_sidebar_friends_initial: "5",
        twixy_friend_highlight_enabled: "false",
        twixy_friend_highlight_color: "rgba(147, 85, 212, 0.18)"
    },
    get(key) {
        const val = localStorage.getItem(key);
        if (val !== null) return val;
        const def = this._defaults[key];
        if (def !== undefined) {
            localStorage.setItem(key, def);
            return def;
        }
        return null;
    },
    set(key, value) {
        localStorage.setItem(key, String(value));
        window.dispatchEvent(new CustomEvent("twixy:settingChanged", {
            detail: {
                key: key,
                value: value
            }
        }));
    },
    getBool(key) {
        return this.get(key) === "true";
    },
    setBool(key, val) {
        this.set(key, val ? "true" : "false");
    },
    getFriendsOrder() {
        try {
            return JSON.parse(localStorage.getItem("twixy_friends_order") || "[]");
        } catch {
            return [];
        }
    },
    setFriendsOrder(order) {
        localStorage.setItem("twixy_friends_order", JSON.stringify(order));
    },
    isFav(login) {
        return localStorage.getItem("twixy_fav_" + login) === "true";
    },
    setFav(login, val) {
        localStorage.setItem("twixy_fav_" + login, val ? "true" : "false");
    },
    getFriendNicknames() {
        try {
            return JSON.parse(localStorage.getItem("twixy_friend_nicknames") || "{}");
        } catch {
            return {};
        }
    },
    getFriendNickname(login) {
        const key = String(login ?? "").trim().toLowerCase();
        if (!key) return "";
        const nicknames = this.getFriendNicknames();
        return typeof nicknames[key] === "string" ? nicknames[key] : "";
    },
    setFriendNickname(login, nickname) {
        const key = String(login ?? "").trim().toLowerCase();
        if (!key) return;
        const nicknames = this.getFriendNicknames();
        const cleanNickname = String(nickname ?? "").trim().slice(0, 40);
        if (cleanNickname) nicknames[key] = cleanNickname; else delete nicknames[key];
        localStorage.setItem("twixy_friend_nicknames", JSON.stringify(nicknames));
        window.dispatchEvent(new CustomEvent("twixy:friendNicknameChanged", {
            detail: {
                login: key,
                nickname: cleanNickname
            }
        }));
    },
    getSidebarHiddenLogins() {
        try {
            return JSON.parse(localStorage.getItem("twixy_sidebar_hidden_logins") || "[]").map(x => String(x).trim().toLowerCase()).filter(Boolean);
        } catch {
            return [];
        }
    },
    isSidebarHidden(login) {
        const k = String(login ?? "").trim().toLowerCase();
        return k && this.getSidebarHiddenLogins().includes(k);
    },
    toggleSidebarHidden(login) {
        const k = String(login ?? "").trim().toLowerCase();
        if (!k) return;
        const set = new Set(this.getSidebarHiddenLogins());
        if (set.has(k)) set.delete(k); else set.add(k);
        localStorage.setItem("twixy_sidebar_hidden_logins", JSON.stringify([ ...set ]));
        window.dispatchEvent(new Event("twixy:sidebarHiddenChanged"));
    }
};

(function() {
    const s = window.TWIXY.settings;
    for (const [key, def] of Object.entries(s._defaults)) {
        if (localStorage.getItem(key) === null) localStorage.setItem(key, def);
    }
})();