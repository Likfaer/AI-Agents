"use strict";

chrome.runtime.onMessage.addListener(msg => {
    if (msg?.action === "token_expired") {
        window.dispatchEvent(new Event("twixy:tokenExpired"));
    }
});

window.addEventListener("unhandledrejection", e => {
    const msg = e.reason?.message ?? "";
    if (msg.includes("Extension context invalidated") || msg.includes("context invalidated")) {
        e.preventDefault();
    }
});

window.onerror = msg => {
    if (String(msg).includes("Extension context invalidated")) return true;
};

window.addEventListener("twixy:contextInvalidated", () => {
    window.TWIXY.presence.destroy();
    window.TWIXY.autoclaim.destroy();
    window.TWIXY.stats?.destroy?.();
    document.getElementById("twixy-draggable")?.remove();
    document.getElementById("twixy-nav-item")?.remove();
    document.getElementById("twixy-modview-dock-slot")?.remove();
    document.getElementById("twixy-friends-sidebar")?.remove();
    document.getElementById("twixy-profile-overlay")?.remove();
    document.getElementById("twixy-followage-btn")?.remove();
    document.getElementById("twixy-personal-watch")?.remove();
});

setInterval(() => {
    try {
        chrome.runtime.getURL("");
    } catch {
        window.dispatchEvent(new Event("twixy:contextInvalidated"));
    }
}, 1e4);

(async function() {
    const required = [ "i18n", "settings", "api", "auth", "autoclaim", "friends", "presence", "notifications", "chatAvatars", "changelog", "profile", "stats", "followage", "streamTimer", "ui" ];
    for (const mod of required) {
        if (!window.TWIXY[mod]) {
            console.error(`[Twixy] Module missing: ${mod}`);
            return;
        }
    }
    const emitLocationChange = () => window.dispatchEvent(new Event("locationchange"));
    const _push = history.pushState;
    const _replace = history.replaceState;
    history.pushState = function(...args) {
        const r = _push.apply(this, args);
        emitLocationChange();
        return r;
    };
    history.replaceState = function(...args) {
        const r = _replace.apply(this, args);
        emitLocationChange();
        return r;
    };
    window.addEventListener("popstate", emitLocationChange);
    let _lastPath = location.pathname;
    setInterval(() => {
        if (location.pathname !== _lastPath) {
            _lastPath = location.pathname;
            emitLocationChange();
        }
    }, 150);
    let _presencePathFollowUp = null;
    window.addEventListener("locationchange", () => {
        window.TWIXY.presence.markActive();
        window.TWIXY.presence.send();
        clearTimeout(_presencePathFollowUp);
        _presencePathFollowUp = setTimeout(() => window.TWIXY.presence.send(), 400);
    });
    window.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") {
            window.TWIXY.presence.markActive();
            window.TWIXY.presence.forceRefresh();
        }
    });
    setInterval(async () => {
        try {
            if (!await window.TWIXY.auth.isLoggedIn()) return;
            window.TWIXY.presence.send();
        } catch {}
    }, 6e4);
    let _lastFriendsRefreshAt = 0;
    setInterval(async () => {
        try {
            if (!await window.TWIXY.auth.isLoggedIn()) return;
            if (!window.TWIXY.presence._canDriveServer({})) return;
            const data = await window.TWIXY.api.presence.getAll();
            if (!data || data.success === false || data.rateLimited || data.networkError) return;
            const statuses = Array.isArray(data) ? data : data?.statuses ?? null;
            if (!Array.isArray(statuses)) return;
            window.TWIXY.presence._applyPresencesSnapshot(statuses);
            window.TWIXY.presence.broadcastPresencesSnapshot(statuses);
        } catch {}
    }, 8e3);
    setInterval(async () => {
        try {
            if (Date.now() - _lastFriendsRefreshAt < 55e3) return;
            if (!await window.TWIXY.auth.isLoggedIn()) return;
            if (!window.TWIXY.presence._canDriveServer({})) return;
            const user = await window.TWIXY.auth.getUser();
            if (!user?.login) return;
            const r = await window.TWIXY.friends.refresh(user.login, true);
            if (r) {
                _lastFriendsRefreshAt = Date.now();
                window.TWIXY.presence.broadcastFriendsSnapshot({
                    accepted: window.TWIXY.friends.accepted,
                    incoming: window.TWIXY.friends.incoming,
                    outgoing: window.TWIXY.friends.outgoing
                });
            }
        } catch {}
    }, 6e4);
    setInterval(() => {
        try {
            chrome.storage.local.get("serverToken", ({serverToken: serverToken}) => {
                if (!serverToken) return;
                try {
                    const {exp: exp} = JSON.parse(atob(serverToken.split(".")[1]));
                    if (!exp) return;
                    const msLeft = exp * 1e3 - Date.now();
                    if (msLeft <= 0) {
                        window.TWIXY.bgMessage({
                            action: "refresh_token"
                        }).then(r => {
                            if (r?.success) {
                                window.TWIXY.auth._token = null;
                            } else {
                                window.dispatchEvent(new Event("twixy:tokenExpired"));
                            }
                        });
                    } else if (msLeft < 24 * 60 * 60 * 1e3) {
                        window.TWIXY.bgMessage({
                            action: "refresh_token"
                        }).then(r => {
                            if (r?.success) window.TWIXY.auth._token = null;
                        });
                    }
                } catch {
                    window.dispatchEvent(new Event("twixy:tokenExpired"));
                }
            });
        } catch {}
    }, 6e4);
    setInterval(async () => {
        try {
            if (!await window.TWIXY.auth.isLoggedIn()) return;
            window.TWIXY.presence.heartbeat();
        } catch {}
    }, 3 * 6e4);
    window.addEventListener("beforeunload", () => window.TWIXY.presence.sendOffline());
    window.addEventListener("pagehide", () => window.TWIXY.presence.sendOffline());
    window.TWIXY.notifications.init();
    window.TWIXY.autoclaim.init();
    window.TWIXY.chatAvatars.init();
    await window.TWIXY.stats.init();
    await window.TWIXY.ui.init();
    window.TWIXY.followage.init();
    window.TWIXY.streamTimer.init();
    if (document.visibilityState === "visible") window.TWIXY.presence.markActive();
    window.addEventListener("focus", () => window.TWIXY.presence.markActive());
    const loggedIn = await window.TWIXY.auth.isLoggedIn();
    if (loggedIn) {
        await window.TWIXY.presence.initSocket();
        const jitterMs = 50 + Math.floor(Math.random() * 750);
        setTimeout(() => {
            try {
                window.TWIXY.presence.send();
            } catch {}
        }, jitterMs);
        const user = await window.TWIXY.auth.getUser();
        if (user?.login) {
            setTimeout(() => {
                try {
                    window.TWIXY.friends.refresh(user.login);
                } catch {}
            }, jitterMs + 200);
        }
    }
    console.log("[Twixy] v2.0 loaded ✓");
})();