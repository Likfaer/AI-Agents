/**
 * Пример PM2: API без раздачи админки + отдельный процесс админки.
 * Подставь cwd и порта под свой сервер.
 *
 * Основной API слушает PORT (например 3000). В .env основого процесса: SERVE_ADMIN=false
 * Админка: ADMIN_PORT=3099, TWIXY_API_INTERNAL=http://127.0.0.1:3000
 *
 * Nginx (один домен, без простоя расширения при правке HTML):
 *   location /api/     { proxy_pass http://127.0.0.1:3000; ... }
 *   location /admin    { proxy_pass http://127.0.0.1:3099; ... }
 *   location /admin-assets/ { proxy_pass http://127.0.0.1:3099; ... }
 */
module.exports = {
  apps: [
    {
      name: 'twixy-api',
      script: 'src/index.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        SERVE_ADMIN: 'false',
      },
    },
    {
      name: 'twixy-admin',
      script: 'src/admin/adminServer.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        ADMIN_PORT: 3099,
        TWIXY_API_INTERNAL: 'http://127.0.0.1:3000',
      },
    },
  ],
};
