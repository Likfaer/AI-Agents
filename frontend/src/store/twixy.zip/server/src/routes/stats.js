import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { query } from '../db/pool.js';

function normLogin(s) {
  const x = String(s ?? '').trim().toLowerCase();
  return /^[a-z0-9_]{3,25}$/.test(x) ? x : '';
}

function sortDesc(map, limit) {
  return Object.entries(map)
    .map(([login, value]) => ({ login, value: Number(value) || 0 }))
    .filter((x) => x.login && x.value > 0)
    .sort((a, b) => b.value - a.value)
    .slice(0, limit);
}

/** YYYY-MM-DD → UTC midnight, minus n days */
function utcDayMinus(yyyyMmDd, daysBack) {
  const [y, m, d] = yyyyMmDd.split('-').map(Number);
  const t = Date.UTC(y, m - 1, d) - daysBack * 86400000;
  const x = new Date(t);
  const yy = x.getUTCFullYear();
  const mm = String(x.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(x.getUTCDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

async function aggregatePeriod(userId, fromStr, toStr) {
  const uid = BigInt(userId);

  const mRows = await query(
    `SELECT channel_login, SUM(messages)::bigint AS v
     FROM user_analytics_daily
     WHERE user_twitch_id = $1 AND stat_date >= $2::date AND stat_date <= $3::date
     GROUP BY channel_login`,
    [uid, fromStr, toStr],
  );
  const wRows = await query(
    `SELECT channel_login, SUM(watch_live_ms)::bigint AS v
     FROM user_analytics_daily
     WHERE user_twitch_id = $1 AND stat_date >= $2::date AND stat_date <= $3::date
     GROUP BY channel_login`,
    [uid, fromStr, toStr],
  );

  const pRows = await query(
    `SELECT DISTINCT ON (channel_login) channel_login, points_snapshot::bigint AS v
     FROM user_analytics_daily
     WHERE user_twitch_id = $1 AND stat_date >= $2::date AND stat_date <= $3::date
       AND points_snapshot IS NOT NULL
     ORDER BY channel_login, stat_date DESC`,
    [uid, fromStr, toStr],
  );

  const messages = {};
  const watch = {};
  const points = {};
  for (const r of mRows) {
    const L = normLogin(r.channel_login);
    if (L) messages[L] = Number(r.v) || 0;
  }
  for (const r of wRows) {
    const L = normLogin(r.channel_login);
    if (L) watch[L] = Number(r.v) || 0;
  }
  for (const r of pRows) {
    const L = normLogin(r.channel_login);
    if (L) points[L] = Number(r.v) || 0;
  }

  return {
    messages: sortDesc(messages, 40),
    watch: sortDesc(watch, 40),
    points: sortDesc(points, 40),
  };
}

/**
 * Аналитика каналов: синхронизация с расширения и выдача сводок.
 * Параметр ?today=YYYY-MM-DD — «сегодня» в календаре пользователя (как в расширении), для корректных окон 7/30 дней.
 */
export function statsRouter() {
  const router = Router();
  router.use(authenticate);

  router.get('/me', asyncHandler(async (req, res) => {
    const uid = req.user.twitch_id;
    const raw = req.query.today;
    const anchor =
      typeof raw === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(raw)
        ? raw
        : new Date().toISOString().slice(0, 10);

    const from7 = utcDayMinus(anchor, 6);
    const from30 = utcDayMinus(anchor, 29);
    const allFrom = '1970-01-01';

    const [p7, p30, pAll] = await Promise.all([
      aggregatePeriod(uid, from7, anchor),
      aggregatePeriod(uid, from30, anchor),
      aggregatePeriod(uid, allFrom, anchor),
    ]);

    res.json({
      success: true,
      periods: {
        '7d': p7,
        '30d': p30,
        all: pAll,
      },
    });
  }));

  router.post('/sync', asyncHandler(async (req, res) => {
    const uid = BigInt(req.user.twitch_id);
    const { day, snapshot } = req.body ?? {};
    if (!day || typeof day !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(day)) {
      return res.status(400).json({ success: false, error: 'Invalid day' });
    }
    if (!snapshot || typeof snapshot !== 'object') {
      return res.status(400).json({ success: false, error: 'Invalid snapshot' });
    }

    let n = 0;
    for (const [rawLogin, cell] of Object.entries(snapshot)) {
      const login = normLogin(rawLogin);
      if (!login || !cell || typeof cell !== 'object') continue;
      const dm = Math.max(0, Math.min(10_000_000, Math.round(Number(cell.m) || 0)));
      const dw = Math.max(0, Math.min(10_000_000_000, Math.round(Number(cell.w) || 0)));
      const p = cell.p == null ? null : Math.max(0, Math.min(200_000_000, Math.round(Number(cell.p))));

      if (dm === 0 && dw === 0 && (p == null || p === 0)) continue;

      await query(
        `INSERT INTO user_analytics_daily (user_twitch_id, channel_login, stat_date, messages, watch_live_ms, points_snapshot)
         VALUES ($1, $2, $3::date, $4, $5, $6)
         ON CONFLICT (user_twitch_id, channel_login, stat_date) DO UPDATE SET
           messages = GREATEST(user_analytics_daily.messages, EXCLUDED.messages),
           watch_live_ms = GREATEST(user_analytics_daily.watch_live_ms, EXCLUDED.watch_live_ms),
           points_snapshot = GREATEST(COALESCE(user_analytics_daily.points_snapshot, 0), COALESCE(EXCLUDED.points_snapshot, 0)),
           updated_at = NOW()`,
        [uid, login, day, dm, dw, p],
      );
      n++;
    }

    res.json({ success: true, merged: n });
  }));

  router.delete('/me', asyncHandler(async (req, res) => {
    const uid = BigInt(req.user.twitch_id);
    await query('DELETE FROM user_analytics_daily WHERE user_twitch_id = $1', [uid]);
    res.json({ success: true });
  }));

  return router;
}
