import { Router } from 'express';
import { authenticateAdmin } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { query, queryOne } from '../db/pool.js';

export const adminRouter = Router();
adminRouter.use(authenticateAdmin);

function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}

/* Модуль для админ-панели, предоставляющий защищённые маршруты для получения метрик и управления пользователями.
- Все маршруты защищены middleware `authenticateAdmin`, который проверяет JWT токен и наличие флага isAdmin.
- GET /api/admin/metrics: возвращает общую статистику по пользователям и дружеским отношениям.
- GET /api/admin/users: возвращает список пользователей с пагинацией и поиском по имени.
- DELETE /api/admin/users/:twitch_id: удаляет пользователя по его Twitch ID.
*/

// GET /api/admin/metrics
adminRouter.get(
  '/metrics',
  asyncHandler(async (_req, res) => {
    const [
      totalUsers,
      onlineNow,
      activeLastHour,
      activeLastDay,
      activeLastWeek,
      totalFriendships,
      pendingRequests,
    ] = await Promise.all([
      queryOne('SELECT COUNT(*) AS count FROM users'),
      queryOne("SELECT COUNT(*) AS count FROM user_statuses WHERE last_seen > NOW() - INTERVAL '5 minutes'"),
      queryOne("SELECT COUNT(*) AS count FROM user_statuses WHERE last_seen > NOW() - INTERVAL '1 hour'"),
      queryOne("SELECT COUNT(*) AS count FROM user_statuses WHERE last_seen > NOW() - INTERVAL '1 day'"),
      queryOne("SELECT COUNT(*) AS count FROM user_statuses WHERE last_seen > NOW() - INTERVAL '7 days'"),
      queryOne("SELECT COUNT(*) AS count FROM friendships WHERE status = 'accepted'"),
      queryOne("SELECT COUNT(*) AS count FROM friendships WHERE status = 'pending'"),
    ]);

    const [
      msgs7d,
      watch7d,
      syncUsers7d,
      rowsAnalytics,
      newUsers7d,
      browserStats,
    ] = await Promise.all([
      queryOne(
        `SELECT COALESCE(SUM(messages), 0)::bigint AS v
         FROM user_analytics_daily WHERE stat_date >= (CURRENT_DATE - INTERVAL '7 days')::date`,
      ),
      queryOne(
        `SELECT COALESCE(SUM(watch_live_ms), 0)::bigint AS v
         FROM user_analytics_daily WHERE stat_date >= (CURRENT_DATE - INTERVAL '7 days')::date`,
      ),
      queryOne(
        `SELECT COUNT(DISTINCT user_twitch_id)::bigint AS v
         FROM user_analytics_daily
         WHERE stat_date >= (CURRENT_DATE - INTERVAL '7 days')::date
           AND (messages > 0 OR watch_live_ms > 0)`,
      ),
      queryOne('SELECT COUNT(*)::bigint AS v FROM user_analytics_daily'),
      queryOne(
        `SELECT COUNT(*)::bigint AS v FROM users
         WHERE created_at >= NOW() - INTERVAL '7 days'`,
      ),
      queryOne(
        `SELECT
           COUNT(*) FILTER (WHERE browser = 'chrome')::bigint  AS chrome,
           COUNT(*) FILTER (WHERE browser = 'firefox')::bigint AS firefox,
           COUNT(*) FILTER (WHERE browser IS NULL)::bigint     AS unknown
         FROM users`,
      ),
    ]);

    res.json({
      success: true,
      generated_at: new Date().toISOString(),
      users: {
        total: Number(totalUsers.count),
        online_now: Number(onlineNow.count),
        last_hour: Number(activeLastHour.count),
        last_day: Number(activeLastDay.count),
        last_week: Number(activeLastWeek.count),
        /* Разбивка по браузерам — для админ-панели. unknown = установлен до того,
           как клиент начал отправлять `browser` (старые сессии без обновления). */
        chrome:  Number(browserStats?.chrome  ?? 0),
        firefox: Number(browserStats?.firefox ?? 0),
        browser_unknown: Number(browserStats?.unknown ?? 0),
      },
      friendships: {
        accepted: Number(totalFriendships.count),
        pending: Number(pendingRequests.count),
      },
      extension_analytics: {
        messages_7d: Number(msgs7d?.v ?? 0),
        watch_hours_7d: Math.round((Number(watch7d?.v ?? 0) / 3600000) * 10) / 10,
        syncing_users_7d: Number(syncUsers7d?.v ?? 0),
        daily_rows_total: Number(rowsAnalytics?.v ?? 0),
        new_users_7d: Number(newUsers7d?.v ?? 0),
      },
    });
  }),
);

function resolveAnalyticsPeriod(raw) {
  const k = String(raw ?? 'all').toLowerCase();
  if (k === 'all' || k === '' || k === '0') return { days: null, key: 'all' };
  const n = parseInt(k, 10);
  if ([7, 30, 90, 365].includes(n)) return { days: n, key: String(n) };
  return { days: null, key: 'all' };
}

function analyticsBucketType(days) {
  if (days == null || days > 180) return 'month';
  if (days > 35) return 'week';
  return 'day';
}

function statDatePredicate(days, paramOffset = 1) {
  if (days == null) return { sql: 'TRUE', params: [] };
  return { sql: `stat_date >= (CURRENT_DATE - $${paramOffset}::integer)`, params: [days] };
}

/** Аналитика: выбранный период (в т.ч. всё время), воронка регистраций, активность, здоровье аудитории. */
adminRouter.get(
  '/analytics',
  asyncHandler(async (req, res) => {
    const { days, key: periodKey } = resolveAnalyticsPeriod(req.query.period);
    const bucket = analyticsBucketType(days);
    const st = statDatePredicate(days, 1);

    let regBucketExpr;
    let actBucketExpr;
    if (bucket === 'month') {
      regBucketExpr = `to_char(date_trunc('month', u.created_at AT TIME ZONE 'UTC'), 'YYYY-MM')`;
      actBucketExpr = `to_char(date_trunc('month', a.stat_date), 'YYYY-MM')`;
    } else if (bucket === 'week') {
      regBucketExpr = `to_char(date_trunc('week', u.created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD')`;
      actBucketExpr = `to_char(date_trunc('week', a.stat_date), 'YYYY-MM-DD')`;
    } else {
      regBucketExpr = `to_char(date_trunc('day', u.created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD')`;
      actBucketExpr = `to_char(a.stat_date, 'YYYY-MM-DD')`;
    }

    const regWhere =
      days == null ? 'TRUE' : 'u.created_at::date >= (CURRENT_DATE - $1::integer)';
    const regParams = days == null ? [] : [days];
    const regSql = `
      SELECT ${regBucketExpr} AS b, COUNT(*)::bigint AS cnt
      FROM users u
      WHERE ${regWhere}
      GROUP BY 1
      ORDER BY 1 ASC`;

    const actSql = `
      SELECT ${actBucketExpr} AS b,
             COALESCE(SUM(a.messages), 0)::bigint AS messages,
             COALESCE(SUM(a.watch_live_ms), 0)::bigint AS watch_ms,
             COUNT(DISTINCT a.user_twitch_id)::bigint AS dau
      FROM user_analytics_daily a
      WHERE a.stat_date <= CURRENT_DATE AND ${st.sql.replace(/stat_date/g, 'a.stat_date')}
      GROUP BY 1
      ORDER BY 1 ASC`;

    const summarySql = `
      SELECT
        COALESCE(SUM(messages), 0)::bigint AS total_messages,
        COALESCE(SUM(watch_live_ms), 0)::bigint AS total_watch_ms,
        COUNT(DISTINCT user_twitch_id)::bigint AS active_users,
        COUNT(*)::bigint AS row_cells,
        MIN(stat_date)::text AS first_stat,
        MAX(stat_date)::text AS last_stat
      FROM user_analytics_daily
      WHERE stat_date <= CURRENT_DATE AND ${st.sql}`;

    const summaryParams = [...st.params];

    const [
      registrations,
      activity,
      summaryRow,
      totalUsers,
      streamerCount,
      inactive14,
      recentUsers,
      quietUsers,
    ] = await Promise.all([
      query(regSql, regParams),
      query(actSql, st.params),
      queryOne(summarySql, summaryParams),
      queryOne('SELECT COUNT(*)::bigint AS c FROM users'),
      queryOne('SELECT COUNT(*)::bigint AS c FROM users WHERE streamer_mode = TRUE'),
      queryOne(
        `SELECT COUNT(*)::bigint AS c
         FROM users u
         LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
         WHERE COALESCE(s.last_seen, 'epoch'::timestamptz) < NOW() - INTERVAL '14 days'`,
      ),
      query(
        days == null
          ? `SELECT username, created_at
             FROM users
             ORDER BY created_at DESC
             LIMIT 18`
          : `SELECT username, created_at
             FROM users
             WHERE created_at::date >= (CURRENT_DATE - $1::integer)
             ORDER BY created_at DESC
             LIMIT 18`,
        days == null ? [] : [days],
      ),
      query(
        `SELECT u.username,
                s.last_seen,
                u.created_at
         FROM users u
         LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
         ORDER BY COALESCE(s.last_seen, 'epoch'::timestamptz) ASC NULLS FIRST
         LIMIT 18`,
      ),
    ]);

    const totalMessages = Number(summaryRow?.total_messages ?? 0);
    const activeUsers = Number(summaryRow?.active_users ?? 0);
    const avgMsg =
      activeUsers > 0 ? Math.round((totalMessages / activeUsers) * 10) / 10 : 0;

    res.json({
      success: true,
      generated_at: new Date().toISOString(),
      period: periodKey,
      period_days: days,
      bucket,
      summary: {
        total_messages: totalMessages,
        total_watch_hours: Math.round((Number(summaryRow?.total_watch_ms ?? 0) / 3600000) * 10) / 10,
        active_users: activeUsers,
        avg_messages_per_active: avgMsg,
        tracked_cells: Number(summaryRow?.row_cells ?? 0),
        first_day: summaryRow?.first_stat ?? null,
        last_day: summaryRow?.last_stat ?? null,
      },
      audience: {
        users_total: Number(totalUsers?.c ?? 0),
        streamer_mode: Number(streamerCount?.c ?? 0),
        quiet_two_weeks: Number(inactive14?.c ?? 0),
      },
      registrations: registrations.map((r) => ({ period: r.b, count: Number(r.cnt) })),
      activity: activity.map((r) => ({
        period: r.b,
        messages: Number(r.messages),
        watch_hours: Math.round((Number(r.watch_ms) / 3600000) * 10) / 10,
        active_users: Number(r.dau),
      })),
      recent_signups: recentUsers.map((r) => ({
        username: r.username,
        created_at: r.created_at,
      })),
      least_recent: quietUsers.map((r) => ({
        username: r.username,
        last_seen: r.last_seen,
        created_at: r.created_at,
      })),
    });
  }),
);

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function parseYmd(s) {
  const t = String(s ?? '').trim();
  if (!DATE_RE.test(t)) return null;
  const d = new Date(`${t}T12:00:00Z`);
  return Number.isNaN(d.getTime()) ? null : t;
}

/** Сводка регистраций по дням и месяцам за интервал [from, to] (UTC-календарные даты). */
adminRouter.get(
  '/registrations/report',
  asyncHandler(async (req, res) => {
    let toStr = parseYmd(req.query.to) ?? new Date().toISOString().slice(0, 10);
    let fromStr =
      parseYmd(req.query.from) ??
      (() => {
        const t = new Date(`${toStr}T12:00:00Z`);
        t.setUTCDate(t.getUTCDate() - 89);
        return t.toISOString().slice(0, 10);
      })();

    if (fromStr > toStr) {
      const x = fromStr;
      fromStr = toStr;
      toStr = x;
    }

    const fromD = new Date(`${fromStr}T00:00:00Z`);
    const toD = new Date(`${toStr}T00:00:00Z`);
    const spanDays = Math.ceil((toD - fromD) / 86400000) + 1;
    if (spanDays > 730) {
      return res.status(400).json({ success: false, error: 'Интервал не больше 730 дней' });
    }

    const [byDay, byMonth] = await Promise.all([
      query(
        `SELECT to_char(date_trunc('day', created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD') AS d,
                COUNT(*)::bigint AS cnt
         FROM users
         WHERE (created_at AT TIME ZONE 'UTC')::date >= $1::date
           AND (created_at AT TIME ZONE 'UTC')::date <= $2::date
         GROUP BY 1
         ORDER BY 1 DESC`,
        [fromStr, toStr],
      ),
      query(
        `SELECT to_char(date_trunc('month', created_at AT TIME ZONE 'UTC'), 'YYYY-MM') AS m,
                COUNT(*)::bigint AS cnt
         FROM users
         WHERE (created_at AT TIME ZONE 'UTC')::date >= $1::date
           AND (created_at AT TIME ZONE 'UTC')::date <= $2::date
         GROUP BY 1
         ORDER BY 1 DESC`,
        [fromStr, toStr],
      ),
    ]);

    res.json({
      success: true,
      generated_at: new Date().toISOString(),
      from: fromStr,
      to: toStr,
      by_day: byDay.map((r) => ({ date: r.d, count: Number(r.cnt) })),
      by_month: byMonth.map((r) => ({ period: r.m, count: Number(r.cnt) })),
    });
  }),
);

const REG_RANGE_MAX_DAYS = 62;

/** Список регистраций за интервал UTC [from, to], не более 62 дней. */
adminRouter.get(
  '/registrations/range',
  asyncHandler(async (req, res) => {
    const fromStr = parseYmd(req.query.from);
    const toStr = parseYmd(req.query.to);
    if (!fromStr || !toStr) {
      return res.status(400).json({ success: false, error: 'Нужны from и to в формате YYYY-MM-DD' });
    }
    let a = fromStr;
    let b = toStr;
    if (a > b) {
      const x = a;
      a = b;
      b = x;
    }
    const fromD = new Date(`${a}T00:00:00Z`);
    const toD = new Date(`${b}T00:00:00Z`);
    const spanDays = Math.ceil((toD - fromD) / 86400000) + 1;
    if (spanDays > REG_RANGE_MAX_DAYS) {
      return res.status(400).json({
        success: false,
        error: `Интервал не больше ${REG_RANGE_MAX_DAYS} дней`,
      });
    }

    const rows = await query(
      `SELECT u.username,
              u.twitch_id::text AS twitch_id,
              u.created_at,
              u.streamer_mode,
              s.last_seen,
              s.real_online,
              s.stream_slug,
              s.real_stream_slug
       FROM users u
       LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
       WHERE (u.created_at AT TIME ZONE 'UTC')::date >= $1::date
         AND (u.created_at AT TIME ZONE 'UTC')::date <= $2::date
       ORDER BY u.created_at ASC`,
      [a, b],
    );

    res.json({
      success: true,
      from: a,
      to: b,
      count: rows.length,
      users: rows,
    });
  }),
);

/** Все регистрации за календарный день UTC (YYYY-MM-DD). */
adminRouter.get(
  '/registrations/day/:date',
  asyncHandler(async (req, res) => {
    const day = parseYmd(req.params.date);
    if (!day) {
      return res.status(400).json({ success: false, error: 'Нужна дата YYYY-MM-DD' });
    }

    const rows = await query(
      `SELECT u.username,
              u.twitch_id::text AS twitch_id,
              u.created_at,
              u.streamer_mode,
              s.last_seen,
              s.real_online,
              s.stream_slug,
              s.real_stream_slug
       FROM users u
       LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
       WHERE (u.created_at AT TIME ZONE 'UTC')::date = $1::date
       ORDER BY u.created_at ASC`,
      [day],
    );

    res.json({
      success: true,
      date: day,
      count: rows.length,
      users: rows,
    });
  }),
);

// GET /api/admin/users?limit=50&offset=0&search=username
adminRouter.get(
  '/users',
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit ?? '50', 10), 200);
    const offset = parseInt(req.query.offset ?? '0', 10);
    const search = req.query.search ?? '';

    const users = await query(
      `SELECT u.twitch_id, u.username, u.created_at, u.streamer_mode,
              s.stream_slug, s.page_type, s.online, s.last_seen,
              s.real_online, s.real_stream_slug
       FROM users u
       LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
       WHERE u.username ILIKE $1
       ORDER BY u.created_at DESC
       LIMIT $2 OFFSET $3`,
      [`%${search}%`, limit, offset],
    );

    const [{ count }] = await query(
      'SELECT COUNT(*) AS count FROM users WHERE username ILIKE $1',
      [`%${search}%`],
    );

    res.json({ success: true, users, total: Number(count) });
  }),
);

// DELETE /api/admin/users/:twitch_id
adminRouter.delete(
  '/users/:twitch_id',
  asyncHandler(async (req, res) => {
    await queryOne('DELETE FROM users WHERE twitch_id = $1 RETURNING twitch_id', [
      BigInt(req.params.twitch_id),
    ]);
    res.json({ success: true });
  }),
);

// Changelog management for admin reference
adminRouter.get('/changelog', asyncHandler(async (_req, res) => {
  const entries = await query(
    `SELECT
       id,
       version,
       content,
       created_at,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at_local
     FROM changelog
     ORDER BY created_at DESC, id DESC`,
  );
  res.json({ success: true, entries });
}));

adminRouter.post('/changelog', asyncHandler(async (req, res) => {
  const version = String(req.body?.version ?? '').trim();
  const content = String(req.body?.content ?? '').trim();

  if (!version || !content) {
    return res.status(400).json({ success: false, error: 'version and content required' });
  }

  const entry = await queryOne(
    `INSERT INTO changelog (version, content)
     VALUES ($1, $2)
     RETURNING
       id,
       version,
       content,
       created_at,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at_local`,
    [version.slice(0, 20), content],
  );

  res.json({ success: true, entry });
}));

adminRouter.delete('/changelog/:id', asyncHandler(async (req, res) => {
  await queryOne('DELETE FROM changelog WHERE id = $1 RETURNING id', [req.params.id]);
  res.json({ success: true });
}));

// PATCH /api/admin/changelog/:id — полное редактирование патчнота (версия, контент, дата и время)
adminRouter.patch('/changelog/:id', asyncHandler(async (req, res) => {
  const hasVersion = hasOwn(req.body, 'version');
  const hasContent = hasOwn(req.body, 'content');
  const hasCreatedAt = hasOwn(req.body, 'created_at');

  if (!hasVersion && !hasContent && !hasCreatedAt) {
    return res.status(400).json({ success: false, error: 'Nothing to update' });
  }

  const fields = [];
  const values = [];
  let idx = 1;

  if (hasVersion) {
    const version = String(req.body.version ?? '').trim();
    if (!version) {
      return res.status(400).json({ success: false, error: 'version is required' });
    }
    fields.push(`version = $${idx++}`);
    values.push(version.slice(0, 20));
  }

  if (hasContent) {
    const content = String(req.body.content ?? '').trim();
    if (!content) {
      return res.status(400).json({ success: false, error: 'content is required' });
    }
    fields.push(`content = $${idx++}`);
    values.push(content);
  }

  if (hasCreatedAt) {
    const createdAt = String(req.body.created_at ?? '').trim();

    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(createdAt)) {
      return res.status(400).json({
        success: false,
        error: 'created_at must be in format YYYY-MM-DD HH:MM[:SS]',
      });
    }

    const normalizedCreatedAt = createdAt.length === 16 ? `${createdAt}:00` : createdAt;
    fields.push(`created_at = $${idx++}::timestamp`);
    values.push(normalizedCreatedAt);
  }

  values.push(req.params.id);

  const entry = await queryOne(
    `UPDATE changelog
     SET ${fields.join(', ')}
     WHERE id = $${idx}
     RETURNING
       id,
       version,
       content,
       created_at,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at_local`,
    values,
  );

  if (!entry) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, entry });
}));

// GET /api/admin/users/:username/friends — список друзей пользователя (реальные данные для админа)
adminRouter.get('/users/:username/friends', asyncHandler(async (req, res) => {
  const username = req.params.username.toLowerCase();
  const friends = await query(
    `SELECT
       f.id AS friendship_id, f.status, f.created_at,
       u2.username AS friend_username,
       s.real_online      AS online,
       s.real_stream_slug AS stream_slug,
       s.last_seen
     FROM friendships f
     JOIN users u1 ON u1.twitch_id = f.user_id1
     JOIN users u2 ON u2.twitch_id = CASE
       WHEN u1.username = $1 THEN f.user_id2
       ELSE f.user_id1
     END
     LEFT JOIN user_statuses s ON s.twitch_id = u2.twitch_id
     WHERE (u1.username = $1 OR EXISTS (
       SELECT 1 FROM users ux WHERE ux.twitch_id = f.user_id2 AND ux.username = $1
     ))
     ORDER BY f.created_at DESC`,
    [username],
  );
  res.json({ success: true, friends });
}));

// GET /api/admin/friendships?limit=20&offset=0&search=username
adminRouter.get(
  '/friendships',
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit ?? '20', 10), 200);
    const offset = parseInt(req.query.offset ?? '0', 10);
    const search = req.query.search ?? '';

    const friendships = await query(
      `SELECT f.id, f.status, f.created_at,
              u1.username AS username1,
              u2.username AS username2
       FROM friendships f
       JOIN users u1 ON u1.twitch_id = f.user_id1
       JOIN users u2 ON u2.twitch_id = f.user_id2
       WHERE u1.username ILIKE $1 OR u2.username ILIKE $1
       ORDER BY f.created_at DESC
       LIMIT $2 OFFSET $3`,
      [`%${search}%`, limit, offset],
    );

    const [{ count }] = await query(
      `SELECT COUNT(*) AS count FROM friendships f
       JOIN users u1 ON u1.twitch_id = f.user_id1
       JOIN users u2 ON u2.twitch_id = f.user_id2
       WHERE u1.username ILIKE $1 OR u2.username ILIKE $1`,
      [`%${search}%`],
    );

    res.json({ success: true, friendships, total: Number(count) });
  }),
);

// DELETE /api/admin/friendships/:id
adminRouter.delete(
  '/friendships/:id',
  asyncHandler(async (req, res) => {
    const f = await queryOne('DELETE FROM friendships WHERE id = $1 RETURNING id', [req.params.id]);
    if (!f) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true });
  }),
);