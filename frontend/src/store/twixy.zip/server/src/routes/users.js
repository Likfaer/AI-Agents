import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { queryOne } from '../db/pool.js';

export function createUsersRouter() {
  const router = Router();
  router.use(authenticate);

  /* POST /api/users/me/browser  — обновляет колонку `browser` у залогиненного
     пользователя (best-effort). Зовётся из background.js после успешного
     refresh, чтобы давно установившие расширение пользователи рано или поздно
     попадали в админ-разбивку Chrome/Firefox без полного перевхода. */
  router.post(
    '/me/browser',
    asyncHandler(async (req, res) => {
      const browser = req.body?.browser === 'firefox' || req.body?.browser === 'chrome'
        ? req.body.browser
        : null;
      if (!browser) return res.json({ success: true, updated: false });

      try {
        await queryOne(
          `UPDATE users
              SET browser = $2,
                  browser_updated_at = NOW()
            WHERE twitch_id = $1`,
          [BigInt(req.user.twitch_id), browser],
        );
      } catch (_) { /* не критично */ }

      res.json({ success: true, updated: true });
    }),
  );

  return router;
}
