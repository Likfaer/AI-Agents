import { Router } from 'express';
import { getTwitchUser } from '../services/twitch.js';
import { authenticateRefresh, signToken } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { queryOne } from '../db/pool.js';
import { env } from '../config/env.js';
import { ADMIN_USERNAMES } from '../config/admins.js';

export const authRouter = Router();

/* Маршрут для аутентификации через Twitch OAuth. Клиент отправляет access_token, полученный от Twitch, и сервер возвращает JWT токен для дальнейшей аутентификации.
- POST /api/auth/twitch
- Body: { access_token: string }
- Response: { success: boolean, token?: string, user?: { twitch_id, username, created_at }, error?: string }
*/
authRouter.post(
  '/twitch',
  asyncHandler(async (req, res) => {
    const { access_token, browser } = req.body;

    if (!access_token) {
      return res.status(400).json({ success: false, error: 'access_token is required' });
    }

    let twitchUser = null;
    try {
      twitchUser = await getTwitchUser(access_token);
    } catch (err) {
      console.error('[/auth/twitch] getTwitchUser failed:', err?.message || err);
      return res.status(502).json({ success: false, error: 'Twitch API unreachable' });
    }
    if (!twitchUser) {
      return res.status(401).json({ success: false, error: 'Invalid Twitch token' });
    }

    /* Только распознанные значения, чтобы мусор из тела запроса не попал в БД. */
    const browserKind = browser === 'firefox' || browser === 'chrome' ? browser : null;

    let twitchId;
    try {
      twitchId = BigInt(twitchUser.id);
    } catch (err) {
      console.error('[/auth/twitch] BigInt(twitchUser.id) failed for id:', twitchUser.id, err?.message);
      return res.status(500).json({ success: false, error: 'Bad twitch id' });
    }

    /* Простой 4-параметровый INSERT — каждый $N имеет однозначный тип,
       не путаем pg-драйвер двойным использованием параметра в CASE.
       Если колонок browser/browser_updated_at в таблице нет (миграция
       ещё не применилась), то INSERT упадёт — ловим и делаем fallback. */
    const browserUpdatedAt = browserKind ? new Date() : null;

    let user;
    try {
      user = await queryOne(
        `INSERT INTO users (twitch_id, username, browser, browser_updated_at)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (twitch_id) DO UPDATE
           SET username            = EXCLUDED.username,
               browser             = COALESCE(EXCLUDED.browser, users.browser),
               browser_updated_at  = COALESCE(EXCLUDED.browser_updated_at, users.browser_updated_at)
         RETURNING twitch_id, username, created_at`,
        [twitchId, twitchUser.login, browserKind, browserUpdatedAt],
      );
    } catch (err) {
      console.error('[/auth/twitch] INSERT with browser failed, falling back:', err?.message || err);
      try {
        /* Fallback: старая схема таблицы без колонок browser. Главное — не уронить логин. */
        user = await queryOne(
          `INSERT INTO users (twitch_id, username)
           VALUES ($1, $2)
           ON CONFLICT (twitch_id) DO UPDATE SET username = EXCLUDED.username
           RETURNING twitch_id, username, created_at`,
          [twitchId, twitchUser.login],
        );
      } catch (err2) {
        console.error('[/auth/twitch] fallback INSERT also failed:', err2?.message || err2);
        return res.status(500).json({ success: false, error: 'DB insert failed' });
      }
    }

    if (!user) {
      console.error('[/auth/twitch] INSERT returned no row');
      return res.status(500).json({ success: false, error: 'No user row' });
    }

    let token;
    try {
      token = signToken({
        twitch_id: user.twitch_id.toString(),
        username:  user.username,
        isAdmin:   ADMIN_USERNAMES.has(user.username.toLowerCase()),
      });
    } catch (err) {
      console.error('[/auth/twitch] signToken failed:', err?.message || err);
      return res.status(500).json({ success: false, error: 'JWT sign failed' });
    }

    res.json({ success: true, token, user });
  }),
);

// Маршрут админов, проверяет пароль и возвращает JWT токен с флагом isAdmin. (для доступа к админ-панели)
authRouter.post(
  '/admin/login',
  asyncHandler(async (req, res) => {
    const { password } = req.body;
    if (!password || password !== env.ADMIN_PASSWORD) {
      return res.status(401).json({ success: false, error: 'Invalid password' });
    }
    const token = signToken({ twitch_id: '0', username: 'admin', isAdmin: true });
    res.json({ success: true, token });
  }),
);

// Принимает действующий serverToken, возвращает новый на 7 дней.
// Клиент может передать `browser` в теле — заодно обновим колонку в users,
// чтобы у пользователей, давно установивших расширение, проставился источник.
authRouter.post('/refresh',
  authenticateRefresh,
  asyncHandler(async (req, res) => {
    const browser = req.body?.browser === 'firefox' || req.body?.browser === 'chrome'
      ? req.body.browser
      : null;

    const user = await queryOne(
      'SELECT twitch_id, username FROM users WHERE twitch_id = $1',
      [BigInt(req.user.twitch_id)],
    );
    if (!user) return res.status(404).json({ success: false });

    if (browser) {
      try {
        await queryOne(
          `UPDATE users
              SET browser = $2,
                  browser_updated_at = NOW()
            WHERE twitch_id = $1`,
          [BigInt(req.user.twitch_id), browser],
        );
      } catch (_) { /* не критично — не блокируем рефреш */ }
    }

    const token = signToken({
      twitch_id: user.twitch_id.toString(),
      username:  user.username,
      isAdmin:   ADMIN_USERNAMES.has(user.username.toLowerCase()),
    });
    res.json({ success: true, token });
  }),
);
