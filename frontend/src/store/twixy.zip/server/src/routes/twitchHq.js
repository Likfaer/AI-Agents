import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { helixStreamLiveByLogin } from '../services/twitchHelixApp.js';

/** Лёгкий публичный эндпоинт для расширения: эфир без user OAuth (нужен TWITCH_CLIENT_SECRET на сервере). */
export const twitchHqRouter = Router();

twitchHqRouter.use(
  rateLimit({
    windowMs: 60_000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false,
  }),
);

twitchHqRouter.get(
  '/stream-live',
  asyncHandler(async (req, res) => {
    const login =
      typeof req.query.login === 'string' ? req.query.login.trim().toLowerCase() : '';
    if (!/^[a-z0-9_]{3,25}$/.test(login)) {
      return res.status(400).json({ live: false, error: 'bad_login' });
    }
    const live = await helixStreamLiveByLogin(login);
    if (live === null) {
      return res.status(503).json({ live: false, unavailable: true });
    }
    res.json({ live });
  }),
);
