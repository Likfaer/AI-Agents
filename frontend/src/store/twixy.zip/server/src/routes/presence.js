import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { query, queryOne } from '../db/pool.js';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { emitPresenceUpdateForOwner } from '../services/presenceEmit.js';

/**
 * @param {import('socket.io').Server} io
 * @returns {import('express').Router}
 */

/* Присутствие: POST сохраняет статус; обновления уходят в комнаты user:<friend> (не в общую presence).
   GET /api/presence — статусы принятых друзей.
   POST /presence/offline — для совместимости (sendBeacon); актуальные клиенты не вызывают при закрытии вкладки. */
export function presenceRouter(io) {
  const router = Router();

  // POST /api/presence/offline — до authenticate, токен читается из тела запроса
  // (sendBeacon не поддерживает кастомные заголовки)
  router.post('/offline', asyncHandler(async (req, res) => {
    console.log('[offline] body:', req.body);
    const token = req.body?.token;
    if (!token) return res.json({ success: false });
    let user;
    try {
      user = jwt.verify(token, env.JWT_SECRET);
    } catch {
      return res.json({ success: false });
    }
    const myId = BigInt(user.twitch_id);
    await queryOne(
      `UPDATE user_statuses
        SET online = false, stream_slug = null, last_seen = NOW(),
        real_online = false, real_stream_slug = null
      WHERE twitch_id = $1`,
      [myId],
    );
    const lastSeen = new Date().toISOString();
    await emitPresenceUpdateForOwner(io, String(user.username).toLowerCase(), user.twitch_id, {
      online: false,
      stream_slug: null,
      page_type: 'other',
      last_seen: lastSeen,
    });
    res.json({ success: true });
  }));

  router.use(authenticate);
  // POST /api/presence
  router.post('/', asyncHandler(async (req, res) => {
    const { stream_slug = null, page_type = 'other', online = true, real_online = true, real_stream_slug = null } = req.body;
    const myId = BigInt(req.user.twitch_id);
    const queryText = `
    INSERT INTO user_statuses (twitch_id, stream_slug, page_type, online, last_seen, real_online, real_stream_slug)
    VALUES ($1, $2, $3, $4, NOW(), $5, $6)
    ON CONFLICT (twitch_id) DO UPDATE
      SET stream_slug      = EXCLUDED.stream_slug,
        page_type        = EXCLUDED.page_type,
        online           = EXCLUDED.online,
        last_seen        = NOW(),
        real_online      = EXCLUDED.real_online,
        real_stream_slug = EXCLUDED.real_stream_slug
      RETURNING *`;
    const values = [myId, stream_slug, page_type, online, real_online, real_stream_slug];
    try {
      console.log('[DB INSERT user_statuses]', {
        time: new Date().toISOString(),
        values,
        body: req.body
      });
      const status = await queryOne(queryText, values);
      await emitPresenceUpdateForOwner(io, String(req.user.username).toLowerCase(), req.user.twitch_id, {
        stream_slug,
        page_type,
        online,
        last_seen: status.last_seen,
      });
      res.json({ success: true, status });
    } catch (err) {
      console.error('[DB ERROR INSERT user_statuses]', {
        time: new Date().toISOString(),
        message: err.message,
        values,
        body: req.body
      });
      throw err;
    }
  }));

  // GET /api/presence  — returns presence of all current user's friends
  router.get('/', asyncHandler(async (req, res) => {
    const myId = BigInt(req.user.twitch_id);
    const statuses = await query(
      `SELECT LOWER(u.username) AS username,
        s.stream_slug,
        s.page_type,
        s.online, s.last_seen
      FROM user_statuses s
      JOIN users u ON u.twitch_id = s.twitch_id
      JOIN friendships f ON (
        (f.user_id1 = $1 AND f.user_id2 = u.twitch_id) OR
        (f.user_id2 = $1 AND f.user_id1 = u.twitch_id)
        )
        WHERE f.status = 'accepted'`,
      [myId],
    );

    res.json({ success: true, statuses });
  }));
  return router;
}
