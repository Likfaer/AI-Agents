import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { queryOne } from '../db/pool.js';

export const profileRouter = Router();

const ALLOWED_PLATFORMS = new Set(['telegram', 'discord', 'tiktok']);
const MAX_CUSTOM_LINKS = 3;

function validateSocialLinks(raw) {
  if (!raw || typeof raw !== 'object') return {};
  const clean = {};
  for (const [key, val] of Object.entries(raw)) {
    if (key === 'custom') {
      if (Array.isArray(val)) {
        clean.custom = val
          .filter(item => item && typeof item.label === 'string' && typeof item.url === 'string')
          .slice(0, MAX_CUSTOM_LINKS)
          .map(item => ({ label: item.label.slice(0, 30), url: item.url.slice(0, 200) }));
      }
      continue;
    }
    if (ALLOWED_PLATFORMS.has(key) && typeof val === 'string') {
      clean[key] = val.slice(0, 100);
    }
  }
  return clean;
}

async function areFriends(userIdA, userIdB) {
  const friendship = await queryOne(
    `SELECT 1
     FROM friendships
     WHERE status = 'accepted'
       AND ((user_id1 = $1 AND user_id2 = $2) OR (user_id1 = $2 AND user_id2 = $1))
     LIMIT 1`,
    [BigInt(userIdA), BigInt(userIdB)],
  );
  return !!friendship;
}

profileRouter.use(authenticate);

// Сначала конкретные пути — иначе в некоторых конфигурациях сегмент `notes` может перехватываться как :username
// GET /api/profile/notes/:username
profileRouter.get('/notes/:username', asyncHandler(async (req, res) => {
  const myId = BigInt(req.user.twitch_id);
  const target = await queryOne('SELECT twitch_id FROM users WHERE username = $1', [req.params.username.toLowerCase()]);
  if (!target) return res.status(404).json({ success: false, error: 'User not found' });
  if (BigInt(target.twitch_id) === myId) {
    return res.json({ success: true, note_text: '', updated_at: null });
  }
  const note = await queryOne('SELECT note_text, updated_at FROM friend_notes WHERE owner_id = $1 AND target_id = $2', [myId, target.twitch_id]);
  res.json({ success: true, note_text: note?.note_text || '', updated_at: note?.updated_at || null });
}));

// PUT /api/profile/notes/:username
profileRouter.put('/notes/:username', asyncHandler(async (req, res) => {
  const myId = BigInt(req.user.twitch_id);
  const target = await queryOne('SELECT twitch_id FROM users WHERE username = $1', [req.params.username.toLowerCase()]);
  if (!target) return res.status(404).json({ success: false, error: 'User not found' });
  if (BigInt(target.twitch_id) === myId) {
    return res.status(400).json({ success: false, error: 'Cannot save a note about yourself' });
  }
  const cleanNote = typeof req.body.note_text === 'string' ? req.body.note_text.slice(0, 500) : '';
  const note = await queryOne(
    `INSERT INTO friend_notes (owner_id, target_id, note_text, updated_at)
     VALUES ($1, $2, $3, NOW()) ON CONFLICT (owner_id, target_id) DO UPDATE
     SET note_text = EXCLUDED.note_text, updated_at = NOW() RETURNING *`,
    [myId, target.twitch_id, cleanNote],
  );
  res.json({ success: true, note });
}));

// GET /api/profile/mutual/:username — общие друзья между текущим пользователем и целью
profileRouter.get('/mutual/:username', asyncHandler(async (req, res) => {
  const viewerId = BigInt(req.user.twitch_id);
  const username = req.params.username.toLowerCase();
  const target = await queryOne(
    'SELECT twitch_id, username, profile_public FROM users WHERE username = $1',
    [username],
  );
  if (!target) return res.status(404).json({ success: false, error: 'User not found' });
  const targetId = BigInt(target.twitch_id);
  if (viewerId === targetId) {
    return res.json({ success: true, username: target.username, mutual: [], isSelf: true });
  }
  const isFriend = await areFriends(viewerId, targetId);
  const canView = !!target.profile_public || isFriend;
  if (!canView) {
    return res.status(403).json({ success: false, error: 'Profile is private' });
  }

  /* Пересекаем два списка принятых друзей и возвращаем верхние 60 совпадений по алфавиту. */
  const rows = await queryOne(
    `WITH my_friends AS (
       SELECT CASE WHEN f.user_id1 = $1 THEN f.user_id2 ELSE f.user_id1 END AS fid
       FROM friendships f
       WHERE f.status = 'accepted' AND (f.user_id1 = $1 OR f.user_id2 = $1)
     ), their_friends AS (
       SELECT CASE WHEN f.user_id1 = $2 THEN f.user_id2 ELSE f.user_id1 END AS fid
       FROM friendships f
       WHERE f.status = 'accepted' AND (f.user_id1 = $2 OR f.user_id2 = $2)
     )
     SELECT json_agg(json_build_object('twitch_id', u.twitch_id::text, 'username', u.username) ORDER BY u.username) AS list
     FROM my_friends mf
     JOIN their_friends tf ON tf.fid = mf.fid
     JOIN users u ON u.twitch_id = mf.fid
     WHERE mf.fid <> $1 AND mf.fid <> $2
     LIMIT 60`,
    [viewerId, targetId],
  );
  const mutual = Array.isArray(rows?.list) ? rows.list : [];
  res.json({ success: true, username: target.username, mutual });
}));

// GET /api/profile/:username
profileRouter.get('/:username', asyncHandler(async (req, res) => {
  const username = req.params.username.toLowerCase();
  const user = await queryOne(
    `SELECT u.twitch_id, u.username, u.created_at, u.streamer_mode, u.profile_public,
            p.status_text, p.status_emoji, p.bio, p.social_links,
            s.online, s.stream_slug, s.last_seen
     FROM users u
     LEFT JOIN user_profiles p ON p.twitch_id = u.twitch_id
     LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
     WHERE u.username = $1`,
    [username],
  );
  if (!user) return res.status(404).json({ success: false, error: 'User not found' });

  const viewerId = BigInt(req.user.twitch_id);
  const targetId = BigInt(user.twitch_id);
  const isSelf = viewerId === targetId;
  const isFriend = isSelf ? false : await areFriends(viewerId, targetId);
  const canViewProfile = isSelf || user.profile_public || isFriend;
  if (!canViewProfile) {
    return res.status(403).json({ success: false, error: 'Profile is private' });
  }

  res.json({
    success: true,
    profile: {
      username: user.username, twitch_id: user.twitch_id.toString(),
      created_at: user.created_at, streamer_mode: user.streamer_mode,
      profile_public: user.profile_public ?? true,
      status_text: user.status_text || '', status_emoji: user.status_emoji || '',
      bio: user.bio || '', social_links: user.social_links || {},
      online: user.online ?? false, stream_slug: user.stream_slug || null,
      last_seen: user.last_seen,
    },
  });
}));

// PUT /api/profile
profileRouter.put('/', asyncHandler(async (req, res) => {
  const myId = BigInt(req.user.twitch_id);
  const { status_text, status_emoji, bio, social_links } = req.body;
  const cleanStatus = typeof status_text === 'string' ? status_text.slice(0, 100) : '';
  const cleanEmoji  = typeof status_emoji === 'string' ? [...status_emoji].slice(0, 2).join('') : '';
  const cleanBio    = typeof bio === 'string' ? bio.slice(0, 500) : '';
  const cleanLinks  = validateSocialLinks(social_links);
  const profile = await queryOne(
    `INSERT INTO user_profiles (twitch_id, status_text, status_emoji, bio, social_links, updated_at)
     VALUES ($1, $2, $3, $4, $5, NOW())
     ON CONFLICT (twitch_id) DO UPDATE
       SET status_text = EXCLUDED.status_text, status_emoji = EXCLUDED.status_emoji,
           bio = EXCLUDED.bio, social_links = EXCLUDED.social_links, updated_at = NOW()
     RETURNING *`,
    [myId, cleanStatus, cleanEmoji, cleanBio, JSON.stringify(cleanLinks)],
  );
  res.json({ success: true, profile });
}));