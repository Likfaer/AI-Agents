import { Router } from 'express';
import { asyncHandler } from '../middleware/asyncHandler.js';

export const playlistRouter = Router();

playlistRouter.use((_req, res, next) => {
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  next();
});

const TWITCH_GQL_URL = 'https://gql.twitch.tv/gql';
/** Публичный Client-ID веб-плеера Twitch (как у официального сайта). */
const TWITCH_WEB_CLIENT_ID = 'kimne78kx3ncx6brgo4mv6wki5h1ko';
/** `embed` даёт другую лестницу качества и чаще преролл; для прокси-плейлиста держим как у основного сайта. */
const PLAYER_TYPE = 'site';

/** Persisted query PlaybackAccessToken — Twitch иногда меняет хэш; при сбое смотрите DevTools → Network на twitch.tv */
const PERSISTED_HASHES = [
  'ed230aa1e33e07eebb8928504583da78a5173989fadfb1ac94be06a04f3cdbe9',
  '0828119ded1c13477966434e15800ff57ddacf13ba1911c129dc2200705b0712',
];

async function gqlPlaybackToken({ isLive, login, isVod, vodID }, authToken) {
  const headers = {
    'Client-ID': TWITCH_WEB_CLIENT_ID,
    'Content-Type': 'application/json',
  };
  if (authToken) {
    headers.Authorization = `OAuth ${authToken}`;
  }

  let lastErr = 'GQL failed';
  for (const sha256Hash of PERSISTED_HASHES) {
    const body = [
      {
        operationName: 'PlaybackAccessToken',
        variables: {
          isLive,
          login: login || '',
          isVod,
          vodID: vodID || '',
          playerType: PLAYER_TYPE,
          platform: 'web',
        },
        extensions: {
          persistedQuery: {
            version: 1,
            sha256Hash,
          },
        },
      },
    ];

    const res = await fetch(TWITCH_GQL_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    const data = await res.json().catch(() => null);
    const row = Array.isArray(data) ? data[0] : data;
    const errMsg = row?.errors?.[0]?.message;

    if (!res.ok) {
      lastErr = `HTTP ${res.status}${errMsg ? `: ${errMsg}` : ''}`;
      continue;
    }

    if (errMsg && !row?.data) {
      lastErr = errMsg;
      continue;
    }

    const tokenData = isVod
      ? row?.data?.videoPlaybackAccessToken
      : row?.data?.streamPlaybackAccessToken;

    if (tokenData?.value && tokenData?.signature) {
      return { value: tokenData.value, signature: tokenData.signature };
    }

    if (errMsg) lastErr = errMsg;
  }

  throw new Error(lastErr);
}

function usherParamsFromQuery(query) {
  const skip = new Set(['auth', 'channel', 'vod_id']);
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (skip.has(k)) continue;
    if (v === undefined || v === null) continue;
    if (Array.isArray(v)) {
      for (const item of v) {
        if (item != null && item !== '') params.append(k, String(item));
      }
    } else if (v !== '') {
      params.set(k, String(v));
    }
  }
  return params;
}

/**
 * GET /api/playlist
 * Плейлист HLS с IP сервера + токен с playerType=site (как у веб-плеера, без «embed»-рекламы).
 */
playlistRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const auth = typeof req.query.auth === 'string' ? req.query.auth : '';
    const channel = typeof req.query.channel === 'string' ? req.query.channel.trim().toLowerCase() : '';
    const vodId = typeof req.query.vod_id === 'string' ? req.query.vod_id.trim() : '';

    if (!channel && !vodId) {
      return res.status(400).type('text/plain').send('channel or vod_id required');
    }

    const isVod = Boolean(vodId);
    let value;
    let signature;

    try {
      if (isVod) {
        ({ value, signature } = await gqlPlaybackToken(
          { isLive: false, login: '', isVod: true, vodID: vodId },
          auth,
        ));
      } else {
        ({ value, signature } = await gqlPlaybackToken(
          { isLive: true, login: channel, isVod: false, vodID: '' },
          auth,
        ));
      }
    } catch (err) {
      console.error('[playlist] GQL error:', err.message);
      return res.status(502).type('text/plain').send(`token_error: ${err.message}`);
    }

    const usherBase = isVod
      ? `https://usher.ttvnw.net/vod/${encodeURIComponent(vodId)}.m3u8`
      : `https://usher.ttvnw.net/api/channel/hls/${encodeURIComponent(channel)}.m3u8`;

    const params = usherParamsFromQuery(req.query || {});
    params.set('sig', signature);
    params.set('token', value);
    if (!params.has('allow_source')) params.set('allow_source', 'true');
    if (!params.has('allow_spectre')) params.set('allow_spectre', 'true');
    if (!params.has('fast_bread')) params.set('fast_bread', 'true');
    if (!params.has('playlist_include_framerate')) params.set('playlist_include_framerate', 'true');
    if (!params.has('player_backend')) params.set('player_backend', 'mediaplayer');
    if (!params.has('platform')) params.set('platform', 'web');
    if (!params.has('supported_codecs')) params.set('supported_codecs', 'av1,h265,h264');

    const usherUrl = `${usherBase}?${params.toString()}`;

    try {
      const usherRes = await fetch(usherUrl, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
      });

      const text = await usherRes.text();
      if (!usherRes.ok) {
        console.error('[playlist] usher HTTP', usherRes.status, text.slice(0, 200));
        return res.status(502).type('text/plain').send(`usher_error: ${usherRes.status}`);
      }

      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.type('application/vnd.apple.mpegurl').send(text);
    } catch (err) {
      console.error('[playlist] usher fetch:', err.message);
      return res.status(502).type('text/plain').send(`network: ${err.message}`);
    }
  }),
);
