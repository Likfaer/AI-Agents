import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { queryOne } from '../db/pool.js';

export function createSettingsRouter() {
  const router = Router();
  router.use(authenticate);

  // GET /api/settings/streamerMode/:login
  router.get(
    '/streamerMode/:login',
    asyncHandler(async (req, res) => {
      const user = await queryOne(
        'SELECT streamer_mode FROM users WHERE username = $1',
        [req.params.login.toLowerCase()],
      );
      if (!user) return res.status(404).json({ success: false, error: 'User not found' });
      res.json({ success: true, streamerMode: user.streamer_mode ?? false });
    }),
  );

  // POST /api/settings/streamerMode
  router.post(
    '/streamerMode',
    asyncHandler(async (req, res) => {
      const { streamerMode } = req.body;
      const updated = await queryOne(
        'UPDATE users SET streamer_mode = $1 WHERE twitch_id = $2 RETURNING streamer_mode',
        [!!streamerMode, BigInt(req.user.twitch_id)],
      );
      if (!updated) return res.status(404).json({ success: false, error: 'User not found' });
      res.json({ success: true, streamerMode: updated.streamer_mode });
    }),
  );

  router.get(
    '/profileVisibility/:login',
    asyncHandler(async (req, res) => {
      const user = await queryOne(
        'SELECT profile_public FROM users WHERE username = $1',
        [req.params.login.toLowerCase()],
      );
      if (!user) return res.status(404).json({ success: false, error: 'User not found' });
      res.json({ success: true, profilePublic: user.profile_public ?? true });
    }),
  );

  router.post(
    '/profileVisibility',
    asyncHandler(async (req, res) => {
      const { profilePublic } = req.body;
      const updated = await queryOne(
        'UPDATE users SET profile_public = $1 WHERE twitch_id = $2 RETURNING profile_public',
        [!!profilePublic, BigInt(req.user.twitch_id)],
      );
      if (!updated) return res.status(404).json({ success: false, error: 'User not found' });
      res.json({ success: true, profilePublic: updated.profile_public });
    }),
  );

  return router;
}
