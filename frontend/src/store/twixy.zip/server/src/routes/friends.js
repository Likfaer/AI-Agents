import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/asyncHandler.js';
import { query, queryOne } from '../db/pool.js';

/* Модуль для управления дружескими отношениями между пользователями.
- Все маршруты защищены middleware `authenticate`, который проверяет JWT токен и прикрепляет данные пользователя к req.user.
- POST /api/friends/request: отправить запрос на добавление в друзья, указав имя пользователя получателя.
- PATCH /api/friends/request/:id: принять или отклонить входящий запрос, указав статус в теле запроса.
- DELETE /api/friends/:id: удалить дружбу или отклонить запрос по его ID.
- GET /api/friends: получить список друзей с их текущим статусом (в эфире, оффлайн и т.д.).
- GET /api/friends/incoming: получить список входящих запросов на дружбу.
- GET /api/friends/outgoing: получить список исходящих запросов на дружбу.
*/
function orderedPair(a, b) {
  return BigInt(a) < BigInt(b)
    ? [BigInt(a), BigInt(b)]
    : [BigInt(b), BigInt(a)];
}

/**
 * @param {import('socket.io').Server} io
 * @returns {import('express').Router}
 */
export function friendsRouter(io) {
  const router = Router();
  router.use(authenticate);

  // Работа с дружескими запросами
  router.post( '/request', asyncHandler(async (req, res) => {
      const { to_username } = req.body;
      const fromId = BigInt(req.user.twitch_id);

      const toUser = await queryOne(
        'SELECT twitch_id, username FROM users WHERE username = $1',
        [to_username?.toLowerCase()],
      );
      if (!toUser) return res.status(404).json({ success: false, error: 'User not found' });

      const toId = BigInt(toUser.twitch_id);
      if (fromId === toId) return res.status(400).json({ success: false, error: 'Cannot add yourself' });

      const [uid1, uid2] = orderedPair(fromId, toId);
      
      const existing = await queryOne(
        'SELECT id, status, initiator_id FROM friendships WHERE user_id1 = $1 AND user_id2 = $2',
        [uid1, uid2],
      );
      if (existing) {
        // Если уже есть запрос в обоих направлениях, автоматически принимаем дружбу
        if (existing.status === 'pending' && BigInt(existing.initiator_id) !== fromId) {
          const friendship = await queryOne(
            `UPDATE friendships SET status = 'accepted' WHERE id = $1 RETURNING *`,
            [existing.id],
          );
           io.to(`user:${String(toUser.username).toLowerCase()}`).emit('friend_request_accepted', friendship);
           io.to(`user:${String(req.user.username).toLowerCase()}`).emit('friend_request_accepted', friendship);
           return res.status(200).json({ success: true, friendship, autoAccepted: true });
          }
          return res.status(409).json({ success: false, error: `Already ${existing.status}` });
        }

      const friendship = await queryOne(
        `INSERT INTO friendships (user_id1, user_id2, initiator_id, status)
         VALUES ($1, $2, $3, 'pending')
         RETURNING *`,
        [uid1, uid2, fromId],
      );

      console.log(`[Twixy] Emitting friend_request_incoming to room user:${String(toUser.username).toLowerCase()}`);
      io.to(`user:${String(toUser.username).toLowerCase()}`).emit('friend_request_incoming', {
        friendship,
        from: { username: req.user.username, twitch_id: req.user.twitch_id },
      });

      res.status(201).json({ success: true, friendship });
    }),
  );

  // Принятие или отклонение входящего запроса на дружбу
  router.patch('/request/:id', asyncHandler(async (req, res) => {
      const { status } = req.body;
      if (!['accepted', 'declined'].includes(status)) {
        return res.status(400).json({ success: false, error: 'status must be accepted or declined' });
      }
      // Откользование запроса на дружбу, работает до UPDATE, так как статус "declined" не сохраняется в БД (но существует, для будущего расширения [Например: Чёрный список/Логировани])
      if (status === 'declined') {
        const deleted = await queryOne(
          'DELETE FROM friendships WHERE id = $1 RETURNING *',
          [req.params.id],
        );
        if (!deleted) return res.status(404).json({ success: false, error: 'Not found' });
        
        // Tell both users to refresh — sender's outgoing list needs to update
        const [u1, u2] = await Promise.all([
          queryOne('SELECT username FROM users WHERE twitch_id = $1', [deleted.user_id1]),
          queryOne('SELECT username FROM users WHERE twitch_id = $1', [deleted.user_id2]),
        ]);
        if (u1) io.to(`user:${String(u1.username).toLowerCase()}`).emit('friend_request_declined', { id: deleted.id });
        if (u2) io.to(`user:${String(u2.username).toLowerCase()}`).emit('friend_request_declined', { id: deleted.id });
        
        return res.json({ success: true, friendship: deleted });
      }

      const friendship = await queryOne(
        `UPDATE friendships SET status = $1
         WHERE id = $2
         RETURNING *`,
        [status, req.params.id],
      );
      if (!friendship) return res.status(404).json({ success: false, error: 'Not found' });

      if (status === 'accepted') {
        const [u1, u2] = await Promise.all([
          queryOne('SELECT username FROM users WHERE twitch_id = $1', [friendship.user_id1]),
          queryOne('SELECT username FROM users WHERE twitch_id = $1', [friendship.user_id2]),
        ]);
        if (u1) io.to(`user:${String(u1.username).toLowerCase()}`).emit('friend_request_accepted', friendship);
        if (u2) io.to(`user:${String(u2.username).toLowerCase()}`).emit('friend_request_accepted', friendship);
      }

      
      res.json({ success: true, friendship });
    }),
  );

  // Удаление дружбы или отклонение запроса
  router.delete('/:id', asyncHandler(async (req, res) => {
      const friendship = await queryOne(
        'DELETE FROM friendships WHERE id = $1 RETURNING *',
        [req.params.id],
      );
      if (!friendship) return res.status(404).json({ success: false, error: 'Not found' });

      const [u1, u2] = await Promise.all([
        queryOne('SELECT username FROM users WHERE twitch_id = $1', [friendship.user_id1]),
        queryOne('SELECT username FROM users WHERE twitch_id = $1', [friendship.user_id2]),
      ]);
      if (u1) io.to(`user:${String(u1.username).toLowerCase()}`).emit('friend_removed', { friendship_id: friendship.id });
      if (u2) io.to(`user:${String(u2.username).toLowerCase()}`).emit('friend_removed', { friendship_id: friendship.id });

      res.json({ success: true });
    }),
  );

  // Получение списка друзей с их статусами
  router.get('/', asyncHandler(async (req, res) => {
      const myId = BigInt(req.user.twitch_id);

      const friends = await query(
        `SELECT
           u.twitch_id::text AS twitch_id,
           u.username,
           f.id        AS friendship_id,
           f.status,
           f.created_at,
           s.stream_slug,
           s.page_type,
           s.last_seen
         FROM friendships f
         JOIN users u ON (
           CASE WHEN f.user_id1 = $1 THEN f.user_id2 ELSE f.user_id1 END = u.twitch_id
         )
         LEFT JOIN user_statuses s ON s.twitch_id = u.twitch_id
         WHERE (f.user_id1 = $1 OR f.user_id2 = $1)
           AND f.status = 'accepted'
         ORDER BY u.username`,
        [myId],
      );

      res.json({
        success: true,
        friends: friends.map((row) => ({
          ...row,
          twitch_id: row.twitch_id != null && row.twitch_id !== '' ? String(row.twitch_id) : row.twitch_id,
        })),
      });
    }),
  );

  // Получение входящих запросов на дружбу
  router.get('/incoming', asyncHandler(async (req, res) => {
      const myId = BigInt(req.user.twitch_id);

      const requests = await query(
        `SELECT f.*, u.username AS from_username
         FROM friendships f
         JOIN users u ON u.twitch_id = f.initiator_id
         WHERE (f.user_id1 = $1 OR f.user_id2 = $1)
          AND f.initiator_id != $1
          AND f.status = 'pending'
         ORDER BY f.created_at DESC`,
        [myId],
      );

      res.json({ success: true, requests });
    }),
  );

  // Получение исходящих запросов на дружбу
  router.get('/outgoing', asyncHandler(async (req, res) => {
      const myId = BigInt(req.user.twitch_id);

      const requests = await query(
        `SELECT f.*, u.username AS to_username
         FROM friendships f
         JOIN users u ON u.twitch_id = CASE WHEN f.user_id1 = $1 THEN f.user_id2 ELSE f.user_id1 END
         WHERE f.initiator_id = $1
          AND f.status = 'pending'
         ORDER BY f.created_at DESC`,
        [myId],
      );

      res.json({ success: true, requests });
    }),
  );
  
  // Получение информации о пользователе по имени для отправки запроса в друзья
  router.get('/lookup/:username', asyncHandler(async (req, res) => {
  const login = req.params.username.toLowerCase();
  const requesterId = BigInt(req.user.twitch_id);
  const user = await queryOne(
    `SELECT u.twitch_id, u.username, u.profile_public,
            EXISTS(
              SELECT 1
              FROM friendships f
              WHERE f.status = 'accepted'
                AND ((f.user_id1 = $1 AND f.user_id2 = u.twitch_id) OR (f.user_id2 = $1 AND f.user_id1 = u.twitch_id))
            ) AS is_friend
     FROM users u
     WHERE u.username = $2`,
    [requesterId, login],
  );
  if (!user) return res.status(404).json({ success: false });
  const isSelf = BigInt(user.twitch_id) === requesterId;
  res.json({
    success: true,
    user: {
      twitch_id: user.twitch_id,
      username: user.username,
      profile_public: user.profile_public ?? true,
      is_friend: !!user.is_friend,
      can_open_profile: isSelf || user.profile_public || !!user.is_friend,
    },
  });
}));

  return router;
}
