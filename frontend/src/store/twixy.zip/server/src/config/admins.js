/* Модуль для хранения конфигурации администраторов */
export const ADMIN_USERNAMES = new Set(['hltorri', 'diemon514']);
