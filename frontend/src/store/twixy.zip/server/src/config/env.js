import 'dotenv/config';
/* 
  * Простой модуль для доступа к переменным окружения с поддержкой обязательных и необязательных переменных, а также типизации и дефолтных значений.
  * - `require(key)`: Получает значение обязательной переменной окружения, выбрасывая ошибку, если она не установлена.
  * - `optional(key, fallback)`: Получает значение необязательной переменной окружения, возвращая дефолтное значение, если она не установлена.
  * - `env`: Объект, содержащий все необходимые конфигурационные переменные для приложения, с типизацией и дефолтными значениями там, где это уместно.
*/
function require(key) {
  const val = process.env[key];
  if (!val) throw new Error(`Missing required env variable: ${key}`);
  return val;
}

function optional(key, fallback = '') {
  return process.env[key] ?? fallback;
}

export const env = {
  NODE_ENV:     optional('NODE_ENV', 'development'),
  PORT:         parseInt(optional('PORT', '80'), 10),
  DATABASE_URL: require('DATABASE_URL'),
  JWT_SECRET:   require('JWT_SECRET'),
  ADMIN_PASSWORD:  require('ADMIN_PASSWORD'),
  TWITCH_CLIENT_ID: require('TWITCH_CLIENT_ID'),
  /** Опционально: app access token для Helix (HQ в расширении без сохранённого twitchToken). */
  TWITCH_CLIENT_SECRET: optional('TWITCH_CLIENT_SECRET', ''),
  ALLOWED_ORIGINS: optional('ALLOWED_ORIGINS', '')
    .split(',').map(s => s.trim()).filter(Boolean),
  RATE_LIMIT_WINDOW_MS: parseInt(optional('RATE_LIMIT_WINDOW_MS', '60000'), 10),
  RATE_LIMIT_MAX:       parseInt(optional('RATE_LIMIT_MAX', '1000'), 10),
  /** Если `false`, маршруты `/admin` и `/admin-assets` не вешаются — админку отдаёт отдельный процесс (см. `src/admin/adminServer.js`). */
  SERVE_ADMIN: String(optional('SERVE_ADMIN', 'true')).toLowerCase() !== 'false',
  /**
   * Сколько прокси перед Node (nginx = 1). Нужно для `express-rate-limit` при trust proxy.
   * Если перед сервером Cloudflare и nginx — часто `2`.
   */
  TRUST_PROXY_HOPS: Math.max(1, parseInt(optional('TRUST_PROXY_HOPS', '1'), 10) || 1),
};
