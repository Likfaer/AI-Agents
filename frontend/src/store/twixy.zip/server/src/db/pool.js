import pg from 'pg';
import { env } from '../config/env.js';
/*
  * Этот модуль отвечает за создание пула соединений с базой данных PostgreSQL и предоставляет удобные функции для выполнения запросов.
  * - `pool`: Экземпляр пула соединений, который автоматически управляет подключениями к базе данных.
  * - `query(text, params)`: Удобная обёртка для выполнения параметризованных SQL-запросов, возвращающая только строки результата.
  * - `queryOne(text, params)`: Выполняет запрос и возвращает только первую строку результата или null, если строк нет.
  * Пул также настроен на обработку неожиданных ошибок соединения, логируя их для отладки.
*/

const { Pool } = pg;


export const pool = new Pool({ connectionString: env.DATABASE_URL });

pool.on('error', (err) => {
  console.error('[DB] Unexpected pool error:', err.message);
});

/**
 * Convenience wrapper — runs a parameterised query and returns rows.
 * @template T
 * @param {string} text  SQL statement with $1 … $n placeholders
 * @param {unknown[]} [params]
 * @returns {Promise<T[]>}
 */
export async function query(text, params) {
  const result = await pool.query(text, params);
  return result.rows;
}

/**
 * Runs a query and returns exactly the first row, or null.
 * @template T
 * @param {string} text
 * @param {unknown[]} [params]
 * @returns {Promise<T|null>}
 */
export async function queryOne(text, params) {
  const rows = await query(text, params);
  return rows[0] ?? null;
}
