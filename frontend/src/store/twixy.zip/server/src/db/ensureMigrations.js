import { pool } from './pool.js';

/**
 * Лёгкие миграции при старте API (без отдельного db:init на проде).
 * Каждая команда выполняется отдельно — одна ошибка не отменяет остальные.
 */
export async function ensureMigrations() {
  const statements = [
    `CREATE TABLE IF NOT EXISTS user_analytics_daily (
       user_twitch_id BIGINT NOT NULL REFERENCES users(twitch_id) ON DELETE CASCADE,
       channel_login VARCHAR(25) NOT NULL,
       stat_date DATE NOT NULL,
       messages BIGINT NOT NULL DEFAULT 0,
       watch_live_ms BIGINT NOT NULL DEFAULT 0,
       points_snapshot BIGINT,
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       PRIMARY KEY (user_twitch_id, channel_login, stat_date)
     )`,
    `CREATE INDEX IF NOT EXISTS idx_analytics_user_date ON user_analytics_daily(user_twitch_id, stat_date)`,
    `ALTER TABLE user_statuses ADD COLUMN IF NOT EXISTS real_online BOOLEAN DEFAULT TRUE`,
    `ALTER TABLE user_statuses ADD COLUMN IF NOT EXISTS real_stream_slug VARCHAR(100)`,
    `ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS status_emoji VARCHAR(10) DEFAULT ''`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_public BOOLEAN DEFAULT TRUE`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS activity_hidden_from_ids JSONB DEFAULT '[]'::jsonb`,
    /* Какой браузер у пользователя — для разбивки в админ-панели (chrome / firefox / null). */
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS browser VARCHAR(16)`,
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS browser_updated_at TIMESTAMP`,
    `CREATE INDEX IF NOT EXISTS idx_users_browser ON users(browser)`,
  ];
  for (const sql of statements) {
    try {
      await pool.query(sql);
    } catch (err) {
      console.error('[ensureMigrations]', err.message);
    }
  }
}
