/*
  Инициализация схемы базы данных.
  Безопасно запускать повторно — все операции используют IF NOT EXISTS и DO $$ BEGIN.
  Таблицы:
  - users          — пользователи Twitch
  - friendships    — дружеские связи
  - user_statuses  — онлайн-статус и активность
  - user_profiles  — расширенный профиль (статус, био, соцсети)
  - friend_notes   — заметки о друзьях
  - changelog      — патч-ноты для админки
*/
import { pool } from './pool.js';
import { ensureMigrations } from './ensureMigrations.js';

const SQL = `
-- Пользователи
CREATE TABLE IF NOT EXISTS users (
  twitch_id     BIGINT      PRIMARY KEY,
  username      VARCHAR(50) UNIQUE NOT NULL,
  created_at    TIMESTAMP   DEFAULT NOW(),
  streamer_mode BOOLEAN     DEFAULT FALSE,
  profile_public BOOLEAN    DEFAULT TRUE
);

-- Дружеские связи (user_id1 < user_id2 всегда)
CREATE TABLE IF NOT EXISTS friendships (
  id           SERIAL      PRIMARY KEY,
  user_id1     BIGINT      NOT NULL REFERENCES users(twitch_id) ON DELETE CASCADE,
  user_id2     BIGINT      NOT NULL REFERENCES users(twitch_id) ON DELETE CASCADE,
  initiator_id BIGINT      REFERENCES users(twitch_id) ON DELETE SET NULL,
  status       VARCHAR(20) NOT NULL DEFAULT 'pending',  -- pending | accepted
  created_at   TIMESTAMP   DEFAULT NOW(),
  CONSTRAINT friendships_ordered CHECK (user_id1 < user_id2),
  UNIQUE (user_id1, user_id2)
);

-- Онлайн-статус и активность
CREATE TABLE IF NOT EXISTS user_statuses (
  twitch_id        BIGINT       PRIMARY KEY REFERENCES users(twitch_id) ON DELETE CASCADE,
  stream_slug      VARCHAR(100),            -- стрим который показывается друзьям
  page_type        VARCHAR(20),             -- "watching" | "other"
  online           BOOLEAN      DEFAULT TRUE,
  last_seen        TIMESTAMP    DEFAULT NOW(),
  real_online      BOOLEAN      DEFAULT TRUE,    -- истинный статус, игнорирует невидимку
  real_stream_slug VARCHAR(100)                  -- истинный просмотр, игнорирует скрытие активности
);

-- Расширенный профиль
CREATE TABLE IF NOT EXISTS user_profiles (
  twitch_id    BIGINT       PRIMARY KEY REFERENCES users(twitch_id) ON DELETE CASCADE,
  status_text  VARCHAR(100) DEFAULT '',
  status_emoji VARCHAR(10)  DEFAULT '',
  bio          TEXT         DEFAULT '',
  social_links JSONB        DEFAULT '{}',
  updated_at   TIMESTAMP    DEFAULT NOW()
);

-- Заметки о друзьях
CREATE TABLE IF NOT EXISTS friend_notes (
  id         SERIAL    PRIMARY KEY,
  owner_id   BIGINT    NOT NULL REFERENCES users(twitch_id) ON DELETE CASCADE,
  target_id  BIGINT    NOT NULL REFERENCES users(twitch_id) ON DELETE CASCADE,
  note_text  TEXT      DEFAULT '',
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(owner_id, target_id)
);

-- Патч-ноты
CREATE TABLE IF NOT EXISTS changelog (
  id         SERIAL      PRIMARY KEY,
  version    VARCHAR(20) NOT NULL,
  content    TEXT        NOT NULL,
  created_at TIMESTAMP   DEFAULT NOW()
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_friendships_user1     ON friendships(user_id1);
CREATE INDEX IF NOT EXISTS idx_friendships_user2     ON friendships(user_id2);
CREATE INDEX IF NOT EXISTS idx_friendships_initiator ON friendships(initiator_id);
CREATE INDEX IF NOT EXISTS idx_statuses_last_seen    ON user_statuses(last_seen);
CREATE INDEX IF NOT EXISTS idx_friend_notes_owner    ON friend_notes(owner_id);
`;

try {
  await pool.query(SQL);
  await ensureMigrations();
  console.log('✅  Database schema initialised successfully');
} catch (err) {
  console.error('❌  Schema init failed:', err.message);
  process.exit(1);
} finally {
  await pool.end();
}
