import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { ADMIN_USERNAMES } from '../config/admins.js';

/**
 * Вытаскивает JWT токен из заголовка Authorization в формате "Bearer <token>".
 * @param {import('express').Request} req
 * @returns {string|null}
 */
function extractToken(req) {
  const auth = req.headers.authorization ?? '';
  return auth.startsWith('Bearer ') ? auth.slice(7) : auth || null;
}

/**
 * Промежуточное ПО для Express, которое проверяет наличие и валидность JWT токена в заголовке Authorization.
 */
export function authenticate(req, res, next) {
  const token = extractToken(req);
  if (!token) return res.status(401).json({ success: false, error: 'No token' });
  try {
    req.user = jwt.verify(token, env.JWT_SECRET);
    next();
  } catch {
    return res.status(403).json({ success: false, error: 'Invalid token' });
  }
}

export function authenticateRefresh(req, res, next) {
  const token = extractToken(req);
  if (!token) return res.status(401).json({ success: false, error: 'No token' });
  try {
    req.user = jwt.verify(token, env.JWT_SECRET, { ignoreExpiration: true });
    next();
  } catch {
    return res.status(403).json({ success: false, error: 'Invalid token' });
  }
}

/**
 *  Промежуточное ПО для Express, которое проверяет, что пользователь аутентифицирован и имеет флаг isAdmin в своем JWT токене.
 *  Используется для защиты маршрутов, доступных только администраторам.
 */
export function authenticateAdmin(req, res, next) {
  const token = extractToken(req);
  if (!token) return res.status(403).json({ success: false });

  try {
    const payload = jwt.verify(token, env.JWT_SECRET);
    // Accept if JWT has isAdmin flag OR if username is in the current ADMIN_USERNAMES set.
    // This ensures users added to ADMIN_USERNAMES don't need to re-login to get access.
    const isAdmin = payload.isAdmin || ADMIN_USERNAMES.has(payload.username?.toLowerCase());
    if (!isAdmin) throw new Error('Not an admin');
    req.user = payload;
    next();
  } catch {
    res.status(403).json({ success: false });
  }
}

/**
 * Подпись JWT токена с полезной нагрузкой, содержащей идентификатор Twitch, имя пользователя и необязательный флаг isAdmin. (7 дней по умолчанию)
 * @param {{ twitch_id: number|string, username: string, isAdmin?: boolean }} payload
 * @param {string} [expiresIn]
 * @returns {string}
 */
export function signToken(payload, expiresIn = '7d') {
  return jwt.sign(payload, env.JWT_SECRET, { expiresIn });
}
