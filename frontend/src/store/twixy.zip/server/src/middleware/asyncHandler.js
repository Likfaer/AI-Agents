/**
 * Превращает асинхронные функции-обработчики Express в функции, которые автоматически обрабатывают Promise и Errors,
 * Вместо того, чтобы вручную вызывать `next(err)` в каждом обработчике.
 * @param {Function} fn
 * @returns {import('express').RequestHandler}
 */
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
