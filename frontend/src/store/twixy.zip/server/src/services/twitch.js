import { env } from '../config/env.js';

const TWITCH_HELIX = 'https://api.twitch.tv/helix';

/**
 * Сопоставляет Twitch ID пользователя с его именем и аватаром
 * @param {string} accessToken
 * @returns {Promise<{id:string, login:string, display_name:string, profile_image_url:string}|null>}
 */
export async function getTwitchUser(accessToken) {
  try {
    const res = await fetch(`${TWITCH_HELIX}/users`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Client-Id':   env.TWITCH_CLIENT_ID,
      },
    });
    if (!res.ok) return null;
    const body = await res.json();
    return body.data?.[0] ?? null;
  } catch {
    return null;
  }
}
