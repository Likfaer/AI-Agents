import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

/**
 * Конфигурирует Socket.IO для аутентификации и управления комнатами.
 * Каждый подключившийся клиент должен предоставить JWT, который будет верифицирован.
 * После успешной аутентификации клиент присоединяется к комнате user:<username> (нижний регистр)
 * для персональных уведомлений и обновлений присутствия друзей.
 *
 * @param {import('socket.io').Server} io
 */
export function setupSockets(io) {
  // Middleware для аутентификации при подключении
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('No token'));

    try {
      socket.user = jwt.verify(token, env.JWT_SECRET);
      next();
    } catch {
      next(new Error('Auth error'));
    }
  });

  io.on('connection', (socket) => {
    const { username } = socket.user;
    const room = `user:${String(username).toLowerCase()}`;
    socket.join(room);

    socket.on('disconnect', () => {
      // Опционально: можно отправить уведомление о том, что пользователь отключился
    });
  });
}
