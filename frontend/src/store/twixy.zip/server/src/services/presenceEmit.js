import { query } from '../db/pool.js';

/**
 * Рассылает presence_update друзьям владельца статуса (комнаты user:<friend>).
 */
export async function emitPresenceUpdateForOwner(io, ownerUsername, ownerTwitchId, payload) {
  const oid = BigInt(ownerTwitchId);
  const friends = await query(
    `SELECT u.username, u.twitch_id::text AS twitch_id
     FROM friendships f
     JOIN users u ON u.twitch_id = CASE WHEN f.user_id1 = $1 THEN f.user_id2 ELSE f.user_id1 END
     WHERE f.status = 'accepted' AND (f.user_id1 = $1 OR f.user_id2 = $1)`,
    [oid],
  );

  const slug = payload.stream_slug ?? null;
  const ptype = payload.page_type ?? 'other';
  const lastSeen = payload.last_seen ?? new Date().toISOString();
  const ownerLogin = String(ownerUsername || '').toLowerCase();

  for (const f of friends) {
    const room = `user:${String(f.username).toLowerCase()}`;
    io.to(room).emit('presence_update', {
      username: ownerLogin,
      stream_slug: slug,
      page_type: ptype,
      online: payload.online,
      last_seen: lastSeen,
    });
  }
}
