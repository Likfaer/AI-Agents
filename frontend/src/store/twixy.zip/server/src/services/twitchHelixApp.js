import { env } from '../config/env.js';

let cachedAppToken = '';
let cachedAppTokenExpiresAt = 0;

async function fetchAppAccessToken() {
  const secret = env.TWITCH_CLIENT_SECRET;
  if (!secret) return null;
  const now = Date.now();
  if (cachedAppToken && now < cachedAppTokenExpiresAt - 60_000) {
    return cachedAppToken;
  }
  const body = new URLSearchParams({
    client_id: env.TWITCH_CLIENT_ID,
    client_secret: secret,
    grant_type: 'client_credentials',
  });
  const r = await fetch('https://id.twitch.tv/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!r.ok) {
    console.error('[twitchHelixApp] oauth2/token HTTP', r.status);
    return null;
  }
  const data = await r.json().catch(() => null);
  const token = data?.access_token;
  const expiresIn = Number(data?.expires_in) || 3600;
  if (!token) return null;
  cachedAppToken = token;
  cachedAppTokenExpiresAt = Date.now() + expiresIn * 1000;
  return token;
}

/**
 * Эфир канала по Helix (app token). null — секрет не задан или запрос не удался.
 */
export async function helixStreamLiveByLogin(login) {
  const L = String(login || '')
    .trim()
    .toLowerCase();
  if (!/^[a-z0-9_]{3,25}$/.test(L)) return null;

  const appToken = await fetchAppAccessToken();
  if (!appToken) return null;

  const url = `https://api.twitch.tv/helix/streams?user_login=${encodeURIComponent(L)}`;
  const r = await fetch(url, {
    headers: {
      Authorization: `Bearer ${appToken}`,
      'Client-Id': env.TWITCH_CLIENT_ID,
    },
  });
  if (!r.ok) {
    console.error('[twitchHelixApp] helix/streams HTTP', r.status);
    return null;
  }
  const data = await r.json().catch(() => null);
  return Array.isArray(data?.data) && data.data.length > 0;
}
