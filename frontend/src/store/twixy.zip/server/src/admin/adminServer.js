/**
 * Отдельный процесс только для админ-панели: HTML + /admin-assets, остальное /api → основной API.
 *
 * Запуск: ADMIN_PORT=3099 TWIXY_API_INTERNAL=http://127.0.0.1:3000 node src/admin/adminServer.js
 * В .env API: SERVE_ADMIN=false
 */
import 'dotenv/config';
import express from 'express';
import http from 'http';
import https from 'https';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const ADMIN_PORT = parseInt(process.env.ADMIN_PORT || '3099', 10);
const API_INTERNAL = (process.env.TWIXY_API_INTERNAL || 'http://127.0.0.1:3000').replace(/\/$/, '');

const app = express();

app.disable('x-powered-by');

function proxyApi(req, res) {
  let dest;
  try {
    dest = new URL(req.originalUrl, API_INTERNAL);
  } catch {
    res.status(500).send('Bad TWIXY_API_INTERNAL');
    return;
  }

  const isHttps = dest.protocol === 'https:';
  const lib = isHttps ? https : http;
  const port = dest.port || (isHttps ? 443 : 80);
  const headers = { ...req.headers };
  delete headers.host;
  headers.host = `${dest.hostname}:${port}`;

  const opts = {
    hostname: dest.hostname,
    port,
    path: dest.pathname + dest.search,
    method: req.method,
    headers,
  };

  const preq = lib.request(opts, (pres) => {
    const outHeaders = { ...pres.headers };
    delete outHeaders['transfer-encoding'];
    res.writeHead(pres.statusCode || 502, outHeaders);
    pres.pipe(res);
  });
  preq.on('error', (err) => {
    if (!res.headersSent) res.status(502).json({ success: false, error: `API proxy: ${err.message}` });
  });
  req.pipe(preq);
}

app.use('/api', proxyApi);

app.get('/admin', (_req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});
app.use('/admin-assets', express.static(path.join(__dirname, 'icons'), { maxAge: '7d' }));

app.listen(ADMIN_PORT, () => {
  console.log(`[adminServer] http://127.0.0.1:${ADMIN_PORT}/admin  →  API ${API_INTERNAL}`);
});
