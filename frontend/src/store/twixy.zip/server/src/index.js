import './config/env.js'; // validates env on startup
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { Server as IOServer } from 'socket.io';

import { env } from './config/env.js';
import { pool } from './db/pool.js';
import { authRouter } from './routes/auth.js';
import { friendsRouter } from './routes/friends.js';
import { presenceRouter } from './routes/presence.js';
import { adminRouter } from './routes/admin.js';
import { profileRouter } from './routes/profile.js';
import { setupSockets } from './services/sockets.js';
import { asyncHandler } from './middleware/asyncHandler.js';
import { query, queryOne } from './db/pool.js';
import { createSettingsRouter } from './routes/settings.js';
import { createUsersRouter } from './routes/users.js';
import { playlistRouter } from './routes/playlist.js';
import { twitchHqRouter } from './routes/twitchHq.js';
import { statsRouter } from './routes/stats.js';
import { ensureMigrations } from './db/ensureMigrations.js';
import { emitPresenceUpdateForOwner } from './services/presenceEmit.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const server = http.createServer(app);

/**
 * Разрешаем все расширения (chrome-extension://*, moz-extension://*) без привязки к UUID —
 * иначе при каждой временной установке в Firefox UUID меняется и ломает CORS.
 * Остальные origin берутся из ALLOWED_ORIGINS.
 */
const allowedOriginSet = new Set(env.ALLOWED_ORIGINS.map((s) => s.toLowerCase()));
function corsOriginCheck(origin, cb) {
  if (!origin) return cb(null, true);
  const o = String(origin).toLowerCase();
  if (allowedOriginSet.size === 0) return cb(null, true);
  if (allowedOriginSet.has(o)) return cb(null, true);
  if (/^chrome-extension:\/\/[a-z0-9]+$/i.test(o)) return cb(null, true);
  if (/^moz-extension:\/\/[0-9a-f-]+$/i.test(o)) return cb(null, true);
  return cb(null, false);
}

const io = new IOServer(server, {
  path: '/api/socket.io',
  cors: { origin: corsOriginCheck, methods: ['GET', 'POST'], credentials: true },
});
setupSockets(io);

// Админка: либо здесь (по умолчанию), либо отдельный процесс adminServer + SERVE_ADMIN=false
if (env.SERVE_ADMIN) {
  app.get('/admin', (_req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'admin.html'));
  });
  app.use('/admin-assets', express.static(path.join(__dirname, 'admin', 'icons'), { maxAge: '7d' }));
}

app.use(helmet());
app.set('trust proxy', env.TRUST_PROXY_HOPS);
app.use(cors({
  origin: corsOriginCheck,
  methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));
app.options('*', cors({ origin: corsOriginCheck, credentials: true }));

morgan.token('cf-ip', (req) =>
  req.headers['cf-connecting-ip'] ||
  req.headers['x-forwarded-for'] ||
  req.socket.remoteAddress
);

morgan.token('cf-country', (req) =>
  req.headers['cf-ipcountry'] || '-'
);

morgan.token('user', (req) =>
  req.user?.username ?? 'guest'
);

app.use(
  morgan(':date[iso] | :cf-ip | :cf-country | :user | :method :url | :status | :res[content-length]b | :response-time ms')
);

app.use(express.json());
/* Поддержка form-urlencoded — нужно для `/api/auth/twitch`, который клиент
   шлёт без JSON, чтобы избежать CORS preflight (см. background.js). */
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  if (req.method !== 'GET') {
    console.log('[REQUEST]', {
      time: new Date().toISOString(),
      method: req.method,
      url: req.url,
      body: req.body,
    });
  }
  next();
});

/** HLS master: без лимита как у остального API (один запрос на сессию плеера). */
app.use('/api/playlist', playlistRouter);
app.use('/api/twitch', twitchHqRouter);

/* Общий лимитер. Несколько ВАЖНЫХ нюансов:
   - `skip: req => req.method === 'OPTIONS'` — иначе CORS preflight тоже
     попадает под лимит, отдаёт 429 без `Access-Control-Allow-Origin`,
     браузер блокирует основной запрос и расширение видит «Failed to fetch»
     (см. кейс с залипшим логином: POST `/api/auth/twitch` молча падал).
   - `handler` — гарантируем, что 429 уезжает с явными CORS-заголовками,
     иначе fetch из chrome-extension:// по факту не получает ответа. */
function rateLimitHandler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Vary', 'Origin');
  res.status(429).json({ success: false, error: 'Too many requests, slow down.', retryAfterMs: 30_000 });
}

app.use(rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  handler: rateLimitHandler,
}));

/* Отдельный, более СТРОГИЙ лимитер на auth-эндпоинты, но он КЛЮЧИТСЯ только
   на /api/auth (и не трогает preflight): 60 запросов в минуту с одного IP —
   с лихвой покрывает любой нормальный логин (включая несколько открытых
   вкладок Twitch, каждая из которых может запустить silent re-auth).
   Бэкофф со стороны клиента уже не даёт уйти в шторм, так что это
   защита только от грубых ботов. */
const authLimiter = rateLimit({
  windowMs: 60_000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS',
  handler: rateLimitHandler,
});

app.get('/api/changelog', asyncHandler(async (_req, res) => {
  const entries = await query(
    `SELECT
       id,
       version,
       content,
       to_char(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at
     FROM changelog
     ORDER BY changelog.created_at DESC
     LIMIT 20`,
  );

  res.json({ success: true, entries });
}));

// Маршруты API
app.use('/api/auth', authLimiter, authRouter);
app.use('/api/friends', friendsRouter(io));
app.use('/api/presence', presenceRouter(io));

// POST /api/admin/login — password-based login returning a short-lived JWT
app.post('/api/admin/login', asyncHandler(async (req, res) => {
  const { password } = req.body;
  console.log('[ADMIN LOGIN] received:', JSON.stringify(password));
  console.log('[ADMIN LOGIN] expected:', JSON.stringify(env.ADMIN_PASSWORD));
  console.log('[ADMIN LOGIN] match:', password === env.ADMIN_PASSWORD);

  if (!password || password !== env.ADMIN_PASSWORD) {
    return res.status(403).json({ success: false, error: 'Wrong password' });
  }

  const { signToken } = await import('./middleware/auth.js');
  const token = signToken({ username: 'admin_panel', isAdmin: true, twitch_id: 0 }, '8h');
  res.json({ success: true, token });
}));

app.use('/api/admin', adminRouter);
app.get('/api/health', (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));
app.use('/api/settings', createSettingsRouter());
app.use('/api/users', createUsersRouter());
app.use('/api/profile', profileRouter);
app.use('/api/stats', statsRouter());

// 404 для несуществующих маршрутов
app.use((_req, res) => res.status(404).json({ success: false, error: 'Not found' }));

// Глобальный обработчик ошибок
app.use((err, _req, res, _next) => {
  console.error('[ERROR]', err.message ?? err);
  if (res.headersSent) return;
  const status = err.status ?? 500;
  res.status(status).json({ success: false, error: err.message ?? 'Internal server error' });
});

async function start() {
  await pool.query('SELECT 1');
  console.log('✅  PostgreSQL connected');
  await ensureMigrations();

  // Очистка зависших онлайн-статусов каждые 2 минуты
  setInterval(async () => {
    try {
      const result = await pool.query(
        `UPDATE user_statuses
         SET online = false, stream_slug = null,
             real_online = false, real_stream_slug = null
         WHERE (real_online = true OR online = true)
           AND last_seen < NOW() - INTERVAL '4 minutes'
         RETURNING twitch_id`
      );
      const count = result.rowCount;
      if (count > 0) {
        console.log(`[Cleanup] Marked ${count} stale user(s) as offline`);
        for (const row of result.rows) {
          const user = await queryOne(
            'SELECT username, twitch_id FROM users WHERE twitch_id = $1',
            [row.twitch_id],
          );
          if (user) {
            const lastSeen = new Date().toISOString();
            await emitPresenceUpdateForOwner(io, String(user.username).toLowerCase(), user.twitch_id, {
              online: false,
              stream_slug: null,
              page_type: 'other',
              last_seen: lastSeen,
            });
          }
        }
      }
    } catch (err) {
      console.error('[Cleanup] Error:', err.message);
    }
  }, 2 * 60 * 1000);

  server.listen(env.PORT, () => {
    console.log(`🚀  Twixy API listening on port ${env.PORT}`);
    console.log(`    Environment: ${env.NODE_ENV}`);
  });
}

start().catch((err) => {
  console.error('❌  Failed to start server:', err?.message || err || 'Unknown error');
  if (err?.stack) console.error(err.stack);
  process.exit(1);
});