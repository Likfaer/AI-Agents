# Twixy — Руководство по установке на Ubuntu

## Требования

- Ubuntu 20.04+ (или любой Debian-based дистрибутив)
- Node.js 20+
- PostgreSQL 14+
- Twitch Developer приложение
- PM2 для автозапуска
- cloudflared (рекомендуется для публичного доступа)

---

## 1. Установка Node.js

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # должно показать v20+
```

---

## 2. Установка PostgreSQL

```bash
sudo apt install -y postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

Создай пользователя и базу данных:

```bash
sudo -u postgres psql
```

Внутри psql:

```sql
CREATE USER twixy WITH PASSWORD 'your_strong_password';
CREATE DATABASE twixy OWNER twixy;
\q
```

---

## 3. Загрузка проекта на сервер

Загрузи проект через FileZilla или scp в любую папку, например `/root/twixy`:

```
/root/twixy/
├── client/
└── server/
```

---

## 4. Настройка переменных окружения

```bash
cd /root/twixy/server
cp .env.example .env
nano .env
```

Заполни все значения:

```env
NODE_ENV=production
PORT=3000

DATABASE_URL=postgresql://twixy:your_strong_password@localhost:5432/twixy

JWT_SECRET=сгенерируй_длинную_случайную_строку
ADMIN_PASSWORD=пароль_от_админ_панели

TWITCH_CLIENT_ID=твой_client_id_с_dev.twitch.tv

# ID расширения из chrome://extensions
ALLOWED_ORIGINS=https://www.twitch.tv,chrome-extension://твой_id_расширения

RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=1000
```

Для генерации `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

---

## 5. Добавление админов

Открой `server/src/config/admins.js` и добавь Twitch никнеймы (строчными буквами):

```js
export const ADMIN_USERNAMES = new Set(['твойникнейм', 'другойадмин']);
```

---

## 6. Установка зависимостей

```bash
cd /root/twixy/server
npm install
```

---

## 7. Инициализация базы данных

```bash
npm run db:init
```

Должно вывести:

```
✅  Database schema initialised successfully
```

Если нужно сбросить БД и начать заново:

```sql
-- Выполни в psql, потом снова npm run db:init
DROP TABLE IF EXISTS friendships CASCADE;
DROP TABLE IF EXISTS user_statuses CASCADE;
DROP TABLE IF EXISTS changelog CASCADE;
DROP TABLE IF EXISTS users CASCADE;
```

---

## 8. Запуск сервера

**Вручную (для тестирования):**

```bash
npm start
```

Должно вывести:

```
✅  PostgreSQL connected
🚀  Twixy API listening on port 3000
    Environment: production
```

**С автозапуском через PM2 (рекомендуется для продакшна):**

```bash
sudo npm install -g pm2
cd /root/twixy/server
pm2 start src/index.js --name twixy
pm2 save
pm2 startup   # выполни команду которую напечатает эта команда
```

Полезные команды PM2:

```bash
pm2 logs twixy --lines 50   # просмотр логов
pm2 restart twixy           # перезапуск
pm2 stop twixy              # остановка
pm2 status                  # статус процессов
```

---

## 9. Настройка cloudflared туннеля

cloudflared позволяет сделать локальный сервер доступным по публичному HTTPS домену без открытия портов.

```bash
# Установка
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
sudo dpkg -i cloudflared.deb

# Авторизация
cloudflared tunnel login

# Создание туннеля
cloudflared tunnel create twixy

# Настройка конфига
nano ~/.cloudflared/config.yml
```

Содержимое `config.yml`:

```yaml
tunnel: twixy
credentials-file: /root/.cloudflared/<tunnel-id>.json

ingress:
  - hostname: twixy.cc
    service: http://localhost:3000
  - service: http_status:404
```

Запуск туннеля:

```bash
cloudflared tunnel run twixy
```

**Автозапуск cloudflared через systemd:**

```bash
sudo cloudflared service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
```

Проверка:

```bash
sudo systemctl status cloudflared
```

---

## 10. (Опционально) nginx как reverse proxy

Если хочешь использовать nginx вместо cloudflared или в дополнение к нему:

```bash
sudo apt install -y nginx
sudo nano /etc/nginx/sites-available/twixy
```

```nginx
server {
    listen 80;
    server_name twixy.cc;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header CF-Connecting-IP $http_cf_connecting_ip;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/twixy /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 11. Загрузка расширения в Chrome

1. Открой Chrome → `chrome://extensions`
2. Включи **Режим разработчика** (переключатель справа вверху)
3. Нажми **Загрузить распакованное расширение**
4. Выбери папку `client/src`
5. Скопируй ID расширения
6. Добавь его в `ALLOWED_ORIGINS` в `.env` → `pm2 restart twixy`

---

## 12. Настройка Twitch Developer App

1. Зайди на [dev.twitch.tv/console/apps](https://dev.twitch.tv/console/apps)
2. Создай или выбери приложение
3. В **OAuth Redirect URLs** добавь:
   ```
   https://твой_id_расширения.chromiumapp.org/
   ```
4. Скопируй **Client ID** → вставь в `TWITCH_CLIENT_ID` в `.env`

Чтобы узнать redirect URL — открой консоль браузера на любой странице Twitch с загруженным расширением:

```js
chrome.identity.getRedirectURL()
```

---

## Структура сервера

```
server/
├── src/
│   ├── config/
│   │   ├── admins.js       ← Twitch никнеймы админов
│   │   └── env.js          ← валидация конфига
│   ├── db/
│   │   ├── init.js         ← запустить один раз для создания таблиц
│   │   └── pool.js         ← подключение к PostgreSQL
│   ├── middleware/
│   │   ├── auth.js         ← JWT аутентификация (401/403)
│   │   └── asyncHandler.js ← обёртка для async роутов
│   ├── routes/
│   │   ├── admin.js        ← метрики, пользователи, changelog
│   │   ├── auth.js         ← Twitch OAuth логин
│   │   ├── friends.js      ← заявки и управление друзьями
│   │   ├── presence.js     ← онлайн статус, активность, офлайн
│   │   └── settings.js     ← режим стримера
│   ├── services/
│   │   ├── sockets.js      ← Socket.IO + офлайн при дисконнекте
│   │   └── twitch.js       ← Twitch API хелперы
│   └── index.js            ← точка входа
├── .env                    ← твой конфиг (никогда не коммитить!)
├── .env.example            ← шаблон
└── package.json
```

---

## Частые проблемы

**Порт 80 занят nginx**  
Используй `PORT=3000` в `.env` и настрой nginx или cloudflared как proxy.

**`❌ Schema init failed: role "twixy" does not exist`**  
Пользователь БД не создан. Вернись к шагу 2.

**`Missing required env variable: JWT_SECRET`**  
Файл `.env` отсутствует или значение пустое. Проверь шаг 4.

**Расширение не подключается к серверу**  
Убедись что ID расширения добавлен в `ALLOWED_ORIGINS` и сервер перезапущен после изменения.

**SSH не подключается**  
Если используешь cloudflared туннель — SSH тоже можно проксировать через него. Либо подключайся через веб-консоль Hetzner.

**Статус не обновляется у друзей**  
Проверь что `NODE_ENV=production` и `PORT=3000` в `.env`. Перезапусти через `pm2 restart twixy`.
